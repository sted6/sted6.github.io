package com.wgu.wguscheduler.packages.assessments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.wgu.wguscheduler.R;
import com.wgu.wguscheduler.databinding.FragmentAssessmentsBinding;

public class AssessmentFragment extends Fragment {
    private FragmentAssessmentsBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        AssessmentViewModel assessmentViewModel = new ViewModelProvider(this).get(AssessmentViewModel.class);

        binding = FragmentAssessmentsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        TextView noAssessmentsText = root.findViewById(R.id.assessments_no_assessments_text);

        RecyclerView recyclerViewAssessments = root.findViewById(R.id.assessments_recycler_view);
        AssessmentAdapter adapter = new AssessmentAdapter(new AssessmentAdapter.AssessmentDiff(), getActivity());
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());

        recyclerViewAssessments.setLayoutManager(layoutManager);
        recyclerViewAssessments.setAdapter(adapter);

        assessmentViewModel.getAssessmentsLive().observe(getViewLifecycleOwner(), (assessments) -> {
            if (assessments.size() > 0) {
                noAssessmentsText.setVisibility(View.GONE);
            } else {
                noAssessmentsText.setVisibility(View.VISIBLE);
            }
            adapter.submitList(assessments);
        });

        FloatingActionButton fab = root.findViewById(R.id.assessments_fab);

        fab.setOnClickListener(view -> Navigation.findNavController(view).navigate(R.id.action_assessmentsFragment_to_addAssessmentFragment));

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}