package com.wgu.wguscheduler.packages.courses;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.wgu.wguscheduler.database.RoomDB;
import com.wgu.wguscheduler.packages.terms.Term;

import java.util.ArrayList;
import java.util.List;

public class CoursesViewModel extends AndroidViewModel {

    private final RoomDB database;
    LiveData<List<Course>> liveCourses;
    Course selectedCourse;
    Term parentTerm;
    ArrayList<Course> selectedCourses = new ArrayList<>();
    ArrayList<Course> coursesToBeAddedToTerm = new ArrayList<>();
    ArrayList<String> selectedNotes = new ArrayList<>();

    public CoursesViewModel(Application application) {
        super(application);
        database = RoomDB.getInstance(application);
        liveCourses = database.courseDao().getAllCoursesLive();
    }

    public Course getCourseById(long id) {
        return database.courseDao().getCourseById(id);
    }
    public List<Course> getCourses() { return database.courseDao().getAllCourses(); }

    public LiveData<List<Course>> getCoursesLive() { return liveCourses; }

    public long addCourse(Course course) {
        return database.courseDao().insert(course);
    }

    public void deleteCourse(Course course) { database.courseDao().delete(course);}

    public Course getSelectedCourse() {
        return selectedCourse;
    }

    public void setSelectedCourse(Course selectedCourse) {
        this.selectedCourse = selectedCourse;
    }

    public Term getParentTerm() {
        return parentTerm;
    }

    public void setParentTerm(Term parentTerm) {
        this.parentTerm = parentTerm;
    }

    public void addCourseToSelectedList(Course course) {
        selectedCourses.add(course);
    }

    public void removeCourseFromSelectedList(Course course) {
        selectedCourses.remove(course);
    }

    public ArrayList<Course> getSelectedCourses() {
        return selectedCourses;
    }

    public LiveData<List<Course>> getLiveCoursesByParentTerm(long id) {
        return database.courseDao().getCoursesByParentTermLive(id);
    }

    public void updateCourse(Course course) {
        database.courseDao().update(course);
    }

    public void resetSelectedCourses() {
        selectedCourses.clear();
    }

    public void addCoursesToToBeAddedToTermList(List<Course> courses) {
        coursesToBeAddedToTerm.addAll(courses);
    }

    public ArrayList<Course> getCoursesToBeAddedToTerm() {
        return coursesToBeAddedToTerm;
    }

    public void resetCoursesToBeAddedToTermList() {
        coursesToBeAddedToTerm.clear();
    }

    public void addNoteToSelectedList(String note) {
        selectedNotes.add(note);
    }

    public void removeNoteFromSelectedList(String note) {
        selectedNotes.remove(note);
    }

    public void resetSelectedNotesList() {
        selectedNotes.clear();
    }

    public ArrayList<String> getSelectedNotes() {
        return selectedNotes;
    }

}