package com.wgu.wguscheduler.packages.courses;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.wgu.wguscheduler.R;
import com.wgu.wguscheduler.databinding.FragmentCoursesBinding;

public class CoursesFragment extends Fragment {
    private FragmentCoursesBinding binding;
    private TextView noCoursesText;

    public CoursesFragment() {}

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        CoursesViewModel coursesViewModel = new ViewModelProvider(this).get(CoursesViewModel.class);


        binding = FragmentCoursesBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        noCoursesText = root.findViewById(R.id.courses_no_courses_text);

        RecyclerView recyclerViewCourses = root.findViewById(R.id.recycler_view_courses);
        CourseAdapter adapter = new CourseAdapter(new CourseAdapter.CourseDiff(), getActivity());
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());

        recyclerViewCourses.setLayoutManager(layoutManager);
        recyclerViewCourses.setAdapter(adapter);

        coursesViewModel.getCoursesLive().observe(getViewLifecycleOwner(), (courses) -> {
            if (courses.size() > 0) {
                noCoursesText.setVisibility(View.GONE);
            } else {
                noCoursesText.setVisibility(View.VISIBLE);
            }
            adapter.submitList(courses);
        });

        FloatingActionButton fab = root.findViewById(R.id.fab_courses);

        fab.setOnClickListener(view -> Navigation.findNavController(view).navigate(R.id.action_coursesFragment_to_addCourseFragment));

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}