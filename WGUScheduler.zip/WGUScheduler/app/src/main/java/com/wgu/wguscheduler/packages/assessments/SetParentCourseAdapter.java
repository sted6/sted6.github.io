package com.wgu.wguscheduler.packages.assessments;

import android.app.Activity;

import android.app.Dialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.wgu.wguscheduler.R;
import com.wgu.wguscheduler.packages.courses.Course;

import org.jetbrains.annotations.NotNull;

public class SetParentCourseAdapter extends ListAdapter<Course, SetParentCourseAdapter.CourseViewHolder> {
    private final Activity context;
    private final Dialog dialog;

    public SetParentCourseAdapter(@NonNull DiffUtil.ItemCallback<Course> diffCallback, Activity context, Dialog dialog) {
        super(diffCallback);
        this.context = context;
        this.dialog = dialog;
    }

    @NonNull @NotNull @Override
    public CourseViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return CourseViewHolder.create(parent);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull CourseViewHolder holder, int position) {
        Course course = getItem(position);
        holder.bind(course, context, dialog);
    }

    public static class CourseDiff extends DiffUtil.ItemCallback<Course> {
        @Override
        public boolean areItemsTheSame(@NonNull Course oldItem, @NonNull Course newItem) {
            return oldItem == newItem;
        }
        @Override
        public boolean areContentsTheSame(@NonNull Course oldItem, @NonNull Course newItem) {
            return oldItem.getTitle().equals(newItem.getTitle());
        }
    }

    public static class CourseViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        LinearLayout linearLayout;
        AssessmentViewModel assessmentViewModel;

        private CourseViewHolder(View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.parent_term_text);
            linearLayout = itemView.findViewById(R.id.parent_term_item);
        }

        public void bind(Course course, Activity context, Dialog dialog){
            textView.setText(course.getTitle());
            linearLayout.setOnClickListener(view -> {
                assessmentViewModel = ViewModelProviders.of((FragmentActivity)context).get(AssessmentViewModel.class);
                assessmentViewModel.setParentCourse(course);
                dialog.dismiss();
            });
        }

        public static CourseViewHolder create(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.set_parent_term_item, parent, false);

            return new CourseViewHolder(view);
        }

    }

}
