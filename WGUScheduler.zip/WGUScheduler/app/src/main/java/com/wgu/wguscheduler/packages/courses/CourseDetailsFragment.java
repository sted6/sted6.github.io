package com.wgu.wguscheduler.packages.courses;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Dialog;
import android.app.PendingIntent;
import android.app.Notification;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.telephony.SmsManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.wgu.wguscheduler.MainActivity;
import com.wgu.wguscheduler.NotificationBroadcast;
import com.wgu.wguscheduler.R;
import com.wgu.wguscheduler.packages.assessments.Assessment;
import com.wgu.wguscheduler.packages.assessments.AssessmentViewModel;
import com.wgu.wguscheduler.packages.assessments.CourseAssessmentsAdapter;
import com.wgu.wguscheduler.packages.instructors.AddInstructorToCourseAdapter;
import com.wgu.wguscheduler.packages.instructors.Instructor;
import com.wgu.wguscheduler.packages.instructors.CourseInstructorsAdapter;
import com.wgu.wguscheduler.packages.instructors.InstructorDetailsAdapter;
import com.wgu.wguscheduler.packages.instructors.InstructorsViewModel;
import com.wgu.wguscheduler.packages.terms.Term;
import com.wgu.wguscheduler.packages.terms.TermsViewModel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import static com.wgu.wguscheduler.MainActivity.NOTIFICATION_CHANNEL_ID;

public class CourseDetailsFragment extends Fragment {
    private static final String TAG = "CourseDetailsFragment";
    private CoursesViewModel coursesViewModel;
    private InstructorsViewModel instructorsViewModel;
    private AssessmentViewModel assessmentViewModel;
    private AlarmManager alarmManager;

    private Course course;
    private Term parentTerm;

    private String courseTitle;
    private long courseId;
    private Date courseStart;
    private Date courseEnd;
    private String courseStatus;

    private boolean fiveMinAlertStart;
    private boolean fifteenMinAlertStart;
    private boolean thirtyMinAlertStart;
    private boolean oneHourAlertStart;
    private boolean sixHourAlertStart;
    private boolean twelveHourAlertStart;
    private boolean oneDayAlertStart;
    private boolean twoDayAlertStart;
    private boolean oneWeekAlertStart;
    private boolean twoWeekAlertStart;
    private boolean oneMonthAlertStart;

    private boolean fiveMinAlertEnd;
    private boolean fifteenMinAlertEnd;
    private boolean thirtyMinAlertEnd;
    private boolean oneHourAlertEnd;
    private boolean sixHourAlertEnd;
    private boolean twelveHourAlertEnd;
    private boolean oneDayAlertEnd;
    private boolean twoDayAlertEnd;
    private boolean oneWeekAlertEnd;
    private boolean twoWeekAlertEnd;
    private boolean oneMonthAlertEnd;

    private TextView parentTermText;
    private EditText editCourseTitle;
    private RadioGroup courseStatusRadioGroup;

    private TextView startDateText;
    private TextView endDateText;

    private RecyclerView notesRecyclerView;

    public CourseDetailsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_course_details, container, false);
        coursesViewModel = ViewModelProviders.of(getActivity()).get(CoursesViewModel.class);
        TermsViewModel termsViewModel = ViewModelProviders.of(getActivity()).get(TermsViewModel.class);
        instructorsViewModel = ViewModelProviders.of(getActivity()).get(InstructorsViewModel.class);
        assessmentViewModel = ViewModelProviders.of(getActivity()).get(AssessmentViewModel.class);
        alarmManager = (AlarmManager) getActivity().getSystemService(Context.ALARM_SERVICE);

        assessmentViewModel.resetSelectedAssessments();
        instructorsViewModel.resetSelectedInstructorsList();

        course = coursesViewModel.getSelectedCourse();
        long parentTermId = course.getTermOwnerId();
        parentTerm = termsViewModel.getTermById(parentTermId);

        courseTitle = course.getTitle();
        courseId = course.getCourseId();
        courseStart = course.getStart();
        courseEnd = course.getEnd();
        courseStatus = course.getStatus();
        List<String> courseNotes = course.getNotes();

        TextView courseIdText = root.findViewById(R.id.course_details_id_text);
        courseIdText.setText("Course ID: " + courseId);

        Button deleteCourseBtn = root.findViewById(R.id.course_details_delete_btn);
        deleteCourseBtn.setOnClickListener(view -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setMessage("Are you sure you want to delete this Course?");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    coursesViewModel.deleteCourse(course);
                    Navigation.findNavController(root).navigate(R.id.action_courseDetailsFragment_to_coursesFragment);
                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.dismiss();
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        });

        parentTermText = root.findViewById(R.id.course_details_parent_term_text);
        if (parentTerm != null) {
            parentTermText.setText("Parent Term: " + parentTerm.getTitle());
        }
        editCourseTitle = root.findViewById(R.id.course_details_edit_text_course_title);
        editCourseTitle.setText(courseTitle);

        courseStatusRadioGroup = root.findViewById(R.id.course_details_status_radio_group);
        RadioButton inProgressRadio = root.findViewById(R.id.course_details_radio_in_progress);
        RadioButton completedRadio = root.findViewById(R.id.course_details_radio_completed);
        RadioButton droppedRadio = root.findViewById(R.id.course_details_radio_dropped);
        RadioButton planToTakeRadio = root.findViewById(R.id.course_details_radio_plan_to_take);

        switch (courseStatus) {
            case "In Progress":
                courseStatusRadioGroup.check(inProgressRadio.getId());
                break;
            case "Completed":
                courseStatusRadioGroup.check(completedRadio.getId());
                break;
            case "Dropped":
                courseStatusRadioGroup.check(droppedRadio.getId());
                break;
            default:
                courseStatusRadioGroup.check(planToTakeRadio.getId());
                break;
        }

        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
        startDateText = root.findViewById(R.id.course_details_start_date_text);
        startDateText.setText("Course Start Date: " + sdf.format(courseStart));
        endDateText = root.findViewById(R.id.course_details_end_date_text);
        endDateText.setText("Course End Date: " + sdf.format(courseEnd));

        Button setParentTermBtn = root.findViewById(R.id.course_details_set_parent_term_btn);
        setParentTermBtn.setOnClickListener(view -> {
            SetParentTermAdapter setParentTermAdapter;
            RecyclerView setParentRecyclerView;
            RecyclerView.LayoutManager layoutManager;
            TermsViewModel termsViewModel1;

            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.set_parent_term);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);

            Button cancelBtn = dialog.findViewById(R.id.set_parent_term_cancel_btn);
            cancelBtn.setOnClickListener(view1 -> dialog.dismiss());

            setParentTermAdapter = new SetParentTermAdapter(new SetParentTermAdapter.TermDiff(), getActivity(), dialog);
            layoutManager = new LinearLayoutManager(dialog.getContext());
            termsViewModel1 = ViewModelProviders.of(getActivity()).get(TermsViewModel.class);

            setParentRecyclerView = dialog.findViewById(R.id.recycler_view_parent_terms);
            setParentRecyclerView.setAdapter(setParentTermAdapter);
            setParentRecyclerView.setLayoutManager(layoutManager);

            termsViewModel1.getTermsLive().observe(getViewLifecycleOwner(), setParentTermAdapter::submitList);

            setParentTermAdapter.notifyDataSetChanged();
            dialog.show();
            dialog.setOnDismissListener( data -> {
                parentTerm = coursesViewModel.getParentTerm();
                if (parentTerm != null) {
                    parentTermText.setText("Parent Term: " + parentTerm.getTitle());
                }
            });
        });

        Button updateStartDateBtn = root.findViewById(R.id.course_details_add_start_btn);
        updateStartDateBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.datepicker);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.show();

            DatePicker datePicker = dialog.findViewById(R.id.datePicker);
            SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());

            String startDateString = sdf1.format(courseStart);
            String[] dateArr = startDateString.split("-");
            int day = Integer.parseInt(dateArr[0]);
            int month = Integer.parseInt(dateArr[1])-1;
            int year = Integer.parseInt(dateArr[2]);

            datePicker.updateDate(year, month, day);

            Button addDateBtn = dialog.findViewById(R.id.btn_datepicker_add);
            Button cancelDateBtn = dialog.findViewById(R.id.btn_datepicker_cancel);

            addDateBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int   day  = datePicker.getDayOfMonth();
                    int   month= datePicker.getMonth();
                    int   year = datePicker.getYear();
                    Calendar calendar = Calendar.getInstance();
                    calendar.set(year, month, day);

                    SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                    String formattedDate = sdf1.format(calendar.getTime());
                    try {
                        Date date = sdf1.parse(formattedDate);
                        courseStart = date;
                        sdf1 = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
                        formattedDate = sdf1.format(calendar.getTime());
                        startDateText.setText("Course Start Date: " + formattedDate);
                    } catch (ParseException e) {
                        courseStart = new Date();
                        e.printStackTrace();
                    }
                    dialog.dismiss();
                }
            });

            cancelDateBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dialog.dismiss();
                }
            });
        });

        Button updateEndDateBtn = root.findViewById(R.id.course_details_add_end_btn);
        updateEndDateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(getContext());
                dialog.setContentView(R.layout.datepicker);
                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setLayout(width, height);
                dialog.show();

                DatePicker datePicker = dialog.findViewById(R.id.datePicker);

                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());

                String endDateString = sdf.format(courseEnd);
                String[] dateArr = endDateString.split("-");
                int day = Integer.parseInt(dateArr[0]);
                int month = Integer.parseInt(dateArr[1])-1;
                int year = Integer.parseInt(dateArr[2]);
                datePicker.updateDate(year, month, day);

                Button addDateBtn = dialog.findViewById(R.id.btn_datepicker_add);
                Button cancelDateBtn = dialog.findViewById(R.id.btn_datepicker_cancel);

                addDateBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        int day  = datePicker.getDayOfMonth();
                        int month= datePicker.getMonth();
                        int year = datePicker.getYear();

                        Calendar calendar = Calendar.getInstance();
                        calendar.set(year, month, day);

                        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                        String formattedDate = sdf.format(calendar.getTime());
                        try {
                            Date date = sdf.parse(formattedDate);
                            courseEnd = date;
                            sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
                            formattedDate = sdf.format(calendar.getTime());
                            endDateText.setText("Course End Date: " + formattedDate);
                        } catch (ParseException e) {
                            courseEnd = new Date();
                            e.printStackTrace();
                        }
                        dialog.dismiss();
                    }
                });

                cancelDateBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
            }
        });

        Button setAlertsBtn = root.findViewById(R.id.course_details_set_alerts_btn);
        setAlertsBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.add_alerts);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);

            fiveMinAlertStart = course.isFiveMinAlertStart();
            fifteenMinAlertStart = course.isFifteenMinAlertStart();
            thirtyMinAlertStart = course.isThirtyMinAlertStart();
            oneHourAlertStart = course.isOneHourAlertStart();
            sixHourAlertStart = course.isSixHourAlertStart();
            twelveHourAlertStart = course.isTwelveHourAlertStart();
            oneDayAlertStart = course.isOneDayAlertStart();
            twoDayAlertStart = course.isTwoDayAlertStart();
            oneWeekAlertStart = course.isOneWeekAlertStart();
            twoWeekAlertStart = course.isTwoWeekAlertStart();
            oneMonthAlertStart = course.isOneMonthAlertStart();

            fiveMinAlertEnd = course.isFiveMinAlertEnd();
            fifteenMinAlertEnd = course.isFifteenMinAlertEnd();
            thirtyMinAlertEnd = course.isThirtyMinAlertEnd();
            oneHourAlertEnd = course.isOneHourAlertEnd();
            sixHourAlertEnd = course.isSixHourAlertEnd();
            twelveHourAlertEnd = course.isTwelveHourAlertEnd();
            oneDayAlertEnd = course.isOneDayAlertEnd();
            twoDayAlertEnd = course.isTwoDayAlertEnd();
            oneWeekAlertEnd = course.isOneWeekAlertEnd();
            twoWeekAlertEnd = course.isTwoWeekAlertEnd();
            oneMonthAlertEnd = course.isOneMonthAlertEnd();

            SwitchCompat fiveMinSwitchStart = dialog.findViewById(R.id.add_alert_5min_switch);
            SwitchCompat fifteenMinSwitchStart = dialog.findViewById(R.id.add_alert_15min_switch);
            SwitchCompat thirtyMinSwitchStart = dialog.findViewById(R.id.add_alert_30min_switch);
            SwitchCompat oneHourSwitchStart = dialog.findViewById(R.id.add_alert_1hour_switch);
            SwitchCompat sixHoursSwitchStart = dialog.findViewById(R.id.add_alert_6hours_switch);
            SwitchCompat twelveHoursSwitchStart = dialog.findViewById(R.id.add_alert_12hours_switch);
            SwitchCompat oneDaySwitchStart = dialog.findViewById(R.id.add_alert_1day_switch);
            SwitchCompat twoDaysSwitchStart = dialog.findViewById(R.id.add_alert_2days_switch);
            SwitchCompat oneWeekSwitchStart = dialog.findViewById(R.id.add_alert_1week_switch);
            SwitchCompat twoWeeksSwitchStart = dialog.findViewById(R.id.add_alert_2weeks_switch);
            SwitchCompat oneMonthSwitchStart = dialog.findViewById(R.id.add_alert_1month_switch);

            SwitchCompat fiveMinSwitchEnd = dialog.findViewById(R.id.add_alert_5min_switch2);
            SwitchCompat fifteenMinSwitchEnd = dialog.findViewById(R.id.add_alert_15min_switch2);
            SwitchCompat thirtyMinSwitchEnd = dialog.findViewById(R.id.add_alert_30min_switch2);
            SwitchCompat oneHourSwitchEnd = dialog.findViewById(R.id.add_alert_1hour_switch2);
            SwitchCompat sixHoursSwitchEnd = dialog.findViewById(R.id.add_alert_6hours_switch2);
            SwitchCompat twelveHoursSwitchEnd = dialog.findViewById(R.id.add_alert_12hours_switch2);
            SwitchCompat oneDaySwitchEnd = dialog.findViewById(R.id.add_alert_1day_switch2);
            SwitchCompat twoDaysSwitchEnd = dialog.findViewById(R.id.add_alert_2days_switch2);
            SwitchCompat oneWeekSwitchEnd = dialog.findViewById(R.id.add_alert_1week_switch2);
            SwitchCompat twoWeeksSwitchEnd = dialog.findViewById(R.id.add_alert_2weeks_switch2);
            SwitchCompat oneMonthSwitchEnd = dialog.findViewById(R.id.add_alert_1month_switch2);
            
            
            Button cancelBtn = dialog.findViewById(R.id.add_alert_cancel_btn);
            Button saveBtn = dialog.findViewById(R.id.add_alert_save_alerts_btn);

            if (fiveMinAlertStart) {
                fiveMinSwitchStart.setChecked(true);
            }
            if (fifteenMinAlertStart) {
                fifteenMinSwitchStart.setChecked(true);
            }
            if (thirtyMinAlertStart) {
                thirtyMinSwitchStart.setChecked(true);
            }
            if (oneHourAlertStart) {
                oneHourSwitchStart.setChecked(true);
            }
            if (sixHourAlertStart) {
                sixHoursSwitchStart.setChecked(true);
            }
            if (twelveHourAlertStart) {
                twelveHoursSwitchStart.setChecked(true);
            }
            if (oneDayAlertStart) {
                oneDaySwitchStart.setChecked(true);
            }
            if (twoDayAlertStart) {
                twoDaysSwitchStart.setChecked(true);
            }
            if (oneWeekAlertStart) {
                oneWeekSwitchStart.setChecked(true);
            }
            if (twoWeekAlertStart) {
                twoWeeksSwitchStart.setChecked(true);
            }
            if (oneMonthAlertStart) {
                oneMonthSwitchStart.setChecked(true);
            }

            if (fiveMinAlertEnd) {
                fiveMinSwitchEnd.setChecked(true);
            }
            if (fifteenMinAlertEnd) {
                fifteenMinSwitchEnd.setChecked(true);
            }
            if (thirtyMinAlertEnd) {
                thirtyMinSwitchEnd.setChecked(true);
            }
            if (oneHourAlertEnd) {
                oneHourSwitchEnd.setChecked(true);
            }
            if (sixHourAlertEnd) {
                sixHoursSwitchEnd.setChecked(true);
            }
            if (twelveHourAlertEnd) {
                twelveHoursSwitchEnd.setChecked(true);
            }
            if (oneDayAlertEnd) {
                oneDaySwitchEnd.setChecked(true);
            }
            if (twoDayAlertEnd) {
                twoDaysSwitchEnd.setChecked(true);
            }
            if (oneWeekAlertEnd) {
                oneWeekSwitchEnd.setChecked(true);
            }
            if (twoWeekAlertEnd) {
                twoWeeksSwitchEnd.setChecked(true);
            }
            if (oneMonthAlertEnd) {
                oneMonthSwitchEnd.setChecked(true);
            }

            saveBtn.setOnClickListener(view1 -> {
                Boolean checked = false;
                Long courseID = courseId;
                int courseid = courseID.intValue();

                if (fiveMinSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 5*60*1000;
                    long notificationTime = courseStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle( courseTitle );
                    builder.setContentText(courseTitle + " begins in five minutes.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 1 );
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+111, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT ) ;
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setFiveMinAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+111, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setFiveMinAlertStart(false);
                }

                if (fifteenMinSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 15*60*1000;
                    long notificationTime = courseStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(courseTitle);
                    builder.setContentText(courseTitle + " begins in 15 minutes.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID );
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID, 2);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION, notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+112, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setFifteenMinAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+112, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setFifteenMinAlertStart(false);
                }

                if (thirtyMinSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 30*60*1000;
                    long notificationTime = courseStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(courseTitle);
                    builder.setContentText(courseTitle + " begins in 30 minutes.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 3);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+113, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setThirtyMinAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+113, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setThirtyMinAlertStart(false);
                }

                if (oneHourSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 60*60*1000;
                    long notificationTime = courseStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(courseTitle);
                    builder.setContentText(courseTitle + " begins in one hour.");
                    builder.setSmallIcon(R.drawable. ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 4);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+114, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setOneHourAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+114, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setOneHourAlertStart(false);
                }

                if (sixHoursSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 6*60*60*1000;
                    long notificationTime = courseStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(courseTitle);
                    builder.setContentText(courseTitle + " begins in six hours.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID );
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 5);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+115, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setSixHourAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+115, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setSixHourAlertStart(false);
                }

                if (twelveHoursSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 12*60*60*1000;
                    long notificationTime = courseStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(courseTitle);
                    builder.setContentText(courseTitle + " begins in twelve hours.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 6);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+116, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setTwelveHourAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+116, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setTwelveHourAlertStart(false);
                }

                if (oneDaySwitchStart.isChecked()) {
                    checked = true;
                    long millis = 24*60*60*1000;
                    long notificationTime = courseStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default" );
                    builder.setContentTitle(courseTitle);
                    builder.setContentText(courseTitle + " begins in one day.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 7);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+117, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setOneDayAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+117, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setOneDayAlertStart(false);
                }

                if (twoDaysSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 48*60*60*1000;
                    long notificationTime = courseStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(courseTitle);
                    builder.setContentText(courseTitle + " begins in two days.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 8);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+118, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setTwoDayAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+118, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setTwoDayAlertStart(false);
                }

                if (oneWeekSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 7*24*60*60*1000;
                    long notificationTime = courseStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle( courseTitle );
                    builder.setContentText(courseTitle + " begins in one week.");
                    builder.setSmallIcon(R.drawable. ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 9);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+119, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setOneWeekAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+119, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setOneWeekAlertStart(false);
                }

                if (twoWeeksSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 14*24*60*60*1000;
                    long notificationTime = courseStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default" );
                    builder.setContentTitle( courseTitle );
                    builder.setContentText(courseTitle + " begins in two weeks.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build() ;

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 10);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+1110, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setTwoWeekAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+1110, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setTwoWeekAlertStart(false);
                }

                if (oneMonthSwitchStart.isChecked()) {
                    checked = true;
                    long weekMillis = 7*24*60*60*1000;
                    long monthMillis = weekMillis*4;
                    long notificationTime = courseStart.getTime() - monthMillis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(courseTitle);
                    builder.setContentText(courseTitle + " begins in 1 month.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 11);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+1111, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setOneMonthAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+1111, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setOneMonthAlertStart(false);
                }
                
                // ending alerts
                if (fiveMinSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 5*60*1000;
                    long notificationTime = courseEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle( courseTitle );
                    builder.setContentText(courseTitle + " ends in five minutes.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 1 );
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+121, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT ) ;
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setFiveMinAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+121, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setFiveMinAlertEnd(false);
                }

                if (fifteenMinSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 15*60*1000;
                    long notificationTime = courseEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(courseTitle);
                    builder.setContentText(courseTitle + " ends in 15 minutes.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID );
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID, 2);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION, notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+122, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setFifteenMinAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+122, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setFifteenMinAlertEnd(false);
                }

                if (thirtyMinSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 30*60*1000;
                    long notificationTime = courseEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(courseTitle);
                    builder.setContentText(courseTitle + " ends in 30 minutes. The start date is " + startDateText.getText());
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 3);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+123, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setThirtyMinAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+123, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setThirtyMinAlertEnd(false);
                }

                if (oneHourSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 60*60*1000;
                    long notificationTime = courseEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(courseTitle);
                    builder.setContentText(courseTitle + " ends in one hour.");
                    builder.setSmallIcon(R.drawable. ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 4);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+124, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setOneHourAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+124, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setOneHourAlertEnd(false);
                }

                if (sixHoursSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 6*60*60*1000;
                    long notificationTime = courseEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(courseTitle);
                    builder.setContentText(courseTitle + " ends in six hours.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID );
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 5);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+125, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setSixHourAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+125, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setSixHourAlertEnd(false);
                }

                if (twelveHoursSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 12*60*60*1000;
                    long notificationTime = courseEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(courseTitle);
                    builder.setContentText(courseTitle + " ends in twelve hours.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 6);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+126, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setTwelveHourAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+126, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setTwelveHourAlertEnd(false);
                }

                if (oneDaySwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 24*60*60*1000;
                    long notificationTime = courseEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default" );
                    builder.setContentTitle(courseTitle);
                    builder.setContentText(courseTitle + " ends in one day.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 7);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+127, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setOneDayAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+127, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setOneDayAlertEnd(false);
                }

                if (twoDaysSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 48*60*60*1000;
                    long notificationTime = courseEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(courseTitle);
                    builder.setContentText(courseTitle + " ends in two days.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 8);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+128, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setTwoDayAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+128, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setTwoDayAlertEnd(false);
                }

                if (oneWeekSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 7*24*60*60*1000;
                    long notificationTime = courseEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle( courseTitle );
                    builder.setContentText(courseTitle + " ends in one week.");
                    builder.setSmallIcon(R.drawable. ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 9);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+129, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setOneWeekAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+129, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setOneWeekAlertEnd(false);
                }

                if (twoWeeksSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 14*24*60*60*1000;
                    long notificationTime = courseEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default" );
                    builder.setContentTitle( courseTitle );
                    builder.setContentText(courseTitle + " ends in two weeks.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build() ;

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 10);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+1210, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setTwoWeekAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+1210, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setTwoWeekAlertEnd(false);
                }

                if (oneMonthSwitchEnd.isChecked()) {
                    checked = true;
                    long weekMillis = 7*24*60*60*1000;
                    long monthMillis = weekMillis*4;
                    long notificationTime = courseEnd.getTime() - monthMillis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(courseTitle);
                    builder.setContentText(courseTitle + " ends in 1 month.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 11);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), courseid+1211, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    course.setOneMonthAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), courseid+1211, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    course.setOneMonthAlertEnd(false);
                }

                if (checked) {
                    CharSequence text = "Notification(s) set.";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(root.getContext(), text, duration);
                    toast.show();
                } else {
                    CharSequence text = "All notifications disabled.";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(root.getContext(), text, duration);
                    toast.show();
                }
                dialog.dismiss();
            });

            cancelBtn.setOnClickListener(view1 -> dialog.dismiss());

            dialog.show();
        });

// INSTRUCTORS
        RecyclerView instructorsRecyclerView = root.findViewById(R.id.course_details_instructors_recycler_view);
        CourseInstructorsAdapter courseInstructorsAdapter = new CourseInstructorsAdapter(new CourseInstructorsAdapter.InstructorDiff(), getActivity());
        instructorsRecyclerView.setAdapter(courseInstructorsAdapter);
        RecyclerView.LayoutManager instructorsLayoutManager = new LinearLayoutManager(getContext());
        instructorsRecyclerView.setLayoutManager(instructorsLayoutManager);

        instructorsViewModel.getInstructorsLive().observe(getViewLifecycleOwner(), instructors -> {
            ArrayList<Instructor> courseInstructors = new ArrayList<>();
            instructors.forEach(instructor -> {
                if (instructor.getCourseIds().contains(courseId)) {
                    courseInstructors.add(instructor);
                }
            });
            courseInstructorsAdapter.submitList(courseInstructors);
        });

        Button removeInstructorsBtn = root.findViewById(R.id.course_details_remove_instructors_btn);
        removeInstructorsBtn.setOnClickListener(view -> {
            ArrayList<Instructor> selectedInstructors = instructorsViewModel.getSelectedInstructors();
            if (selectedInstructors.size() <= 0) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "No Instructors selected.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            selectedInstructors.forEach(instructor -> instructor.removeCourseId(courseId));
            instructorsViewModel.resetSelectedInstructorsList();
            instructorsViewModel.getInstructorsLive().observe(getViewLifecycleOwner(), instructors -> {
                ArrayList<Instructor> courseInstructors = new ArrayList<>();
                instructors.forEach(instructor -> {
                    if (instructor.getCourseIds().contains(courseId)) {
                        courseInstructors.add(instructor);
                    }
                });
                courseInstructorsAdapter.submitList(courseInstructors);
            });
        });

        Button viewInstructorDetailsBtn = root.findViewById(R.id.course_details_view_instructor_information);
        viewInstructorDetailsBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.view_instructor_details);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);

            Button backBtn = dialog.findViewById(R.id.view_instructor_details_back_btn);

            backBtn.setOnClickListener(view1 -> dialog.dismiss());

            RecyclerView instructorDetailsRecyclerView = dialog.findViewById(R.id.view_instructor_details_recycler_view);
            InstructorDetailsAdapter instructorDetailsAdapter = new InstructorDetailsAdapter(new InstructorDetailsAdapter.InstructorDiff(), getActivity());
            RecyclerView.LayoutManager instructorDetailsLayoutManager = new LinearLayoutManager(getContext());
            instructorDetailsRecyclerView.setAdapter(instructorDetailsAdapter);
            instructorDetailsRecyclerView.setLayoutManager(instructorDetailsLayoutManager);
            instructorsViewModel.getInstructorsLive().observe(getViewLifecycleOwner(), instructors -> {
                ArrayList<Instructor> courseInstructors = new ArrayList<>();
                instructors.forEach(instructor -> {
                    if (instructor.getCourseIds().contains(courseId)) {
                        courseInstructors.add(instructor);
                    }
                });
                instructorDetailsAdapter.submitList(courseInstructors);
            });
            dialog.show();

        });

        Button addInstructorBtn = root.findViewById(R.id.course_details_add_instructors_btn);
        addInstructorBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.add_instructor_to_course);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);

            RecyclerView addInstructorsRecyclerView = dialog.findViewById(R.id.recycler_view_add_assessments_to_course);
            AddInstructorToCourseAdapter addInstructorToCourseAdapter = new AddInstructorToCourseAdapter(new AddInstructorToCourseAdapter.InstructorDiff(), getActivity());
            RecyclerView.LayoutManager addInstructorLayoutManager = new LinearLayoutManager(getContext());
            addInstructorsRecyclerView.setAdapter(addInstructorToCourseAdapter);
            addInstructorsRecyclerView.setLayoutManager(addInstructorLayoutManager);

            instructorsViewModel.getInstructorsLive().observe(getViewLifecycleOwner(), addInstructorToCourseAdapter::submitList);

            Button addSelectedInstructorsBtn = dialog.findViewById(R.id.add_selected_assessments_to_cours_btn);
            Button cancelSelectedInstructorsBtn = dialog.findViewById(R.id.add_assessments_to_course_cancel_btn);
            Button createNewInstructorBtn = dialog.findViewById(R.id.create_new_instructor_btn);
            Button deleteSelectedInstructorsBtn = dialog.findViewById(R.id.delete_instructors_btn);

            deleteSelectedInstructorsBtn.setOnClickListener(view1 -> {
                ArrayList<Instructor> selectedInstructors = instructorsViewModel.getSelectedInstructors();
                for (int x = 0; x < selectedInstructors.size(); x++) {
                    if (selectedInstructors.get(x).getCourseIds().size() > 0) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setMessage("One or more of the selected Instructors are assigned to Courses, are you sure you want to delete them?");
                        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                instructorsViewModel.deleteList(selectedInstructors);
                                instructorsViewModel.resetSelectedInstructorsList();
                            }
                        });
                        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                            }
                        });
                        AlertDialog dialog1 = builder.create();
                        dialog1.show();
                        return;
                    }
                }
                instructorsViewModel.deleteList(selectedInstructors);
                instructorsViewModel.resetSelectedInstructorsList();
                dialog.dismiss();

            });

            createNewInstructorBtn.setOnClickListener(view1 -> {
                Dialog dialog1 = new Dialog(getContext());
                dialog1.setContentView(R.layout.create_new_instructor);
                int width1 = WindowManager.LayoutParams.MATCH_PARENT;
                int height1 = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog1.getWindow().setLayout(width1, height1);

                EditText firstNameEdit = dialog1.findViewById(R.id.create_new_instructor_first_name_edit_text);
                EditText lastNameEdit = dialog1.findViewById(R.id.create_new_instructor_last_name_edit_text);
                EditText emailEdit = dialog1.findViewById(R.id.create_new_instructor_email_edit_text);
                EditText phoneEdit = dialog1.findViewById(R.id.create_new_instructor_phone_edit_text);
                Button createNewInstructorCancelBtn = dialog1.findViewById(R.id.create_new_instructor_cancel_btn);
                Button createNewInstructorSaveBtn = dialog1.findViewById(R.id.create_new_instructor_save_btn);

                createNewInstructorCancelBtn.setOnClickListener(view2 -> dialog1.dismiss());

                createNewInstructorSaveBtn.setOnClickListener(view2 -> {
                    String firstName = firstNameEdit.getText().toString().trim();
                    String lastName = lastNameEdit.getText().toString().trim();
                    String email = emailEdit.getText().toString().trim();
                    String phone = phoneEdit.getText().toString().trim();

                    Instructor newInstructor = new Instructor(firstName, lastName, email, phone);
                    instructorsViewModel.createInstructor(newInstructor);
                    dialog1.dismiss();
                });

                dialog1.show();
            });

            addSelectedInstructorsBtn.setOnClickListener(view1 -> {
                ArrayList<Instructor> selectedInstructors = instructorsViewModel.getSelectedInstructors();
                if (selectedInstructors.size() == 0){
                    Context context = view.getContext().getApplicationContext();
                    CharSequence text = "No Instructors selected.";
                    int duration = Toast.LENGTH_LONG;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    return;
                }
                selectedInstructors.forEach(instructor -> {
                    instructor.addCourseId(courseId);
                    instructorsViewModel.updateInstructor(instructor);
                });
                instructorsViewModel.resetSelectedInstructorsList();
                dialog.dismiss();
            });

            cancelSelectedInstructorsBtn.setOnClickListener(view1 -> {
                instructorsViewModel.resetSelectedInstructorsList();
                dialog.dismiss();
            });

            dialog.show();
        });


// NOTES
        notesRecyclerView = root.findViewById(R.id.course_details_notes_recycler_view);
        CourseNotesAdapter courseNotesAdapter = new CourseNotesAdapter(new CourseNotesAdapter.NoteDiff(), getActivity());
        notesRecyclerView.setAdapter(courseNotesAdapter);
        RecyclerView.LayoutManager notesLayoutManager = new LinearLayoutManager(getContext());
        notesRecyclerView.setLayoutManager(notesLayoutManager);

//        coursesViewModel.getNotesByCourseIdLive(course.getCourseId()).observe(getViewLifecycleOwner(), notes -> {
//            courseNotesAdapter.submitList(notes);
//        });
        courseNotesAdapter.submitList(courseNotes);

        Button removeNotesBtn = root.findViewById(R.id.course_details_remove_notes_btn);
        removeNotesBtn.setOnClickListener(view -> {
            ArrayList<String> notes = coursesViewModel.getSelectedNotes();
            if (notes.size() <= 0) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "No Notes selected.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            List<String> existingNotes = course.getNotes();
            List<String> newNotes = new ArrayList<>();
            existingNotes.forEach(note -> {
                if (!notes.contains(note)) {
                    newNotes.add(note);
                }
            });
            course.setNotes(newNotes);
            coursesViewModel.updateCourse(course);
            courseNotesAdapter.submitList(newNotes);
            courseNotesAdapter.notifyDataSetChanged();
        });

        Button addNoteBtn = root.findViewById(R.id.course_details_add_note_btn);
        addNoteBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.add_note_to_course);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            EditText editNote = dialog.findViewById(R.id.add_note_to_course_edit_note);
            Button addBtn = dialog.findViewById(R.id.add_note_to_course_add_btn);
            Button cancelBtn = dialog.findViewById(R.id.add_note_to_course_cancel_btn);

            addBtn.setOnClickListener(view1 -> {
                String newNote = editNote.getText().toString().trim();
                if (newNote.isEmpty()){
                    Context context = view.getContext().getApplicationContext();
                    CharSequence text = "Note cannot be empty.";
                    int duration = Toast.LENGTH_LONG;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    return;
                }
                course.addNote(newNote);
                coursesViewModel.updateCourse(course);
                List<String> updatedNotes = course.getNotes();
                dialog.dismiss();
                courseNotesAdapter.submitList(updatedNotes);
                courseNotesAdapter.notifyItemInserted(updatedNotes.size()-1);
                courseNotesAdapter.notifyDataSetChanged();
                notesRecyclerView.scrollToPosition(updatedNotes.size()-1);
            });

            cancelBtn.setOnClickListener(view1 -> dialog.dismiss());
            dialog.show();
        });

        Button shareNotesBtn = root.findViewById(R.id.course_details_share_note_btn);
        shareNotesBtn.setOnClickListener(view -> {
            ArrayList<String> selectedNotes = coursesViewModel.getSelectedNotes();
            if (selectedNotes.size() <= 0) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "No Notes selected.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.share_note);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);

            EditText editRecipientNumber = dialog.findViewById(R.id.share_note_edit_phone);

            Button sendBtn = dialog.findViewById(R.id.share_note_send_btn);
            Button cancelBtn = dialog.findViewById(R.id.share_note_cancel_btn);

            cancelBtn.setOnClickListener(view1 -> dialog.dismiss());

            sendBtn.setOnClickListener(view1 -> {
                String recipientNumber = editRecipientNumber.getText().toString();
                selectedNotes.forEach(note -> {
                    MainActivity.SMS_RECIPIENT = recipientNumber;
                    MainActivity.SMS_CONTENT = note;
                    if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                        if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                            sendSms(recipientNumber, note);
                        } else {
                            ActivityCompat.requestPermissions(getActivity(),
                                    new String[]{Manifest.permission.SEND_SMS},
                                    200);
                        }
                    } else {
                        ActivityCompat.requestPermissions(getActivity(),
                                new String[]{Manifest.permission.READ_PHONE_STATE},
                                100);
                    }
                });
                dialog.dismiss();
            });
            dialog.show();
        });

        // ASSESSMENTS

        RecyclerView assessmentsRecyclerView = root.findViewById(R.id.course_details_assessment_recycler_view);
        CourseAssessmentsAdapter courseAssessmentsAdapter = new CourseAssessmentsAdapter(new CourseAssessmentsAdapter.AssessmentDiff(), getActivity());
        RecyclerView.LayoutManager courseAssessmentsLayoutManager = new LinearLayoutManager(getContext());
        assessmentsRecyclerView.setAdapter(courseAssessmentsAdapter);
        assessmentsRecyclerView.setLayoutManager(courseAssessmentsLayoutManager);

        assessmentViewModel.getAssessmentsByCourseOwnerLive(courseId).observe(getViewLifecycleOwner(), courseAssessmentsAdapter::submitList);

        Button removeAssessmentsBtn = root.findViewById(R.id.course_details_remove_assessments_btn);
        removeAssessmentsBtn.setOnClickListener(view -> {
            ArrayList<Assessment> selectedAssessments = assessmentViewModel.getSelectedAssessments();
            if (selectedAssessments.size() <= 0) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "No Assessments selected.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            selectedAssessments.forEach(assessment -> {
                assessment.setCourseOwnerId(0);
                assessmentViewModel.updateAssessment(assessment);
            });
            assessmentViewModel.resetSelectedAssessments();
        });


        Button addAssessmentBtn = root.findViewById(R.id.course_details_add_assessments_btn);
        addAssessmentBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.add_assessment_to_course);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);

            RecyclerView addAssessmentsToCourseRecyclerView = dialog.findViewById(R.id.recycler_view_add_assessments_to_course);
            Button cancelBtn = dialog.findViewById(R.id.add_assessments_to_course_cancel_btn);
            Button addSelectedAssessmentsBtn = dialog.findViewById(R.id.add_selected_assessments_to_cours_btn);

            CourseAssessmentsAdapter addAssessmentsToCourseAdapter = new CourseAssessmentsAdapter(new CourseAssessmentsAdapter.AssessmentDiff(), getActivity());
            RecyclerView.LayoutManager addAssessmentsToCourseLayoutManager = new LinearLayoutManager(getContext());

            addAssessmentsToCourseRecyclerView.setAdapter(addAssessmentsToCourseAdapter);
            addAssessmentsToCourseRecyclerView.setLayoutManager(addAssessmentsToCourseLayoutManager);

            assessmentViewModel.getAssessmentsLive().observe(getViewLifecycleOwner(), addAssessmentsToCourseAdapter::submitList);

            cancelBtn.setOnClickListener(view1 -> {
                assessmentViewModel.resetSelectedAssessments();
                dialog.dismiss();
            });

            addSelectedAssessmentsBtn.setOnClickListener(view1 -> {
                ArrayList<Assessment> selectedAssessments = assessmentViewModel.getSelectedAssessments();
                if (selectedAssessments.size() <= 0) {
                    Context context = view.getContext().getApplicationContext();
                    CharSequence text = "No Assessments selected.";
                    int duration = Toast.LENGTH_LONG;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    return;
                }
                int assessmentCount = selectedAssessments.size();
                for (int x = 0; x < assessmentCount; x++) {
                    long assessmentOwnerId = selectedAssessments.get(x).getCourseOwnerId();
                    if (assessmentOwnerId != 0 && assessmentOwnerId != courseId) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setMessage("One or more of the selected Assessments are assigned to another Course. Are you sure you want to reassign them?");
                        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog1, int id) {
                                selectedAssessments.forEach(assessment -> {
                                    assessment.setCourseOwnerId(courseId);
                                    assessmentViewModel.updateAssessment(assessment);
                                });
                                dialog1.dismiss();
                                dialog.dismiss();
                            }
                        });
                        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                            }
                        });
                        AlertDialog dialog1 = builder.create();
                        dialog1.show();
                        return;
                    }
                }
                selectedAssessments.forEach(assessment -> {
                    assessment.setCourseOwnerId(courseId);
                    assessmentViewModel.updateAssessment(assessment);
                });
                assessmentViewModel.resetSelectedAssessments();
                dialog.dismiss();
            });

            dialog.show();
        });

        // finalize
        Button updateCourseBtn = root.findViewById(R.id.course_details_add_course_btn);
        updateCourseBtn.setOnClickListener(view -> {
            courseTitle = editCourseTitle.getText().toString().trim();
            if (courseTitle.equals("") || courseTitle.isEmpty()) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Course Title is required.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            int courseStatusId = courseStatusRadioGroup.getCheckedRadioButtonId();
            if (courseStatusId == -1) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Course Status is required.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            RadioButton selectedBtn = root.findViewById(courseStatusId);
            courseStatus = selectedBtn.getText().toString();

            if (courseStart == null || courseEnd == null){
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Course Start and End dates are both required.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }

            if (courseStart.after(courseEnd)) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Course Start must be before Course End.";
                Toast toast = Toast.makeText(context, text, Toast.LENGTH_LONG);
                toast.show();
                return;
            }

            long courseParentTermId = 0;
            if (parentTerm != null) {
                courseParentTermId = parentTerm.getTermId();
            }
            course.setTitle(courseTitle);
            course.setTermOwnerId(courseParentTermId);
            if (!course.getStart().equals(courseStart)) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Course Start Date changed. Start Notifications reset.";
                resetStartNotifications();
                Toast toast = Toast.makeText(context, text, Toast.LENGTH_LONG);
                toast.show();
            }
            course.setStart(courseStart);
            if (!course.getEnd().equals(courseEnd)) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Course End Date changed. End Notifications reset.";
                resetEndNotifications();
                Toast toast = Toast.makeText(context, text, Toast.LENGTH_LONG);
                toast.show();
            }
            course.setEnd(courseEnd);
            course.setStatus(courseStatus);
            coursesViewModel.updateCourse(course);
            Navigation.findNavController(view).navigate(R.id.action_courseDetailsFragment_to_coursesFragment);
        });

        Button cancelBtn1 = root.findViewById(R.id.course_details_cancel_btn);
        cancelBtn1.setOnClickListener(view -> Navigation.findNavController(view).navigate(R.id.action_courseDetailsFragment_to_coursesFragment));

        return root;
    }

    private void resetStartNotifications() {
        Long courseID = courseId;
        int courseid = courseID.intValue();
        Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+111, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setFiveMinAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+112, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setFifteenMinAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+113, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setThirtyMinAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+114, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setOneHourAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+115, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setSixHourAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+116, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setTwelveHourAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+117, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setOneDayAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+118, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setTwoDayAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+119, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setOneWeekAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+1110, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setTwoWeekAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+1111, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setOneMonthAlertStart(false);
    }
    private void resetEndNotifications() {
        Long courseID = courseId;
        int courseid = courseID.intValue();
        Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+121, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setFiveMinAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+122, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setFifteenMinAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+123, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setThirtyMinAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+124, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setOneHourAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+125, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setSixHourAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+126, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setTwelveHourAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+127, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setOneDayAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+128, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setTwoDayAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+129, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setOneWeekAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+1210, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setTwoWeekAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), courseid+1211, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        course.setOneMonthAlertEnd(false);
    }

    private void sendSms(String recipientNumber, String note) {
        Log.d(TAG, recipientNumber + " " + note);
        try{
            SmsManager smgr = SmsManager.getDefault();
            smgr.sendTextMessage(recipientNumber,null,note,null,null);
            Toast.makeText(getContext(), "SMS Message(s) Sent Successfully", Toast.LENGTH_SHORT).show();
        }
        catch (Exception e){
            Log.e(TAG, e.getMessage() );
            Toast.makeText(getContext(), "SMS Failed to Send, Please try again", Toast.LENGTH_SHORT).show();
        }
    }
}