package com.wgu.wguscheduler;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.wgu.wguscheduler.packages.custom_events.CustomEvent;
import com.wgu.wguscheduler.packages.custom_events.CustomEventsViewModel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AddCustomEventActivity extends AppCompatActivity {
    private CustomEventsViewModel customEventsViewModel;
    private String customEventTitle;
    private String customEventType;
    private Date customEventStart;
    private Date customEventEnd;

    @Override
    protected void onCreate(@Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        super.onCreate(savedInstanceState);
        customEventsViewModel = new CustomEventsViewModel(this.getApplication());

        setContentView(R.layout.activity_new_custom_event);

        EditText editTitle = findViewById(R.id.scheduler_new_custom_event_edit_title);
        EditText editType = findViewById(R.id.scheduler_new_custom_event_edit_type);

        Button startBtn = findViewById(R.id.scheduler_new_custom_event_start_date_btn);
        TextView startDateText = findViewById(R.id.scheduler_add_new_custom_event_start_date_text);
        Button endBtn = findViewById(R.id.scheduler_new_custom_event_end_date_btn);
        TextView endDateText = findViewById(R.id.scheduler_add_new_custom_event_end_date_text);

        Button cancelBtn = findViewById(R.id.scheduler_new_custom_event_cancel);
        Button saveBtn = findViewById(R.id.scheduler_new_custom_event_save);

        startBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(this);
            dialog.setContentView(R.layout.datepicker);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.show();

            DatePicker datePicker = dialog.findViewById(R.id.datePicker);

            if (customEventStart != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String startDateString = sdf.format(customEventStart);
                String[] dateArr = startDateString.split("-");
                int day = Integer.parseInt(dateArr[0]);
                int month = Integer.parseInt(dateArr[1])-1;
                int year = Integer.parseInt(dateArr[2]);
                datePicker.updateDate(year, month, day);
            }

            Button addDateBtn = dialog.findViewById(R.id.btn_datepicker_add);
            Button cancelDateBtn = dialog.findViewById(R.id.btn_datepicker_cancel);

            addDateBtn.setOnClickListener(view1 -> {
                int day  = datePicker.getDayOfMonth();
                int month= datePicker.getMonth();
                int year = datePicker.getYear();
                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, day);

                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String formattedDate = sdf.format(calendar.getTime());
                try {
                    Date date = sdf.parse(formattedDate);
                    customEventStart = date;
                    sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
                    formattedDate = sdf.format(calendar.getTime());
                    startDateText.setText("Start Date: " + formattedDate);
                } catch (ParseException e) {
                    customEventStart = new Date();
                    e.printStackTrace();
                }
                dialog.dismiss();
            });

            cancelDateBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dialog.dismiss();
                }
            });
        });

        endBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(this);
            dialog.setContentView(R.layout.datepicker);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.show();

            DatePicker datePicker = dialog.findViewById(R.id.datePicker);

            if (customEventEnd != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String startDateString = sdf.format(customEventEnd);
                String[] dateArr = startDateString.split("-");
                int day = Integer.parseInt(dateArr[0]);
                int month = Integer.parseInt(dateArr[1])-1;
                int year = Integer.parseInt(dateArr[2]);
                datePicker.updateDate(year, month, day);
            }

            Button addDateBtn = dialog.findViewById(R.id.btn_datepicker_add);
            Button cancelDateBtn = dialog.findViewById(R.id.btn_datepicker_cancel);

            addDateBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int day  = datePicker.getDayOfMonth();
                    int month= datePicker.getMonth();
                    int year = datePicker.getYear();
                    Calendar calendar = Calendar.getInstance();
                    calendar.set(year, month, day);

                    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                    String formattedDate = sdf.format(calendar.getTime());
                    try {
                        Date date = sdf.parse(formattedDate);
                        customEventEnd = date;
                        sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
                        formattedDate = sdf.format(calendar.getTime());
                        endDateText.setText("End Date: " + formattedDate);
                    } catch (ParseException e) {
                        customEventEnd = new Date();
                        e.printStackTrace();
                    }
                    dialog.dismiss();
                }
            });

            cancelDateBtn.setOnClickListener(view1 -> dialog.dismiss());
        });

        saveBtn.setOnClickListener(view -> {
            customEventTitle = editTitle.getText().toString().trim();
            if (customEventTitle.equals("") || customEventTitle.isEmpty()) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Title is required.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            customEventType = editType.getText().toString().trim();
            if (customEventType.equals("") || customEventType.isEmpty()) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Type is required.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            if (customEventStart == null || customEventEnd == null){
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Event Start and End dates are both required.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }

            if (customEventStart.after(customEventEnd)) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Event Start must be before Course End.";
                Toast toast = Toast.makeText(context, text, Toast.LENGTH_LONG);
                toast.show();
                return;
            }
            CustomEvent newCustomEvent = new CustomEvent(customEventTitle, customEventType, customEventStart, customEventEnd);
            customEventsViewModel.addCustomEvent(newCustomEvent);
            Intent intent = new Intent(this, SchedulerActivity.class);
            startActivity(intent);
        });

        cancelBtn.setOnClickListener(view -> {
            Intent intent = new Intent(this, SchedulerActivity.class);
            startActivity(intent);
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
