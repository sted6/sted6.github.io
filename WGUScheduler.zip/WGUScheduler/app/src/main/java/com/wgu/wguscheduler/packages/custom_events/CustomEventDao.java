package com.wgu.wguscheduler.packages.custom_events;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.ArrayList;
import java.util.List;

import static androidx.room.OnConflictStrategy.REPLACE;

@Dao
public interface CustomEventDao {
    @Insert(onConflict = REPLACE)
    long insert(CustomEvent customEvent);

    @Delete
    void delete(CustomEvent customEvent);

    @Update
    void update(CustomEvent customEvent);

    @Query("SELECT * FROM customevent")
    LiveData<List<CustomEvent>> getCustomEventsLive();

}
