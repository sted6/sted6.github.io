package com.wgu.wguscheduler.packages.instructors;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.wgu.wguscheduler.R;

import org.jetbrains.annotations.NotNull;

public class CourseInstructorsAdapter extends ListAdapter<Instructor, CourseInstructorsAdapter.InstructorViewHolder> {
    private final Activity context;
    public CourseInstructorsAdapter(@NonNull @NotNull DiffUtil.ItemCallback<Instructor> diffCallback, Activity context) {
        super(diffCallback);
        this.context = context;
    }

    @NonNull @NotNull @Override
    public CourseInstructorsAdapter.InstructorViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return CourseInstructorsAdapter.InstructorViewHolder.create(parent);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull CourseInstructorsAdapter.InstructorViewHolder holder, int position) {
        Instructor instructor = getItem(position);
        holder.bind(instructor, context);
    }

    public static class InstructorDiff extends DiffUtil.ItemCallback<Instructor> {
        @Override
        public boolean areItemsTheSame(@NonNull @NotNull Instructor oldItem, @NonNull @NotNull Instructor newItem) {
            return oldItem == newItem;
        }

        @Override
        public boolean areContentsTheSame(@NonNull @NotNull Instructor oldItem, @NonNull @NotNull Instructor newItem) {
            return oldItem.getInstructorId() == (newItem.getInstructorId());
        }
    }


    public static class InstructorViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        CheckBox checkbox;
        InstructorsViewModel instructorsViewModel;

        public InstructorViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.child_text);
            checkbox = itemView.findViewById(R.id.child_checkbox);
        }


        public void bind(Instructor instructor, Activity context) {
            instructorsViewModel = ViewModelProviders.of((FragmentActivity)context).get(InstructorsViewModel.class);
            textView.setText(instructor.getFirstName() + " " + instructor.getLastName());
            checkbox.setChecked(false);
            instructorsViewModel.resetSelectedInstructorsList();
            checkbox.setOnClickListener(view -> {
                if (checkbox.isChecked()) {
                    instructorsViewModel.addInstructorToSelectedList(instructor);
                } else {
                    instructorsViewModel.removeInstructorFromSelectedList(instructor);
                }
            });
        }

        public static CourseInstructorsAdapter.InstructorViewHolder create(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_item, parent, false);
            return new CourseInstructorsAdapter.InstructorViewHolder(view);
        }
    }
}
