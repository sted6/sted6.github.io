package com.wgu.wguscheduler.packages.terms;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.wgu.wguscheduler.database.RoomDB;
import java.util.List;

public class TermsViewModel extends AndroidViewModel {

    private final RoomDB database;
    List<Term> terms;
    LiveData<List<Term>> liveTerms;
    Term selectedTerm;

    public TermsViewModel(Application application) {
        super(application);

        database = RoomDB.getInstance(application);

        terms = database.termDao().getAllTerms();

        liveTerms = database.termDao().getAllTermsLive();
    }

    public List<Term> getTerms() { return terms; }

    public LiveData<List<Term>> getTermsLive() { return liveTerms; };

    public long addTerm(Term term) {
        return database.termDao().insert(term);
    }

    public void deleteTerm(Term term) {
        database.termDao().delete(term);
    }

    public Term getTermById(long id) { return database.termDao().getTermById(id); }

    public Term getSelectedTerm() {
        return selectedTerm;
    }

    public void setSelectedTerm(Term selectedTerm) {
        this.selectedTerm = selectedTerm;
    }

    public void updateTerm(Term term) {
        database.termDao().update(term);
    }
}