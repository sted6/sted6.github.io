package com.wgu.wguscheduler.packages.instructors;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;
import java.util.ArrayList;

@Entity(tableName = "instructors")
public class Instructor implements Serializable {
    @PrimaryKey(autoGenerate = true)
    private long instructorId;

    @ColumnInfo
    private ArrayList<Long> courseIds;

    @ColumnInfo
    private String firstName;

    @ColumnInfo
    private String lastName;

    @ColumnInfo
    private String phoneNumber;

    @ColumnInfo
    private String email;

    public Instructor(String firstName, String lastName, String phoneNumber, String email) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.courseIds = new ArrayList<>();
    }

    public ArrayList<Long> getCourseIds() {
        return courseIds;
    }

    public void addCourseId(long courseId) {
        courseIds.add(courseId);
    }

    public void removeCourseId(long courseId) {
        courseIds.remove(courseId);
    }

    public void setCourseIds(ArrayList<Long> courseIds) {
        this.courseIds = courseIds;
    }

    public long getInstructorId() {
        return instructorId;
    }

    public void setInstructorId(long instructorId) {
        this.instructorId = instructorId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
