package com.wgu.wguscheduler.packages.instructors;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.wgu.wguscheduler.database.RoomDB;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class InstructorsViewModel extends AndroidViewModel {
    private final RoomDB database;
    private LiveData<List<Instructor>> instructorsLive;
    private final ArrayList<Instructor> selectedInstructors = new ArrayList<>();
    private Instructor selectedInstructor;

    public InstructorsViewModel(@NonNull @NotNull Application application) {
        super(application);
        database = RoomDB.getInstance(application);
        instructorsLive = database.instructorDao().getAllInstructorsLive();
    }

    public LiveData<List<Instructor>> getInstructorsLive() {
        return instructorsLive;
    }

    public void setInstructorsLive(LiveData<List<Instructor>> instructorsLive) {
        this.instructorsLive = instructorsLive;
    }

    public void addInstructorToSelectedList(Instructor instructor) {
        selectedInstructors.add(instructor);
    }

    public void removeInstructorFromSelectedList(Instructor instructor) {
        selectedInstructors.remove(instructor);
    }

    public void resetSelectedInstructorsList() {
        selectedInstructors.clear();
    }

    public ArrayList<Instructor> getSelectedInstructors() {
        return this.selectedInstructors;
    }

    public void createInstructor(Instructor instructor) {
        database.instructorDao().insert(instructor);
    }

    public void deleteList(ArrayList<Instructor> selectedInstructors) {
        database.instructorDao().deleteList(selectedInstructors);
    }

    public void updateInstructor(Instructor instructor) {
        database.instructorDao().update(instructor);
    }

    public Instructor getSelectedInstructor() {
        return selectedInstructor;
    }

    public void setSelectedInstructor(Instructor selectedInstructor) {
        this.selectedInstructor = selectedInstructor;
    }
}
