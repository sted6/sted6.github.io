package com.wgu.wguscheduler;

import android.app.AlarmManager;
import android.app.Dialog;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.NotificationCompat;

import com.wgu.wguscheduler.packages.custom_events.CustomEvent;
import com.wgu.wguscheduler.packages.custom_events.CustomEventsViewModel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import static com.wgu.wguscheduler.MainActivity.NOTIFICATION_CHANNEL_ID;
import static com.wgu.wguscheduler.packages.custom_events.ConstantCustomEvents.SELECTED_CUSTOM_EVENT;

public class CustomEventDetailsActivity extends AppCompatActivity {
    private AlarmManager alarmManager;
    
    CustomEvent customEvent;
    CustomEventsViewModel customEventsViewModel;
    private long customEventId;
    private String customEventTitle;
    private String customEventType;
    private Date customEventStart;
    private Date customEventEnd;
    private boolean fiveMinAlertStart;
    private boolean fifteenMinAlertStart;
    private boolean thirtyMinAlertStart;
    private boolean oneHourAlertStart;
    private boolean sixHourAlertStart;
    private boolean twelveHourAlertStart;
    private boolean oneDayAlertStart;
    private boolean twoDayAlertStart;
    private boolean oneWeekAlertStart;
    private boolean twoWeekAlertStart;
    private boolean oneMonthAlertStart;
    private boolean fiveMinAlertEnd;
    private boolean fifteenMinAlertEnd;
    private boolean thirtyMinAlertEnd;
    private boolean oneHourAlertEnd;
    private boolean sixHourAlertEnd;
    private boolean twelveHourAlertEnd;
    private boolean oneDayAlertEnd;
    private boolean twoDayAlertEnd;
    private boolean oneWeekAlertEnd;
    private boolean twoWeekAlertEnd;
    private boolean oneMonthAlertEnd;

    @Override
    protected void onCreate(@Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        super.onCreate(savedInstanceState);
        customEventsViewModel = new CustomEventsViewModel(getApplication());
        alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        customEvent = SELECTED_CUSTOM_EVENT;
        setContentView(R.layout.activity_custom_event_details);

        customEventId = customEvent.getId();
        customEventTitle = customEvent.getTitle();
        customEventType = customEvent.getType();
        customEventStart = customEvent.getStartDate();
        customEventEnd = customEvent.getEndDate();

        TextView eventIdText = findViewById(R.id.custom_event_details_id_text);
        Button deleteBtn = findViewById(R.id.custom_event_details_delete_btn);

        EditText editTitle = findViewById(R.id.custom_event_details_edit_title);
        EditText editType = findViewById(R.id.custom_event_details_edit_type);

        Button startBtn = findViewById(R.id.custom_event_details_start_date_btn);
        TextView startDateText = findViewById(R.id.custom_event_details_start_date_text);
        Button endBtn = findViewById(R.id.custom_event_details_end_date_btn);
        TextView endDateText = findViewById(R.id.custom_event_details_end_date_text);

        Button setNotificationsBtn = findViewById(R.id.custom_event_details_set_notifications_btn);

        Button cancelBtn = findViewById(R.id.custom_event_details_cancel);
        Button saveBtn = findViewById(R.id.custom_event_details_save);

        eventIdText.setText("Event ID: " + customEventId);
        editTitle.setText(customEventTitle);
        editType.setText(customEventType);

        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
        startDateText.setText("Start Date: " + sdf.format(customEventStart));
        endDateText.setText("End Date: " + sdf.format(customEventEnd));

        deleteBtn.setOnClickListener(view -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Are you sure you want to delete this Event?");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    customEventsViewModel.deleteCustomEvent(customEvent);
                    Intent intent = new Intent(view.getContext(), SchedulerActivity.class);
                    startActivity(intent);
                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.dismiss();
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        });

        startBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(this);
            dialog.setContentView(R.layout.datepicker);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.show();

            DatePicker datePicker = dialog.findViewById(R.id.datePicker);

            if (customEventStart != null) {
                SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String startDateString = sdf1.format(customEventStart);
                String[] dateArr = startDateString.split("-");
                int day = Integer.parseInt(dateArr[0]);
                int month = Integer.parseInt(dateArr[1])-1;
                int year = Integer.parseInt(dateArr[2]);
                datePicker.updateDate(year, month, day);
            }

            Button addDateBtn = dialog.findViewById(R.id.btn_datepicker_add);
            Button cancelDateBtn = dialog.findViewById(R.id.btn_datepicker_cancel);

            addDateBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int day  = datePicker.getDayOfMonth();
                    int month= datePicker.getMonth();
                    int year = datePicker.getYear();
                    Calendar calendar = Calendar.getInstance();
                    calendar.set(year, month, day);

                    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                    String formattedDate = sdf.format(calendar.getTime());
                    try {
                        Date date = sdf.parse(formattedDate);
                        customEventStart = date;
                        sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
                        formattedDate = sdf.format(calendar.getTime());
                        startDateText.setText("Start Date: " + formattedDate);
                    } catch (ParseException e) {
                        customEventStart = new Date();
                        e.printStackTrace();
                    }
                    dialog.dismiss();
                }
            });

            cancelDateBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dialog.dismiss();
                }
            });
        });

        endBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(this);
            dialog.setContentView(R.layout.datepicker);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.show();

            DatePicker datePicker = dialog.findViewById(R.id.datePicker);

            if (customEventEnd != null) {
                SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String startDateString = sdf1.format(customEventEnd);
                String[] dateArr = startDateString.split("-");
                int day = Integer.parseInt(dateArr[0]);
                int month = Integer.parseInt(dateArr[1])-1;
                int year = Integer.parseInt(dateArr[2]);
                datePicker.updateDate(year, month, day);
            }

            Button addDateBtn = dialog.findViewById(R.id.btn_datepicker_add);
            Button cancelDateBtn = dialog.findViewById(R.id.btn_datepicker_cancel);

            addDateBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int day  = datePicker.getDayOfMonth();
                    int month= datePicker.getMonth();
                    int year = datePicker.getYear();
                    Calendar calendar = Calendar.getInstance();
                    calendar.set(year, month, day);

                    SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                    String formattedDate = sdf.format(calendar.getTime());
                    try {
                        Date date = sdf.parse(formattedDate);
                        customEventEnd = date;
                        sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
                        formattedDate = sdf.format(calendar.getTime());
                        endDateText.setText("End Date: " + formattedDate);
                    } catch (ParseException e) {
                        customEventEnd = new Date();
                        e.printStackTrace();
                    }
                    dialog.dismiss();
                }
            });

            cancelDateBtn.setOnClickListener(view1 -> dialog.dismiss());
        });

        setNotificationsBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(this);
            dialog.setContentView(R.layout.add_alerts);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);

            fiveMinAlertStart = customEvent.isFiveMinAlertStart();
            fifteenMinAlertStart = customEvent.isFifteenMinAlertStart();
            thirtyMinAlertStart = customEvent.isThirtyMinAlertStart();
            oneHourAlertStart = customEvent.isOneHourAlertStart();
            sixHourAlertStart = customEvent.isSixHourAlertStart();
            twelveHourAlertStart = customEvent.isTwelveHourAlertStart();
            oneDayAlertStart = customEvent.isOneDayAlertStart();
            twoDayAlertStart = customEvent.isTwoDayAlertStart();
            oneWeekAlertStart = customEvent.isOneWeekAlertStart();
            twoWeekAlertStart = customEvent.isTwoWeekAlertStart();
            oneMonthAlertStart = customEvent.isOneMonthAlertStart();

            fiveMinAlertEnd = customEvent.isFiveMinAlertEnd();
            fifteenMinAlertEnd = customEvent.isFifteenMinAlertEnd();
            thirtyMinAlertEnd = customEvent.isThirtyMinAlertEnd();
            oneHourAlertEnd = customEvent.isOneHourAlertEnd();
            sixHourAlertEnd = customEvent.isSixHourAlertEnd();
            twelveHourAlertEnd = customEvent.isTwelveHourAlertEnd();
            oneDayAlertEnd = customEvent.isOneDayAlertEnd();
            twoDayAlertEnd = customEvent.isTwoDayAlertEnd();
            oneWeekAlertEnd = customEvent.isOneWeekAlertEnd();
            twoWeekAlertEnd = customEvent.isTwoWeekAlertEnd();
            oneMonthAlertEnd = customEvent.isOneMonthAlertEnd();

            SwitchCompat fiveMinSwitchStart = dialog.findViewById(R.id.add_alert_5min_switch);
            SwitchCompat fifteenMinSwitchStart = dialog.findViewById(R.id.add_alert_15min_switch);
            SwitchCompat thirtyMinSwitchStart = dialog.findViewById(R.id.add_alert_30min_switch);
            SwitchCompat oneHourSwitchStart = dialog.findViewById(R.id.add_alert_1hour_switch);
            SwitchCompat sixHoursSwitchStart = dialog.findViewById(R.id.add_alert_6hours_switch);
            SwitchCompat twelveHoursSwitchStart = dialog.findViewById(R.id.add_alert_12hours_switch);
            SwitchCompat oneDaySwitchStart = dialog.findViewById(R.id.add_alert_1day_switch);
            SwitchCompat twoDaysSwitchStart = dialog.findViewById(R.id.add_alert_2days_switch);
            SwitchCompat oneWeekSwitchStart = dialog.findViewById(R.id.add_alert_1week_switch);
            SwitchCompat twoWeeksSwitchStart = dialog.findViewById(R.id.add_alert_2weeks_switch);
            SwitchCompat oneMonthSwitchStart = dialog.findViewById(R.id.add_alert_1month_switch);

            SwitchCompat fiveMinSwitchEnd = dialog.findViewById(R.id.add_alert_5min_switch2);
            SwitchCompat fifteenMinSwitchEnd = dialog.findViewById(R.id.add_alert_15min_switch2);
            SwitchCompat thirtyMinSwitchEnd = dialog.findViewById(R.id.add_alert_30min_switch2);
            SwitchCompat oneHourSwitchEnd = dialog.findViewById(R.id.add_alert_1hour_switch2);
            SwitchCompat sixHoursSwitchEnd = dialog.findViewById(R.id.add_alert_6hours_switch2);
            SwitchCompat twelveHoursSwitchEnd = dialog.findViewById(R.id.add_alert_12hours_switch2);
            SwitchCompat oneDaySwitchEnd = dialog.findViewById(R.id.add_alert_1day_switch2);
            SwitchCompat twoDaysSwitchEnd = dialog.findViewById(R.id.add_alert_2days_switch2);
            SwitchCompat oneWeekSwitchEnd = dialog.findViewById(R.id.add_alert_1week_switch2);
            SwitchCompat twoWeeksSwitchEnd = dialog.findViewById(R.id.add_alert_2weeks_switch2);
            SwitchCompat oneMonthSwitchEnd = dialog.findViewById(R.id.add_alert_1month_switch2);

            Button cancelAlertsBtn = dialog.findViewById(R.id.add_alert_cancel_btn);
            Button saveAlertsBtn = dialog.findViewById(R.id.add_alert_save_alerts_btn);

            if (fiveMinAlertStart) {
                fiveMinSwitchStart.setChecked(true);
            }
            if (fifteenMinAlertStart) {
                fifteenMinSwitchStart.setChecked(true);
            }
            if (thirtyMinAlertStart) {
                thirtyMinSwitchStart.setChecked(true);
            }
            if (oneHourAlertStart) {
                oneHourSwitchStart.setChecked(true);
            }
            if (sixHourAlertStart) {
                sixHoursSwitchStart.setChecked(true);
            }
            if (twelveHourAlertStart) {
                twelveHoursSwitchStart.setChecked(true);
            }
            if (oneDayAlertStart) {
                oneDaySwitchStart.setChecked(true);
            }
            if (twoDayAlertStart) {
                twoDaysSwitchStart.setChecked(true);
            }
            if (oneWeekAlertStart) {
                oneWeekSwitchStart.setChecked(true);
            }
            if (twoWeekAlertStart) {
                twoWeeksSwitchStart.setChecked(true);
            }
            if (oneMonthAlertStart) {
                oneMonthSwitchStart.setChecked(true);
            }

            if (fiveMinAlertEnd) {
                fiveMinSwitchEnd.setChecked(true);
            }
            if (fifteenMinAlertEnd) {
                fifteenMinSwitchEnd.setChecked(true);
            }
            if (thirtyMinAlertEnd) {
                thirtyMinSwitchEnd.setChecked(true);
            }
            if (oneHourAlertEnd) {
                oneHourSwitchEnd.setChecked(true);
            }
            if (sixHourAlertEnd) {
                sixHoursSwitchEnd.setChecked(true);
            }
            if (twelveHourAlertEnd) {
                twelveHoursSwitchEnd.setChecked(true);
            }
            if (oneDayAlertEnd) {
                oneDaySwitchEnd.setChecked(true);
            }
            if (twoDayAlertEnd) {
                twoDaysSwitchEnd.setChecked(true);
            }
            if (oneWeekAlertEnd) {
                oneWeekSwitchEnd.setChecked(true);
            }
            if (twoWeekAlertEnd) {
                twoWeeksSwitchEnd.setChecked(true);
            }
            if (oneMonthAlertEnd) {
                oneMonthSwitchEnd.setChecked(true);
            }
            
            saveAlertsBtn.setOnClickListener(view1 -> {
                boolean checked = false;
                Long customEventID = customEventId;
                int customEventid = customEventID.intValue();
                if (fiveMinSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 5*60*1000;
                    long notificationTime = customEventStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");
                    builder.setContentTitle( customEventTitle );
                    builder.setContentText(customEventTitle + " begins in five minutes.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 1 );
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+111, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT ) ;
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setFiveMinAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+111, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setFiveMinAlertStart(false);
                }

                if (fifteenMinSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 15*60*1000;
                    long notificationTime = customEventStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");
                    builder.setContentTitle(customEventTitle);
                    builder.setContentText(customEventTitle + " begins in 15 minutes.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID );
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID, 2);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION, notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+112, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setFifteenMinAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+112, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setFifteenMinAlertStart(false);
                }

                if (thirtyMinSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 30*60*1000;
                    long notificationTime = customEventStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");
                    builder.setContentTitle(customEventTitle);
                    builder.setContentText(customEventTitle + " begins in 30 minutes.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 3);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+113, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setThirtyMinAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+113, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setThirtyMinAlertStart(false);
                }

                if (oneHourSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 60*60*1000;
                    long notificationTime = customEventStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");
                    builder.setContentTitle(customEventTitle);
                    builder.setContentText(customEventTitle + " begins in one hour.");
                    builder.setSmallIcon(R.drawable. ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 4);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+114, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setOneHourAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+114, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setOneHourAlertStart(false);
                }

                if (sixHoursSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 6*60*60*1000;
                    long notificationTime = customEventStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");
                    builder.setContentTitle(customEventTitle);
                    builder.setContentText(customEventTitle + " begins in six hours.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID );
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 5);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+115, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setSixHourAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+115, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setSixHourAlertStart(false);
                }

                if (twelveHoursSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 12*60*60*1000;
                    long notificationTime = customEventStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");
                    builder.setContentTitle(customEventTitle);
                    builder.setContentText(customEventTitle + " begins in twelve hours.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 6);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+116, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setTwelveHourAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+116, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setTwelveHourAlertStart(false);
                }

                if (oneDaySwitchStart.isChecked()) {
                    checked = true;
                    long millis = 24*60*60*1000;
                    long notificationTime = customEventStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default" );
                    builder.setContentTitle(customEventTitle);
                    builder.setContentText(customEventTitle + " begins in one day.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 7);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+117, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setOneDayAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+117, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setOneDayAlertStart(false);
                }

                if (twoDaysSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 48*60*60*1000;
                    long notificationTime = customEventStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");
                    builder.setContentTitle(customEventTitle);
                    builder.setContentText(customEventTitle + " begins in two days.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 8);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+118, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setTwoDayAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+118, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setTwoDayAlertStart(false);
                }

                if (oneWeekSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 7*24*60*60*1000;
                    long notificationTime = customEventStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");
                    builder.setContentTitle( customEventTitle );
                    builder.setContentText(customEventTitle + " begins in one week.");
                    builder.setSmallIcon(R.drawable. ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 9);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+119, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setOneWeekAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+119, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setOneWeekAlertStart(false);
                }

                if (twoWeeksSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 14*24*60*60*1000;
                    long notificationTime = customEventStart.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default" );
                    builder.setContentTitle( customEventTitle );
                    builder.setContentText(customEventTitle + " begins in two weeks.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build() ;

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 10);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+1110, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setTwoWeekAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+1110, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setTwoWeekAlertStart(false);
                }

                if (oneMonthSwitchStart.isChecked()) {
                    checked = true;
                    long weekMillis = 7*24*60*60*1000;
                    long monthMillis = weekMillis*4;
                    long notificationTime = customEventStart.getTime() - monthMillis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");
                    builder.setContentTitle(customEventTitle);
                    builder.setContentText(customEventTitle + " begins in 1 month.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 11);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+1111, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setOneMonthAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+1111, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setOneMonthAlertStart(false);
                }

                // ending alerts
                if (fiveMinSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 5*60*1000;
                    long notificationTime = customEventEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");
                    builder.setContentTitle( customEventTitle );
                    builder.setContentText(customEventTitle + " ends in five minutes.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 1 );
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+121, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT ) ;
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setFiveMinAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+121, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setFiveMinAlertEnd(false);
                }

                if (fifteenMinSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 15*60*1000;
                    long notificationTime = customEventEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");
                    builder.setContentTitle(customEventTitle);
                    builder.setContentText(customEventTitle + " ends in 15 minutes.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID );
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID, 2);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION, notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+122, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setFifteenMinAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+122, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setFifteenMinAlertEnd(false);
                }

                if (thirtyMinSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 30*60*1000;
                    long notificationTime = customEventEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");
                    builder.setContentTitle(customEventTitle);
                    builder.setContentText(customEventTitle + " ends in 30 minutes. The start date is " + startDateText.getText());
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 3);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+123, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setThirtyMinAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+123, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setThirtyMinAlertEnd(false);
                }

                if (oneHourSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 60*60*1000;
                    long notificationTime = customEventEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");
                    builder.setContentTitle(customEventTitle);
                    builder.setContentText(customEventTitle + " ends in one hour.");
                    builder.setSmallIcon(R.drawable. ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 4);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+124, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setOneHourAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+124, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setOneHourAlertEnd(false);
                }

                if (sixHoursSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 6*60*60*1000;
                    long notificationTime = customEventEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");
                    builder.setContentTitle(customEventTitle);
                    builder.setContentText(customEventTitle + " ends in six hours.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID );
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 5);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+125, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setSixHourAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+125, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setSixHourAlertEnd(false);
                }

                if (twelveHoursSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 12*60*60*1000;
                    long notificationTime = customEventEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");
                    builder.setContentTitle(customEventTitle);
                    builder.setContentText(customEventTitle + " ends in twelve hours.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 6);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+126, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setTwelveHourAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+126, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setTwelveHourAlertEnd(false);
                }

                if (oneDaySwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 24*60*60*1000;
                    long notificationTime = customEventEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default" );
                    builder.setContentTitle(customEventTitle);
                    builder.setContentText(customEventTitle + " ends in one day.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 7);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+127, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setOneDayAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+127, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setOneDayAlertEnd(false);
                }

                if (twoDaysSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 48*60*60*1000;
                    long notificationTime = customEventEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");
                    builder.setContentTitle(customEventTitle);
                    builder.setContentText(customEventTitle + " ends in two days.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 8);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+128, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setTwoDayAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+128, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setTwoDayAlertEnd(false);
                }

                if (oneWeekSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 7*24*60*60*1000;
                    long notificationTime = customEventEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");
                    builder.setContentTitle( customEventTitle );
                    builder.setContentText(customEventTitle + " ends in one week.");
                    builder.setSmallIcon(R.drawable. ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 9);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+129, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setOneWeekAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+129, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setOneWeekAlertEnd(false);
                }

                if (twoWeeksSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 14*24*60*60*1000;
                    long notificationTime = customEventEnd.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default" );
                    builder.setContentTitle( customEventTitle );
                    builder.setContentText(customEventTitle + " ends in two weeks.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build() ;

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 10);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+1210, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setTwoWeekAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+1210, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setTwoWeekAlertEnd(false);
                }

                if (oneMonthSwitchEnd.isChecked()) {
                    checked = true;
                    long weekMillis = 7*24*60*60*1000;
                    long monthMillis = weekMillis*4;
                    long notificationTime = customEventEnd.getTime() - monthMillis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "default");
                    builder.setContentTitle(customEventTitle);
                    builder.setContentText(customEventTitle + " ends in 1 month.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(this, NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 11);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(this, customEventid+1211, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    customEvent.setOneMonthAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            this, customEventid+1211, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    customEvent.setOneMonthAlertEnd(false);
                }

                if (checked) {
                    CharSequence text = "Notification(s) set.";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(this, text, duration);
                    toast.show();
                } else {
                    CharSequence text = "All notifications disabled.";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(this, text, duration);
                    toast.show();
                }
                dialog.dismiss();
            });

            cancelAlertsBtn.setOnClickListener(view1 -> dialog.dismiss());
            dialog.show();
        });

        saveBtn.setOnClickListener(view -> {
            customEventTitle = editTitle.getText().toString().trim();
            if (customEventTitle.equals("") || customEventTitle.isEmpty()) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Title is required.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            customEventType = editType.getText().toString().trim();
            if (customEventType.equals("") || customEventType.isEmpty()) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Type is required.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            if (customEventStart == null || customEventEnd == null){
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Event Start and End dates are both required.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            if (customEventStart.after(customEventEnd)) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Event Start must be before Course End.";
                Toast toast = Toast.makeText(context, text, Toast.LENGTH_LONG);
                toast.show();
                return;
            }
            customEvent.setTitle(customEventTitle);
            customEvent.setType(customEventType);
            if (!customEvent.getStartDate().equals(customEventStart)) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Event Start Date changed. Start Notifications reset.";
                resetStartNotifications();
                Toast toast = Toast.makeText(context, text, Toast.LENGTH_LONG);
                toast.show();
            }
            customEvent.setStartDate(customEventStart);
            if (!customEvent.getEndDate().equals(customEventEnd)) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Event End Date changed. End Notifications reset.";
                resetEndNotifications();
                Toast toast = Toast.makeText(context, text, Toast.LENGTH_LONG);
                toast.show();
            }
            customEvent.setEndDate(customEventEnd);
            customEventsViewModel.updateCustomEvent(customEvent);
            Intent intent = new Intent(this, SchedulerActivity.class);
            startActivity(intent);
        });

        cancelBtn.setOnClickListener(view -> {
            Intent intent = new Intent(this, SchedulerActivity.class);
            startActivity(intent);
        });

    }

    private void resetStartNotifications() {
        Long customEventID = customEventId;
        int customEventid = customEventID.intValue();
        Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+111, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setFiveMinAlertStart(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+112, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setFifteenMinAlertStart(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+113, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setThirtyMinAlertStart(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+114, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setOneHourAlertStart(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+115, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setSixHourAlertStart(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+116, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setTwelveHourAlertStart(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+117, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setOneDayAlertStart(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+118, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setTwoDayAlertStart(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+119, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setOneWeekAlertStart(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+1110, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setTwoWeekAlertStart(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+1111, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setOneMonthAlertStart(false);
    }
    private void resetEndNotifications() {
        Long customEventID = customEventId;
        int customEventid = customEventID.intValue();
        Intent cancelIntent = new Intent(this, NotificationBroadcast.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+121, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setFiveMinAlertEnd(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+122, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setFifteenMinAlertEnd(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+123, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setThirtyMinAlertEnd(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+124, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setOneHourAlertEnd(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+125, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setSixHourAlertEnd(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+126, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setTwelveHourAlertEnd(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+127, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setOneDayAlertEnd(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+128, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setTwoDayAlertEnd(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+129, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setOneWeekAlertEnd(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+1210, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setTwoWeekAlertEnd(false);

        cancelIntent = new Intent(this, NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                this, customEventid+1211, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        customEvent.setOneMonthAlertEnd(false);
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
