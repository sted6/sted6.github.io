package com.wgu.wguscheduler.packages.courses;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.wgu.wguscheduler.R;
import com.wgu.wguscheduler.packages.assessments.Assessment;
import com.wgu.wguscheduler.packages.assessments.AssessmentViewModel;
import com.wgu.wguscheduler.packages.assessments.CourseAssessmentsAdapter;
import com.wgu.wguscheduler.packages.instructors.AddInstructorToCourseAdapter;
import com.wgu.wguscheduler.packages.instructors.CourseInstructorsAdapter;
import com.wgu.wguscheduler.packages.instructors.Instructor;
import com.wgu.wguscheduler.packages.instructors.InstructorsViewModel;
import com.wgu.wguscheduler.packages.terms.Term;
import com.wgu.wguscheduler.packages.terms.TermsViewModel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AddCourseFragment extends Fragment {
    private CoursesViewModel coursesViewModel;
    private AssessmentViewModel assessmentViewModel;
    private InstructorsViewModel instructorsViewModel;


    private TextView parentTermText;
    private EditText editTitle;

    private RadioGroup courseStatusGroup;

    private TextView startDateText;
    private TextView endDateText;

    private RecyclerView notesRecyclerView;

    private RecyclerView instructorsRecyclerView;

    private RecyclerView assessmentsRecyclerView;

    private Term courseParentTerm;
    private String courseTitle;
    private String courseStatus;
    private Date courseStart;
    private Date courseEnd;

    private final ArrayList<String> courseNotes = new ArrayList<>();
    private final ArrayList<Instructor> courseInstructors = new ArrayList<>();
    private final ArrayList<Assessment> courseAssessments = new ArrayList<>();


    public AddCourseFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_add_course, container, false);
        coursesViewModel = ViewModelProviders.of(getActivity()).get(CoursesViewModel.class);
        assessmentViewModel = ViewModelProviders.of(getActivity()).get(AssessmentViewModel.class);
        instructorsViewModel = ViewModelProviders.of(getActivity()).get(InstructorsViewModel.class);

        assessmentViewModel.resetSelectedAssessments();
        instructorsViewModel.resetSelectedInstructorsList();

        parentTermText = root.findViewById(R.id.add_course_parent_term_text);
        Button setParentTermBtn = root.findViewById(R.id.add_course_set_parent_term_btn);
        editTitle = root.findViewById(R.id.add_course_edit_text_course_title);

        courseStatusGroup = root.findViewById(R.id.add_course_status_radio_group);

        startDateText = root.findViewById(R.id.add_course_start_date_text);
        endDateText = root.findViewById(R.id.add_course_end_date_text);
        Button startDateBtn = root.findViewById(R.id.add_course_add_start_btn);
        Button endDateBtn = root.findViewById(R.id.add_course_add_end_btn);

        Button addNoteBtn = root.findViewById(R.id.add_course_add_note_btn);
        Button removeNoteBtn = root.findViewById(R.id.add_course_remove_notes_btn);

        Button addInstructorBtn = root.findViewById(R.id.add_course_add_instructors_btn);
        Button removeInstructorsBtn = root.findViewById(R.id.add_course_remove_instructors_btn);

        Button addAssessmentBtn = root.findViewById(R.id.add_course_add_assessments_btn);
        Button removeAssessmentsBtn = root.findViewById(R.id.add_course_remove_assessments_btn);

        Button addCourseBtn = root.findViewById(R.id.add_course_add_course_btn);
        Button cancelBtn1 = root.findViewById(R.id.add_course_cancel_btn);

        notesRecyclerView = root.findViewById(R.id.add_course_notes_recycler_view);
        CourseNotesAdapter courseNotesAdapter = new CourseNotesAdapter(new CourseNotesAdapter.NoteDiff(), getActivity());
        RecyclerView.LayoutManager courseNotesLayoutManager = new LinearLayoutManager(getContext());
        notesRecyclerView.setAdapter(courseNotesAdapter);
        notesRecyclerView.setLayoutManager(courseNotesLayoutManager);

        setParentTermBtn.setOnClickListener(view -> {
            SetParentTermAdapter setParentTermAdapter;
            RecyclerView setParentRecyclerView;
            RecyclerView.LayoutManager layoutManager;
            TermsViewModel termsViewModel;

            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.set_parent_term);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);

            Button cancelBtn = dialog.findViewById(R.id.set_parent_term_cancel_btn);
            cancelBtn.setOnClickListener(view1 -> dialog.dismiss());

            setParentTermAdapter = new SetParentTermAdapter(new SetParentTermAdapter.TermDiff(), getActivity(), dialog);
            layoutManager = new LinearLayoutManager(dialog.getContext());
            termsViewModel = ViewModelProviders.of(getActivity()).get(TermsViewModel.class);
            termsViewModel.getTermsLive().observe(getViewLifecycleOwner(), setParentTermAdapter::submitList);

            setParentRecyclerView = dialog.findViewById(R.id.recycler_view_parent_terms);

            setParentRecyclerView.setAdapter(setParentTermAdapter);
            setParentRecyclerView.setLayoutManager(layoutManager);
            setParentTermAdapter.notifyDataSetChanged();
            dialog.show();
            dialog.setOnDismissListener( data -> {
                courseParentTerm = coursesViewModel.getParentTerm();
                if (courseParentTerm != null) {
                    parentTermText.setText("Parent Term: " + courseParentTerm.getTitle());
                }
            });
        });
        
        startDateBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.datepicker);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.show();

            DatePicker datePicker = dialog.findViewById(R.id.datePicker);

            if (courseStart != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String startDateString = sdf.format(courseStart);
                String[] dateArr = startDateString.split("-");
                int day = Integer.parseInt(dateArr[0]);
                int month = Integer.parseInt(dateArr[1])-1;
                int year = Integer.parseInt(dateArr[2]);
                datePicker.updateDate(year, month, day);
            }

            Button addDateBtn = dialog.findViewById(R.id.btn_datepicker_add);
            Button cancelDateBtn = dialog.findViewById(R.id.btn_datepicker_cancel);

            addDateBtn.setOnClickListener(view1 -> {
                int   day  = datePicker.getDayOfMonth();
                int   month= datePicker.getMonth();
                int   year = datePicker.getYear();
                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, day);

                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String formattedDate = sdf.format(calendar.getTime());
                try {
                    Date date = sdf.parse(formattedDate);
                    courseStart = date;
                    sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
                    formattedDate = sdf.format(calendar.getTime());
                    startDateText.setText("Start Date: " + formattedDate);
                } catch (ParseException e) {
                    courseStart = new Date();
                    e.printStackTrace();
                }
                dialog.dismiss();
            });

            cancelDateBtn.setOnClickListener(view1 -> dialog.dismiss());
        });

        endDateBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.datepicker);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.show();

            DatePicker datePicker = dialog.findViewById(R.id.datePicker);

            if (courseEnd != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String endDateString = sdf.format(courseEnd);
                String[] dateArr = endDateString.split("-");
                int day = Integer.parseInt(dateArr[0]);
                int month = Integer.parseInt(dateArr[1])-1;
                int year = Integer.parseInt(dateArr[2]);
                datePicker.updateDate(year, month, day);
            }

            Button addDateBtn = dialog.findViewById(R.id.btn_datepicker_add);
            Button cancelDateBtn = dialog.findViewById(R.id.btn_datepicker_cancel);

            addDateBtn.setOnClickListener(view1 -> {
                int day  = datePicker.getDayOfMonth();
                int month= datePicker.getMonth();
                int year = datePicker.getYear();

                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, day);

                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String formattedDate = sdf.format(calendar.getTime());
                try {
                    Date date = sdf.parse(formattedDate);
                    courseEnd = date;
                    sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
                    formattedDate = sdf.format(calendar.getTime());
                    endDateText.setText("End Date: " + formattedDate);
                } catch (ParseException e) {
                    courseEnd = new Date();
                    e.printStackTrace();
                }
                dialog.dismiss();
            });

            cancelDateBtn.setOnClickListener(view1 -> dialog.dismiss());
        });

        addNoteBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.add_note_to_course);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            EditText editNote = dialog.findViewById(R.id.add_note_to_course_edit_note);
            Button addBtn = dialog.findViewById(R.id.add_note_to_course_add_btn);
            Button cancelBtn = dialog.findViewById(R.id.add_note_to_course_cancel_btn);

            addBtn.setOnClickListener(view1 -> {
                String newNote = editNote.getText().toString().trim();
                if (newNote.isEmpty()) {
                    Context context = view.getContext().getApplicationContext();
                    CharSequence text = "Note cannot be empty.";
                    int duration = Toast.LENGTH_LONG;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    return;
                }
                courseNotes.add(newNote);
                courseNotesAdapter.submitList(courseNotes);
                courseNotesAdapter.notifyItemInserted(courseNotes.size()-1);
                courseNotesAdapter.notifyDataSetChanged();
                notesRecyclerView.scrollToPosition(courseNotes.size()-1);
                dialog.dismiss();
            });

            cancelBtn.setOnClickListener(view1 -> dialog.dismiss());

            dialog.show();
        });

        removeNoteBtn.setOnClickListener(view -> {
            ArrayList<String> selectedNotes = coursesViewModel.getSelectedNotes();
            for (int x = 0; x < selectedNotes.size(); x++) {
                courseNotes.remove(selectedNotes.get(x));
            }
            courseNotesAdapter.submitList(courseNotes);
            courseNotesAdapter.notifyDataSetChanged();
        });

        //INSTRUCTORS
        instructorsRecyclerView = root.findViewById(R.id.add_course_instructors_recycler_view);
        CourseInstructorsAdapter courseInstructorsAdapter = new CourseInstructorsAdapter(new CourseInstructorsAdapter.InstructorDiff(), getActivity());
        instructorsRecyclerView.setAdapter(courseInstructorsAdapter);
        RecyclerView.LayoutManager instructorsLayoutManager = new LinearLayoutManager(getContext());
        instructorsRecyclerView.setLayoutManager(instructorsLayoutManager);

        addInstructorBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.add_instructor_to_course);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);

            RecyclerView addInstructorsRecyclerView = dialog.findViewById(R.id.recycler_view_add_assessments_to_course);
            AddInstructorToCourseAdapter addInstructorToCourseAdapter = new AddInstructorToCourseAdapter(new AddInstructorToCourseAdapter.InstructorDiff(), getActivity());
            RecyclerView.LayoutManager addInstructorLayoutManager = new LinearLayoutManager(getContext());
            addInstructorsRecyclerView.setAdapter(addInstructorToCourseAdapter);
            addInstructorsRecyclerView.setLayoutManager(addInstructorLayoutManager);

            instructorsViewModel.getInstructorsLive().observe(getViewLifecycleOwner(), addInstructorToCourseAdapter::submitList);

            Button addSelectedInstructorsBtn = dialog.findViewById(R.id.add_selected_assessments_to_cours_btn);
            Button cancelSelectedInstructorsBtn = dialog.findViewById(R.id.add_assessments_to_course_cancel_btn);
            Button createNewInstructorBtn = dialog.findViewById(R.id.create_new_instructor_btn);
            Button deleteSelectedInstructorsBtn = dialog.findViewById(R.id.delete_instructors_btn);

            deleteSelectedInstructorsBtn.setOnClickListener(view1 -> {
                ArrayList<Instructor> selectedInstructors = instructorsViewModel.getSelectedInstructors();
                for (int x = 0; x < selectedInstructors.size(); x++) {
                    if (selectedInstructors.get(x).getCourseIds().size() > 0) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setMessage("One or more of the selected Instructors are assigned to Courses, are you sure you want to delete them?");
                        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                instructorsViewModel.deleteList(selectedInstructors);
                                instructorsViewModel.resetSelectedInstructorsList();
                            }
                        });
                        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                            }
                        });
                        AlertDialog dialog1 = builder.create();
                        dialog1.show();
                        return;
                    }
                }
                instructorsViewModel.deleteList(selectedInstructors);
                instructorsViewModel.resetSelectedInstructorsList();
                dialog.dismiss();
            });

            createNewInstructorBtn.setOnClickListener(view1 -> {
                Dialog dialog1 = new Dialog(getContext());
                dialog1.setContentView(R.layout.create_new_instructor);
                int width1 = WindowManager.LayoutParams.MATCH_PARENT;
                int height1 = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog1.getWindow().setLayout(width1, height1);

                EditText firstNameEdit = dialog1.findViewById(R.id.create_new_instructor_first_name_edit_text);
                EditText lastNameEdit = dialog1.findViewById(R.id.create_new_instructor_last_name_edit_text);
                EditText emailEdit = dialog1.findViewById(R.id.create_new_instructor_email_edit_text);
                EditText phoneEdit = dialog1.findViewById(R.id.create_new_instructor_phone_edit_text);
                Button createNewInstructorCancelBtn = dialog1.findViewById(R.id.create_new_instructor_cancel_btn);
                Button createNewInstructorSaveBtn = dialog1.findViewById(R.id.create_new_instructor_save_btn);

                createNewInstructorCancelBtn.setOnClickListener(view2 -> dialog1.dismiss());

                createNewInstructorSaveBtn.setOnClickListener(view2 -> {
                    String firstName = firstNameEdit.getText().toString().trim();
                    String lastName = lastNameEdit.getText().toString().trim();
                    String email = emailEdit.getText().toString().trim();
                    String phone = phoneEdit.getText().toString().trim();

                    Instructor newInstructor = new Instructor(firstName, lastName, email, phone);
                    instructorsViewModel.createInstructor(newInstructor);
                    dialog1.dismiss();
                });
                dialog1.show();
            });

            addSelectedInstructorsBtn.setOnClickListener(view1 -> {
                ArrayList<Instructor> selectedInstructors = instructorsViewModel.getSelectedInstructors();
                if (selectedInstructors.size() == 0){
                    Context context = view.getContext().getApplicationContext();
                    CharSequence text = "No Instructors selected.";
                    int duration = Toast.LENGTH_LONG;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    return;
                }
                courseInstructors.addAll(selectedInstructors);
                courseInstructorsAdapter.submitList(courseInstructors);
                courseInstructorsAdapter.notifyItemInserted(courseInstructors.size()-1);
                courseInstructorsAdapter.notifyDataSetChanged();
                instructorsRecyclerView.scrollToPosition(courseInstructors.size()-1);
                instructorsViewModel.resetSelectedInstructorsList();
                dialog.dismiss();
            });

            cancelSelectedInstructorsBtn.setOnClickListener(view1 -> {
                dialog.dismiss();
                instructorsViewModel.resetSelectedInstructorsList();
            });

            dialog.show();
        });

        removeInstructorsBtn.setOnClickListener(view -> {
            ArrayList<Instructor> selectedInstructors = instructorsViewModel.getSelectedInstructors();
            if (selectedInstructors.size() <= 0) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "No Instructors selected.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            selectedInstructors.forEach(courseInstructors::remove);
            instructorsViewModel.resetSelectedInstructorsList();
            courseInstructorsAdapter.submitList(courseInstructors);
            courseInstructorsAdapter.notifyItemInserted(courseInstructors.size()-1);
            courseInstructorsAdapter.notifyDataSetChanged();
            instructorsRecyclerView.scrollToPosition(courseInstructors.size()-1);
        });


        // ASSESSMENTS

        assessmentsRecyclerView = root.findViewById(R.id.add_course_assessment_recycler_view);
        CourseAssessmentsAdapter courseAssessmentsAdapter = new CourseAssessmentsAdapter(new CourseAssessmentsAdapter.AssessmentDiff(), getActivity());
        RecyclerView.LayoutManager courseAssessmentsLayoutManager = new LinearLayoutManager(getContext());
        assessmentsRecyclerView.setAdapter(courseAssessmentsAdapter);
        assessmentsRecyclerView.setLayoutManager(courseAssessmentsLayoutManager);

        removeAssessmentsBtn.setOnClickListener(view -> {
            ArrayList<Assessment> selectedAssessments = assessmentViewModel.getSelectedAssessments();
            if (selectedAssessments.size() <= 0) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "No Assessments selected.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            courseAssessments.removeAll(selectedAssessments);
            courseAssessmentsAdapter.submitList(courseAssessments);
            courseAssessmentsAdapter.notifyItemInserted(courseAssessments.size()-1);
            courseAssessmentsAdapter.notifyDataSetChanged();
            assessmentsRecyclerView.scrollToPosition(courseAssessments.size()-1);
            assessmentViewModel.resetSelectedAssessments();
        });

        addAssessmentBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.add_assessment_to_course);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);

            RecyclerView addAssessmentsToCourseRecyclerView = dialog.findViewById(R.id.recycler_view_add_assessments_to_course);
            Button cancelBtn = dialog.findViewById(R.id.add_assessments_to_course_cancel_btn);
            Button addSelectedAssessmentsBtn = dialog.findViewById(R.id.add_selected_assessments_to_cours_btn);

            CourseAssessmentsAdapter addAssessmentsToCourseAdapter = new CourseAssessmentsAdapter(new CourseAssessmentsAdapter.AssessmentDiff(), getActivity());
            RecyclerView.LayoutManager addAssessmentsToCourseLayoutManager = new LinearLayoutManager(getContext());

            addAssessmentsToCourseRecyclerView.setAdapter(addAssessmentsToCourseAdapter);
            addAssessmentsToCourseRecyclerView.setLayoutManager(addAssessmentsToCourseLayoutManager);

            assessmentViewModel.getAssessmentsLive().observe(getViewLifecycleOwner(), addAssessmentsToCourseAdapter::submitList);

            cancelBtn.setOnClickListener(view1 -> dialog.dismiss());

            addSelectedAssessmentsBtn.setOnClickListener(view1 -> {
                ArrayList<Assessment> selectedAssessments = assessmentViewModel.getSelectedAssessments();
                if (selectedAssessments.size() <= 0) {
                    Context context = view.getContext().getApplicationContext();
                    CharSequence text = "No Assessments selected.";
                    int duration = Toast.LENGTH_LONG;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    return;
                }
                int assessmentCount = selectedAssessments.size();
                for (int x = 0; x < assessmentCount; x++) {
                    if (selectedAssessments.get(x).getCourseOwnerId() != 0) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setMessage("One or more of the selected Courses are assigned to another Term. Are you sure you want to reassign them?");
                        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog1, int id) {
                                courseAssessments.addAll(selectedAssessments);
                                courseAssessmentsAdapter.submitList(courseAssessments);
                                courseAssessmentsAdapter.notifyItemInserted(courseAssessments.size()-1);
                                courseAssessmentsAdapter.notifyDataSetChanged();
                                assessmentsRecyclerView.scrollToPosition(courseAssessments.size()-1);
                                assessmentViewModel.resetSelectedAssessments();
                                dialog1.dismiss();
                                dialog.dismiss();
                            }
                        });
                        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                            }
                        });
                        AlertDialog dialog1 = builder.create();
                        dialog1.show();
                        return;
                    }
                }
                courseAssessments.addAll(selectedAssessments);
                courseAssessmentsAdapter.submitList(courseAssessments);
                courseAssessmentsAdapter.notifyItemInserted(courseAssessments.size()-1);
                courseAssessmentsAdapter.notifyDataSetChanged();
                assessmentsRecyclerView.scrollToPosition(courseAssessments.size()-1);
                assessmentViewModel.resetSelectedAssessments();
                dialog.dismiss();
            });

            dialog.show();
        });

        addCourseBtn.setOnClickListener(view -> {
            courseTitle = editTitle.getText().toString().trim();
            if (courseTitle.equals("") || courseTitle.isEmpty()) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Course Title is required.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            int courseStatusId = courseStatusGroup.getCheckedRadioButtonId();
            if (courseStatusId == -1) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Course Status is required.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            RadioButton selectedBtn = root.findViewById(courseStatusId);
            courseStatus = selectedBtn.getText().toString();

            if (courseStart == null || courseEnd == null){
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Course Start and End dates are both required.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }

            if (courseStart.after(courseEnd)) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Course Start must be before Course End.";
                Toast toast = Toast.makeText(context, text, Toast.LENGTH_LONG);
                toast.show();
                return;
            }

            long courseParentTermId = 0;
            if (courseParentTerm != null) {
                courseParentTermId = courseParentTerm.getTermId();
            }

            Course newCourse = new Course(courseTitle, courseParentTermId, courseStart, courseEnd, courseStatus);

            if (courseNotes.size() > 0) {
                newCourse.setNotes(courseNotes);
            }
            long newCourseId = coursesViewModel.addCourse(newCourse);
            if (courseInstructors.size() > 0) {
                courseInstructors.forEach(instructor -> instructor.addCourseId(newCourseId));
            }
            if (courseAssessments.size() > 0) {
                courseAssessments.forEach(assessment -> assessment.setCourseOwnerId(newCourseId));
            }
            Navigation.findNavController(view).navigate(R.id.action_addCourseFragment_to_coursesFragment);
        });

        cancelBtn1.setOnClickListener(view -> Navigation.findNavController(view).navigate(R.id.action_addCourseFragment_to_coursesFragment));
        
        return root;
    }
}