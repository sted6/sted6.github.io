package com.wgu.wguscheduler.packages.custom_events;

public class ConstantCustomEvents {
    public static CustomEvent SELECTED_CUSTOM_EVENT;
}
