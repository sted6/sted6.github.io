package com.wgu.wguscheduler.packages.custom_events;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.wgu.wguscheduler.database.RoomDB;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class CustomEventsViewModel extends AndroidViewModel {
    RoomDB database;
    LiveData<List<CustomEvent>> customEventsLive;

    public CustomEventsViewModel(@NonNull @NotNull Application application) {
        super(application);
        database = RoomDB.getInstance(application);
        customEventsLive = database.customEventDao().getCustomEventsLive();
    }

    public long addCustomEvent(CustomEvent customEvent) {
        return database.customEventDao().insert(customEvent);
    }

    public void deleteCustomEvent(CustomEvent customEvent) {
        database.customEventDao().delete(customEvent);
    }

    public void updateCustomEvent(CustomEvent customEvent) {
        database.customEventDao().update(customEvent);
    }

    public LiveData<List<CustomEvent>> getCustomEventsLive() {
        return customEventsLive;
    }
}
