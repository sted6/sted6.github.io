package com.wgu.wguscheduler.packages.instructors;

import android.app.Activity;
import android.app.Dialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.wgu.wguscheduler.R;

import org.jetbrains.annotations.NotNull;

public class AddInstructorToCourseAdapter extends ListAdapter<Instructor, AddInstructorToCourseAdapter.InstructorViewHolder> {
    private final Activity context;
    public AddInstructorToCourseAdapter(@NonNull @NotNull DiffUtil.ItemCallback<Instructor> diffCallback, Activity context) {
        super(diffCallback);
        this.context = context;
    }

    @NonNull @NotNull @Override
    public AddInstructorToCourseAdapter.InstructorViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return InstructorViewHolder.create(parent);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull AddInstructorToCourseAdapter.InstructorViewHolder holder, int position) {
        Instructor instructor = getItem(position);
        holder.bind(instructor, context);
    }

    public static class InstructorDiff extends DiffUtil.ItemCallback<Instructor> {
        @Override
        public boolean areItemsTheSame(@NonNull @NotNull Instructor oldItem, @NonNull @NotNull Instructor newItem) {
            return oldItem == newItem;
        }

        @Override
        public boolean areContentsTheSame(@NonNull @NotNull Instructor oldItem, @NonNull @NotNull Instructor newItem) {
            return oldItem.getInstructorId() == newItem.getInstructorId();
        }
    }


    public static class InstructorViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        CheckBox instructorCheckbox;
        InstructorsViewModel instructorsViewModel;

        public InstructorViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);

            textView = itemView.findViewById(R.id.child_text);
            instructorCheckbox = itemView.findViewById(R.id.child_checkbox);
        }


        public void bind(Instructor instructor, Activity context) {
            instructorsViewModel = ViewModelProviders.of((FragmentActivity)context).get(InstructorsViewModel.class);
            textView.setText(instructor.getFirstName() + " " + instructor.getLastName());
            instructorCheckbox.setOnClickListener(view -> {
                if (instructorCheckbox.isChecked()) {
                    instructorsViewModel.addInstructorToSelectedList(instructor);
                } else {
                    instructorsViewModel.removeInstructorFromSelectedList(instructor);
                }
            });
        }

        public static InstructorViewHolder create(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_item, parent, false);
            return new InstructorViewHolder(view);
        }
    }
}
