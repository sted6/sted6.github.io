package com.wgu.wguscheduler.packages.terms;

import android.app.Activity;
import android.app.Dialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.wgu.wguscheduler.R;
import com.wgu.wguscheduler.packages.courses.Course;
import com.wgu.wguscheduler.packages.courses.CoursesViewModel;

import org.jetbrains.annotations.NotNull;

public class AddCoursesToTermAdapter extends ListAdapter<Course, AddCoursesToTermAdapter.CourseViewHolder> {
    private final Activity context;
    protected AddCoursesToTermAdapter(@NonNull @NotNull DiffUtil.ItemCallback<Course> diffCallback, Activity context) {
        super(diffCallback);
        this.context = context;
    }

    @NonNull @NotNull @Override
    public AddCoursesToTermAdapter.CourseViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return CourseViewHolder.create(parent);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull AddCoursesToTermAdapter.CourseViewHolder holder, int position) {
        Course course = getItem(position);
        holder.bind(course, context);
    }

    public static class CourseDiff extends DiffUtil.ItemCallback<Course> {
        @Override
        public boolean areItemsTheSame(@NonNull @NotNull Course oldItem, @NonNull @NotNull Course newItem) {
            return oldItem == newItem;
        }

        @Override
        public boolean areContentsTheSame(@NonNull @NotNull Course oldItem, @NonNull @NotNull Course newItem) {
            return oldItem.getTitle().equals(newItem.getTitle());
        }
    }


    public static class CourseViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        CheckBox courseCheckbox;
        CoursesViewModel coursesViewModel;

        public CourseViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);

            textView = itemView.findViewById(R.id.child_text);
            courseCheckbox = itemView.findViewById(R.id.child_checkbox);
        }


        public void bind(Course course, Activity context) {
            coursesViewModel = ViewModelProviders.of((FragmentActivity)context).get(CoursesViewModel.class);
            coursesViewModel.resetSelectedCourses();
            textView.setText(course.getTitle());
            courseCheckbox.setOnClickListener(view -> {
                if (courseCheckbox.isChecked()) {
                    coursesViewModel.addCourseToSelectedList(course);
                } else {
                    coursesViewModel.removeCourseFromSelectedList(course);
                }
            });
        }

        public static CourseViewHolder create(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_item, parent, false);
            return new CourseViewHolder(view);
        }
    }
}
