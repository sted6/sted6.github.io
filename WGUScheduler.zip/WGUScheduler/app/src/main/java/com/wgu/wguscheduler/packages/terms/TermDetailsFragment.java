package com.wgu.wguscheduler.packages.terms;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.wgu.wguscheduler.R;
import com.wgu.wguscheduler.packages.courses.Course;
import com.wgu.wguscheduler.packages.courses.CoursesViewModel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TermDetailsFragment extends Fragment {
    private TermsViewModel termsViewModel;
    private CoursesViewModel coursesViewModel;

    private Term term;
    private EditText termTitleEdit;
    private TextView termStartText;
    private TextView termEndText;

    private String termTitle;
    private Date termStart;
    private Date termEnd;
    private long termId;
    private List<Course> termCourses;


    public TermDetailsFragment() { }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        termsViewModel = ViewModelProviders.of(requireActivity()).get(TermsViewModel.class);
        term = termsViewModel.getSelectedTerm();
        termTitle = term.getTitle();
        termId = term.getTermId();

        termStart = term.getStart();
        termEnd = term.getEnd();

        coursesViewModel = ViewModelProviders.of(requireActivity()).get(CoursesViewModel.class);
        coursesViewModel.resetSelectedCourses();

        View root = inflater.inflate(R.layout.fragment_term_details, container, false);

        termStartText = root.findViewById(R.id.term_details_start_text);
        Button updateStartBtn = root.findViewById(R.id.term_details_update_start_date_btn);
        termEndText = root.findViewById(R.id.term_details_end_text);
        Button updateEndBtn = root.findViewById(R.id.term_details_update_end_date_btn);
        TextView termIdText = root.findViewById(R.id.term_details_id_text);
        Button deleteTermBtn = root.findViewById(R.id.term_details_delete_btn);
        termTitleEdit = root.findViewById(R.id.term_details_edit_title);
        RecyclerView coursesRecyclerView = root.findViewById(R.id.term_details_courses_list_recycler_view);
        Button addCourseBtn = root.findViewById(R.id.term_details_add_course_btn);
        Button removeCoursesBtn = root.findViewById(R.id.term_details_remove_courses_btn);
        Button saveChangesBtn = root.findViewById(R.id.term_details_update_term_btn);

        termTitleEdit.setText(termTitle);
        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
        termStartText.setText("Term Start Date: " + sdf.format(termStart));
        termEndText.setText("Term End Date: " + sdf.format(termEnd));
        termIdText.setText("Term ID: " + termId);

        TermCoursesAdapter termCoursesAdapter = new TermCoursesAdapter(new TermCoursesAdapter.CourseDiff(), getActivity());
        RecyclerView.LayoutManager termCoursesLayoutManager = new LinearLayoutManager(getContext());
        coursesRecyclerView.setAdapter(termCoursesAdapter);
        coursesRecyclerView.setLayoutManager(termCoursesLayoutManager);

        coursesViewModel.getLiveCoursesByParentTerm(termId).observe(getViewLifecycleOwner(), courses -> {
            termCoursesAdapter.submitList(courses);
            termCourses = courses;
        });

        deleteTermBtn.setOnClickListener(view -> {
            if (termCourses.size() != 0) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Term cannot be deleted while it has Courses assigned to it.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setMessage("Are you sure you want to delete this Term?");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    termsViewModel.deleteTerm(term);
                    Navigation.findNavController(view).navigate(R.id.action_termDetailsFragment_to_termsFragment);
                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.dismiss();
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        });

        updateStartBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.datepicker);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);

            DatePicker datePicker = dialog.findViewById(R.id.datePicker);

            String startDateString = sdf.format(termStart);
            String[] dateArr = startDateString.split("-");
            int startDay = Integer.parseInt(dateArr[1]);
            int startMonth = Integer.parseInt(dateArr[0])-1;
            int startYear = Integer.parseInt(dateArr[2]);

            datePicker.updateDate(startYear, startMonth, startDay);

            Button addDateBtn = dialog.findViewById(R.id.btn_datepicker_add);
            Button cancelDateBtn = dialog.findViewById(R.id.btn_datepicker_cancel);

            addDateBtn.setText("Update Date");
            addDateBtn.setOnClickListener(view1 -> {
                int day  = datePicker.getDayOfMonth();
                int month= datePicker.getMonth();
                int year = datePicker.getYear();
                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, day);

                SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String formattedDate = sdf2.format(calendar.getTime());
                try {
                    Date date = sdf2.parse(formattedDate);
                    termStart = date;
                    formattedDate = sdf.format(calendar.getTime());
                    termStartText.setText("Term Start Date: " + formattedDate);
                } catch (ParseException e) {
                    termStart = new Date();
                    e.printStackTrace();
                }
                dialog.dismiss();
            });

            cancelDateBtn.setOnClickListener(view2 -> dialog.dismiss());

            dialog.show();
        });

        updateEndBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.datepicker);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);

            DatePicker datePicker = dialog.findViewById(R.id.datePicker);


            String endDateString = sdf.format(termEnd);
            String[] dateArr = endDateString.split("-");
            int endDay = Integer.parseInt(dateArr[1]);
            int endMonth = Integer.parseInt(dateArr[0])-1;
            int endYear = Integer.parseInt(dateArr[2]);

            datePicker.updateDate(endYear, endMonth, endDay);

            Button addDateBtn = dialog.findViewById(R.id.btn_datepicker_add);
            Button cancelDateBtn = dialog.findViewById(R.id.btn_datepicker_cancel);

            addDateBtn.setText("Update Date");
            addDateBtn.setOnClickListener(view1 -> {
                int day  = datePicker.getDayOfMonth();
                int month= datePicker.getMonth();
                int year = datePicker.getYear();
                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, day);

                SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String formattedDate = sdf1.format(calendar.getTime());
                try {
                    Date date = sdf1.parse(formattedDate);
                    termEnd = date;
                    formattedDate = sdf.format(calendar.getTime());
                    termEndText.setText("Term End Date: " + formattedDate);
                } catch (ParseException e) {
                    termEnd = new Date();
                    e.printStackTrace();
                }
                dialog.dismiss();
            });

            cancelDateBtn.setOnClickListener(view2 -> dialog.dismiss());

            dialog.show();
        });
        
        addCourseBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.add_courses_to_term);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);

            Button addSelectedCoursesBtn = dialog.findViewById(R.id.add_selected_courses_btn);
            Button cancel = dialog.findViewById(R.id.cancel_selected_courses_btn);
            RecyclerView addCoursesRecyclerView = dialog.findViewById(R.id.recycler_view_add_courses_to_term);

            AddCoursesToTermAdapter adapter = new AddCoursesToTermAdapter(new AddCoursesToTermAdapter.CourseDiff(), getActivity());
            RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());

            addCoursesRecyclerView.setLayoutManager(layoutManager);
            addCoursesRecyclerView.setAdapter(adapter);

            adapter.submitList(coursesViewModel.getCourses());

            cancel.setOnClickListener(view1 -> {
                coursesViewModel.resetSelectedCourses();
                dialog.dismiss();
            });

            addSelectedCoursesBtn.setOnClickListener(view1 -> {
                ArrayList<Course> courses = coursesViewModel.getSelectedCourses();
                if (courses.size() <= 0) {
                    Context context = view.getContext().getApplicationContext();
                    CharSequence text = "No Courses selected.";
                    int duration = Toast.LENGTH_LONG;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    return;
                }
                for (int x = 0; x < courses.size(); x++) {
                    long courseOwnerId = courses.get(x).getTermOwnerId();
                    if (courseOwnerId != 0 && courseOwnerId != termId) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setMessage("One or more of the selected Courses are assigned to another Term. Are you sure you want to reassign them?");
                        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog1, int id) {
                                courses.forEach(course -> {
                                    course.setTermOwnerId(termId);
                                    coursesViewModel.updateCourse(course);
                                });
                                coursesViewModel.resetSelectedCourses();
                                dialog1.dismiss();
                                dialog.dismiss();
                            }
                        });
                        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                            }
                        });
                        AlertDialog dialog1 = builder.create();
                        dialog1.show();
                        return;
                    }
                }
                courses.forEach(course -> {
                    course.setTermOwnerId(termId);
                    coursesViewModel.updateCourse(course);
                });
                coursesViewModel.resetSelectedCourses();
                dialog.dismiss();
            });

            dialog.show();

        });

        removeCoursesBtn.setOnClickListener(view -> {
            ArrayList<Course> courses = coursesViewModel.getSelectedCourses();
            if (courses.size() <= 0) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "No Courses selected.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            courses.forEach(course -> {
                course.setTermOwnerId(0);
                coursesViewModel.updateCourse(course);
            });
            coursesViewModel.resetSelectedCourses();
        });

        saveChangesBtn.setOnClickListener(view -> {
            termTitle = termTitleEdit.getText().toString().trim();
            if (termTitle.equals("") || String.valueOf(termStart).equals("null")|| String.valueOf(termEnd).equals("null")) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Please input a title and select both start and end dates.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            if (termStart.after(termEnd)) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Term Start must be before Term End.";
                Toast toast = Toast.makeText(context, text, Toast.LENGTH_LONG);
                toast.show();
                return;
            }
            term.setTitle(termTitle);
            term.setStart(termStart);
            term.setEnd(termEnd);
            termsViewModel.updateTerm(term);
            Navigation.findNavController(view).navigate(R.id.action_termDetailsFragment_to_termsFragment);
        });

        Button cancelChangesBtn = root.findViewById(R.id.term_details_back_btn);
        cancelChangesBtn.setOnClickListener(view -> Navigation.findNavController(view).navigate(R.id.action_termDetailsFragment_to_termsFragment));


        return root;
    }
}