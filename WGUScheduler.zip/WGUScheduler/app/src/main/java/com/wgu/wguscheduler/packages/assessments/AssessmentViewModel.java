package com.wgu.wguscheduler.packages.assessments;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.wgu.wguscheduler.database.RoomDB;
import com.wgu.wguscheduler.packages.courses.Course;

import java.util.ArrayList;
import java.util.List;

public class AssessmentViewModel extends AndroidViewModel {

    private final RoomDB database;
    LiveData<List<Assessment>> liveAssessments;
    Course parentCourse;
    Assessment selectedAssessment;
    ArrayList<Assessment> selectedAssessments = new ArrayList<>();

    public AssessmentViewModel(Application application) {
        super(application);
        database = RoomDB.getInstance(application);
        liveAssessments = database.assessmentDao().getAllAssessmentsLive();
    }

    public void addAssessment(Assessment assessment) {
        database.assessmentDao().insert(assessment);
    }
    public void deleteAssessment(Assessment assessment) {
        database.assessmentDao().delete(assessment);
    }
    public void updateAssessment(Assessment assessment) {
        database.assessmentDao().update(assessment);
    }
    public LiveData<List<Assessment>> getAssessmentsLive() {
        return liveAssessments;
    }

    public void setParentCourse(Course course) {
        this.parentCourse = course;
    }

    public Course getParentCourse() {
        return parentCourse;
    }

    public Assessment getSelectedAssessment() {
        return selectedAssessment;
    }

    public void setSelectedAssessment(Assessment assessment) {
        this.selectedAssessment = assessment;
    }

    public void resetSelectedAssessments() {
        this.selectedAssessments.clear();
    }

    public ArrayList<Assessment> getSelectedAssessments() {
        return selectedAssessments;
    }

    public void addAssessmentToSelectedList(Assessment assessment) {
        this.selectedAssessments.add(assessment);
    }

    public void removeAssessmentFromSelectedList(Assessment assessment) {
        this.selectedAssessments.remove(assessment);
    }

    public LiveData<List<Assessment>> getAssessmentsByCourseOwnerLive(long id) {
        return database.assessmentDao().getAssessmentsByCourseOwnerLive(id);
    }
}