package com.wgu.wguscheduler.packages.terms;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;


import java.io.Serializable;
import java.util.Date;


@Entity(tableName = "terms")
public class Term implements Serializable {
    @PrimaryKey(autoGenerate = true)
    private long termId;

    @ColumnInfo(name = "title")
    private String title;

    @ColumnInfo(name = "start")
    private Date start;

    @ColumnInfo(name = "end")
    private Date end;

    public Term(String title, Date start, Date end) {
        this.title = title;
        this.start = start;
        this.end = end;
    }

    public long getTermId() {
        return termId;
    }

    public void setTermId(long termId) {
        this.termId = termId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Date getStart() {
        return start;
    }

    public void setStart(Date start) {
        this.start = start;
    }

    public Date getEnd() {
        return end;
    }

    public void setEnd(Date end) {
        this.end = end;
    }

}
