package com.wgu.wguscheduler.packages.custom_events;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import static com.wgu.wguscheduler.packages.custom_events.ConstantCustomEvents.SELECTED_CUSTOM_EVENT;

import com.wgu.wguscheduler.CustomEventDetailsActivity;
import com.wgu.wguscheduler.R;

import org.jetbrains.annotations.NotNull;

public class CustomEventAdapter extends ListAdapter<CustomEvent, CustomEventAdapter.CustomEventViewHolder> {
    private final Activity context;
    public CustomEventAdapter(@NonNull @NotNull DiffUtil.ItemCallback<CustomEvent> diffCallback, Activity context) {
        super(diffCallback);
        this.context = context;
    }

    @NonNull @NotNull @Override
    public CustomEventAdapter.CustomEventViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return CustomEventAdapter.CustomEventViewHolder.create(parent);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull CustomEventAdapter.CustomEventViewHolder holder, int position) {
        CustomEvent customEvent = getItem(position);
        holder.bind(customEvent, context);
    }

    public static class CustomEventDiff extends DiffUtil.ItemCallback<CustomEvent> {
        @Override
        public boolean areItemsTheSame(@NonNull @NotNull CustomEvent oldItem, @NonNull @NotNull CustomEvent newItem) {
            return oldItem == newItem;
        }

        @Override
        public boolean areContentsTheSame(@NonNull @NotNull CustomEvent oldItem, @NonNull @NotNull CustomEvent newItem) {
            return oldItem.getTitle().equals(newItem.getTitle());
        }
    }


    public static class CustomEventViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        LinearLayout linearLayout;

        public CustomEventViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.parent_term_text);
            linearLayout = itemView.findViewById(R.id.parent_term_item);
        }


        public void bind(CustomEvent customEvent, Activity context) {
            textView.setText(customEvent.getTitle());
            linearLayout.setOnClickListener(view -> {
                SELECTED_CUSTOM_EVENT = customEvent;
                Intent intent = new Intent(context, CustomEventDetailsActivity.class);
                context.startActivity(intent);
            });
        }

        public static CustomEventAdapter.CustomEventViewHolder create(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_row_main, parent, false);
            return new CustomEventAdapter.CustomEventViewHolder(view);
        }
    }
}

