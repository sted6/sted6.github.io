package com.wgu.wguscheduler.packages.terms;

import androidx.lifecycle.LiveData;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Transaction;
import androidx.room.Update;

import java.util.List;

import static androidx.room.OnConflictStrategy.REPLACE;

@Dao
public interface TermDao {
    @Insert(onConflict = REPLACE)
    long insert(Term term);

    @Delete
    void delete(Term term);

    @Query("DELETE FROM terms")
    void resetAll();

    @Update
    void update(Term term);

    @Query("SELECT * FROM terms")
    List<Term> getAllTerms();

    @Query("SELECT * FROM terms")
    LiveData<List<Term>> getAllTermsLive();

    @Query("SELECT * FROM terms WHERE termId = :id")
    Term getTermById(long id);

}
