package com.wgu.wguscheduler.packages.terms;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.wgu.wguscheduler.R;
import com.wgu.wguscheduler.databinding.FragmentTermsBinding;

public class TermsFragment extends Fragment {
    private TextView noTermsText;

    public TermsFragment() {}

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        TermsViewModel termsViewModel = new ViewModelProvider(requireActivity()).get(TermsViewModel.class);
        View root = inflater.inflate(R.layout.fragment_terms, container, false);
        noTermsText = root.findViewById(R.id.terms_no_terms_text);

        RecyclerView recyclerViewTerms = root.findViewById(R.id.recycler_view_terms);
        TermAdapter adapter = new TermAdapter(new TermAdapter.TermDiff(), getActivity());
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());

        recyclerViewTerms.setLayoutManager(layoutManager);
        recyclerViewTerms.setAdapter(adapter);

        termsViewModel.getTermsLive().observe(getViewLifecycleOwner(), (terms) -> {
            if (terms.size() > 0) {
                noTermsText.setVisibility(View.GONE);
            } else {
                noTermsText.setVisibility(View.VISIBLE);
            }
            adapter.submitList(terms);
        });

        FloatingActionButton fab = root.findViewById(R.id.fab);

        fab.setOnClickListener(view1 -> Navigation.findNavController(view1).navigate(R.id.action_termsFragment_to_addTermFragment));

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }
}