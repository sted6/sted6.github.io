package com.wgu.wguscheduler.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import com.wgu.wguscheduler.packages.assessments.Assessment;
import com.wgu.wguscheduler.packages.assessments.AssessmentDao;
import com.wgu.wguscheduler.packages.courses.Course;
import com.wgu.wguscheduler.packages.courses.CourseDao;
import com.wgu.wguscheduler.packages.custom_events.CustomEvent;
import com.wgu.wguscheduler.packages.custom_events.CustomEventDao;
import com.wgu.wguscheduler.packages.instructors.Instructor;
import com.wgu.wguscheduler.packages.instructors.InstructorDao;
import com.wgu.wguscheduler.packages.terms.Term;
import com.wgu.wguscheduler.packages.terms.TermDao;


@Database(entities = {Term.class, Assessment.class, Course.class, Instructor.class, CustomEvent.class}, version = 1, exportSchema = false)
@TypeConverters({Converters.class})
public abstract class RoomDB extends RoomDatabase {
    private static RoomDB database;

    private static String DATABASE_NAME = "database";

    public synchronized static RoomDB getInstance(Context context) {
        if (database == null) {
            database = Room.databaseBuilder(context.getApplicationContext(), RoomDB.class, DATABASE_NAME)
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return database;
    }

    public abstract AssessmentDao assessmentDao();
    public abstract CourseDao courseDao();
    public abstract TermDao termDao();
    public abstract InstructorDao instructorDao();
    public abstract CustomEventDao customEventDao();

}
