package com.wgu.wguscheduler.packages.assessments;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.wgu.wguscheduler.R;

import org.jetbrains.annotations.NotNull;

public class CourseAssessmentsAdapter extends ListAdapter<Assessment, CourseAssessmentsAdapter.AssessmentViewHolder> {
private final Activity context;
public CourseAssessmentsAdapter(@NonNull @NotNull DiffUtil.ItemCallback<Assessment> diffCallback, Activity context) {
        super(diffCallback);
        this.context = context;
        }

@NonNull @NotNull @Override
public CourseAssessmentsAdapter.AssessmentViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return CourseAssessmentsAdapter.AssessmentViewHolder.create(parent);
        }

@Override
public void onBindViewHolder(@NonNull @NotNull CourseAssessmentsAdapter.AssessmentViewHolder holder, int position) {
        Assessment assessment = getItem(position);
        holder.bind(assessment, context);
        }

public static class AssessmentDiff extends DiffUtil.ItemCallback<Assessment> {
    @Override
    public boolean areItemsTheSame(@NonNull @NotNull Assessment oldItem, @NonNull @NotNull Assessment newItem) {
        return oldItem == newItem;
    }

    @Override
    public boolean areContentsTheSame(@NonNull @NotNull Assessment oldItem, @NonNull @NotNull Assessment newItem) {
        return oldItem.getTitle().equals(newItem.getTitle());
    }
}


public static class AssessmentViewHolder extends RecyclerView.ViewHolder {
    TextView textView;
    CheckBox checkbox;
    AssessmentViewModel assessmentViewModel;

    public AssessmentViewHolder(@NonNull @NotNull View itemView) {
        super(itemView);
        textView = itemView.findViewById(R.id.child_text);
        checkbox = itemView.findViewById(R.id.child_checkbox);
    }


    public void bind(Assessment assessment, Activity context) {
        assessmentViewModel = ViewModelProviders.of((FragmentActivity)context).get(AssessmentViewModel.class);
        textView.setText(assessment.getTitle());
        checkbox.setChecked(false);
        assessmentViewModel.resetSelectedAssessments();
        checkbox.setOnClickListener(view -> {
            if (checkbox.isChecked()) {
                assessmentViewModel.addAssessmentToSelectedList(assessment);
            } else {
                assessmentViewModel.removeAssessmentFromSelectedList(assessment);
            }
        });
    }

    public static CourseAssessmentsAdapter.AssessmentViewHolder create(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_item, parent, false);
        return new CourseAssessmentsAdapter.AssessmentViewHolder(view);
    }
}
}