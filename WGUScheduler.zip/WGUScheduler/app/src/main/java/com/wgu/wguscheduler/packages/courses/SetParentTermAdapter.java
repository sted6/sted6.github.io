package com.wgu.wguscheduler.packages.courses;

import android.app.Activity;

import android.app.Dialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.wgu.wguscheduler.R;
import com.wgu.wguscheduler.packages.terms.Term;

import org.jetbrains.annotations.NotNull;

public class SetParentTermAdapter extends ListAdapter<Term, SetParentTermAdapter.TermViewHolder> {
    private final Activity context;
    private final Dialog dialog;

    public SetParentTermAdapter(@NonNull DiffUtil.ItemCallback<Term> diffCallback, Activity context, Dialog dialog) {
        super(diffCallback);
        this.context = context;
        this.dialog = dialog;
    }

    @NonNull @NotNull @Override
    public TermViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return TermViewHolder.create(parent);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull TermViewHolder holder, int position) {
        Term term = getItem(position);
        holder.bind(term, context, dialog);
    }

    public static class TermDiff extends DiffUtil.ItemCallback<Term> {
        @Override
        public boolean areItemsTheSame(@NonNull Term oldItem, @NonNull Term newItem) {
            return oldItem == newItem;
        }
        @Override
        public boolean areContentsTheSame(@NonNull Term oldItem, @NonNull Term newItem) {
            return oldItem.getTitle().equals(newItem.getTitle());
        }
    }

    public static class TermViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        ImageView btEdit, btDelete;
        LinearLayout linearLayout;
        CoursesViewModel coursesViewModel;

        private TermViewHolder(View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.parent_term_text);
            linearLayout = itemView.findViewById(R.id.parent_term_item);
        }

        public void bind(Term term, Activity context, Dialog dialog){
            textView.setText(term.getTitle());
            linearLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    coursesViewModel = ViewModelProviders.of((FragmentActivity)context).get(CoursesViewModel.class);
                    coursesViewModel.setParentTerm(term);
                    dialog.dismiss();
                }
            });
        }

        public static TermViewHolder create(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.set_parent_term_item, parent, false);

            return new TermViewHolder(view);
        }

    }

}
