package com.wgu.wguscheduler.packages.courses;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import static androidx.room.OnConflictStrategy.REPLACE;

@Dao
public interface CourseDao {
    @Insert(onConflict = REPLACE)
    long insert(Course course);

    @Delete
    void delete(Course course);

    @Update
    void update(Course course);

    @Query("SELECT * FROM courses WHERE courseId = :id")
    Course getCourseById(long id);

    @Query("SELECT * FROM courses")
    List<Course> getAllCourses();

    @Query("SELECT * FROM courses")
    LiveData<List<Course>> getAllCoursesLive();

    @Query("SELECT * FROM courses WHERE termOwnerId = :id")
    LiveData<List<Course>> getCoursesByParentTermLive(long id);

    @Query("SELECT notes FROM courses WHERE courseId = :id")
    LiveData<List<String>> getCourseNotesByCourse(long id);

}
