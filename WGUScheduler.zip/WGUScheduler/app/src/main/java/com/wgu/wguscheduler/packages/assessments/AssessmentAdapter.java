package com.wgu.wguscheduler.packages.assessments;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.wgu.wguscheduler.R;

import org.jetbrains.annotations.NotNull;

public class AssessmentAdapter extends ListAdapter<Assessment, AssessmentAdapter.AssessmentViewHolder> {
    private final Activity context;
    protected AssessmentAdapter(@NonNull @NotNull DiffUtil.ItemCallback<Assessment> diffCallback, Activity context) {
        super(diffCallback);
        this.context = context;
    }

    @NonNull @NotNull @Override
    public AssessmentAdapter.AssessmentViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return AssessmentAdapter.AssessmentViewHolder.create(parent);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull AssessmentAdapter.AssessmentViewHolder holder, int position) {
        Assessment assessment = getItem(position);
        holder.bind(assessment, context);
    }

    public static class AssessmentDiff extends DiffUtil.ItemCallback<Assessment> {
        @Override
        public boolean areItemsTheSame(@NonNull @NotNull Assessment oldItem, @NonNull @NotNull Assessment newItem) {
            return oldItem == newItem;
        }

        @Override
        public boolean areContentsTheSame(@NonNull @NotNull Assessment oldItem, @NonNull @NotNull Assessment newItem) {
            return oldItem.getTitle().equals(newItem.getTitle());
        }
    }


    public static class AssessmentViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        LinearLayout linearLayout;
        AssessmentViewModel assessmentViewModel;

        public AssessmentViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.parent_term_text);
            linearLayout = itemView.findViewById(R.id.parent_term_item);
        }


        public void bind(Assessment assessment, Activity context) {
            textView.setText(assessment.getTitle());
            linearLayout.setOnClickListener(view -> {
                assessmentViewModel = ViewModelProviders.of((FragmentActivity)context).get(AssessmentViewModel.class);
                assessmentViewModel.setSelectedAssessment(assessment);
                Navigation.findNavController(view).navigate(R.id.action_assessmentsFragment_to_assessmentDetailsFragment);
            });
        }

        public static AssessmentAdapter.AssessmentViewHolder create(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_row_main, parent, false);
            return new AssessmentAdapter.AssessmentViewHolder(view);
        }
    }
}