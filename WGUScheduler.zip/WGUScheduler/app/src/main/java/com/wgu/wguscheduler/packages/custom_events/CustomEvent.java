package com.wgu.wguscheduler.packages.custom_events;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Date;

@Entity
public class CustomEvent {
    @PrimaryKey(autoGenerate = true)
    private long id;

    @ColumnInfo
    private String title;

    @ColumnInfo
    private String type;

    @ColumnInfo
    private Date startDate;

    @ColumnInfo
    private Date endDate;

    @ColumnInfo
    private boolean fiveMinAlertStart;
    @ColumnInfo
    private boolean fifteenMinAlertStart;
    @ColumnInfo
    private boolean thirtyMinAlertStart;
    @ColumnInfo
    private boolean oneHourAlertStart;
    @ColumnInfo
    private boolean sixHourAlertStart;
    @ColumnInfo
    private boolean twelveHourAlertStart;
    @ColumnInfo
    private boolean oneDayAlertStart;
    @ColumnInfo
    private boolean twoDayAlertStart;
    @ColumnInfo
    private boolean oneWeekAlertStart;
    @ColumnInfo
    private boolean twoWeekAlertStart;
    @ColumnInfo
    private boolean oneMonthAlertStart;

    @ColumnInfo
    private boolean fiveMinAlertEnd;
    @ColumnInfo
    private boolean fifteenMinAlertEnd;
    @ColumnInfo
    private boolean thirtyMinAlertEnd;
    @ColumnInfo
    private boolean oneHourAlertEnd;
    @ColumnInfo
    private boolean sixHourAlertEnd;
    @ColumnInfo
    private boolean twelveHourAlertEnd;
    @ColumnInfo
    private boolean oneDayAlertEnd;
    @ColumnInfo
    private boolean twoDayAlertEnd;
    @ColumnInfo
    private boolean oneWeekAlertEnd;
    @ColumnInfo
    private boolean twoWeekAlertEnd;
    @ColumnInfo
    private boolean oneMonthAlertEnd;

    public CustomEvent(String title, String type, Date startDate, Date endDate) {
        this.title = title;
        this.type = type;
        this.startDate = startDate;
        this.endDate = endDate;
        this.fiveMinAlertStart = false;
        this.fifteenMinAlertStart = false;
        this.thirtyMinAlertStart = false;
        this.oneHourAlertStart = false;
        this.sixHourAlertStart = false;
        this.twelveHourAlertStart = false;
        this.oneDayAlertStart = false;
        this.twoDayAlertStart = false;
        this.oneWeekAlertStart = false;
        this.twoWeekAlertStart = false;
        this.oneMonthAlertStart = false;
        this.fiveMinAlertEnd = false;
        this.fifteenMinAlertEnd = false;
        this.thirtyMinAlertEnd = false;
        this.oneHourAlertEnd = false;
        this.sixHourAlertEnd = false;
        this.twelveHourAlertEnd = false;
        this.oneDayAlertEnd = false;
        this.twoDayAlertEnd = false;
        this.oneWeekAlertEnd = false;
        this.twoWeekAlertEnd = false;
        this.oneMonthAlertEnd = false;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public boolean isFiveMinAlertStart() {
        return fiveMinAlertStart;
    }

    public void setFiveMinAlertStart(boolean fiveMinAlertStart) {
        this.fiveMinAlertStart = fiveMinAlertStart;
    }

    public boolean isFifteenMinAlertStart() {
        return fifteenMinAlertStart;
    }

    public void setFifteenMinAlertStart(boolean fifteenMinAlertStart) {
        this.fifteenMinAlertStart = fifteenMinAlertStart;
    }

    public boolean isThirtyMinAlertStart() {
        return thirtyMinAlertStart;
    }

    public void setThirtyMinAlertStart(boolean thirtyMinAlertStart) {
        this.thirtyMinAlertStart = thirtyMinAlertStart;
    }

    public boolean isOneHourAlertStart() {
        return oneHourAlertStart;
    }

    public void setOneHourAlertStart(boolean oneHourAlertStart) {
        this.oneHourAlertStart = oneHourAlertStart;
    }

    public boolean isSixHourAlertStart() {
        return sixHourAlertStart;
    }

    public void setSixHourAlertStart(boolean sixHourAlertStart) {
        this.sixHourAlertStart = sixHourAlertStart;
    }

    public boolean isTwelveHourAlertStart() {
        return twelveHourAlertStart;
    }

    public void setTwelveHourAlertStart(boolean twelveHourAlertStart) {
        this.twelveHourAlertStart = twelveHourAlertStart;
    }

    public boolean isOneDayAlertStart() {
        return oneDayAlertStart;
    }

    public void setOneDayAlertStart(boolean oneDayAlertStart) {
        this.oneDayAlertStart = oneDayAlertStart;
    }

    public boolean isTwoDayAlertStart() {
        return twoDayAlertStart;
    }

    public void setTwoDayAlertStart(boolean twoDayAlertStart) {
        this.twoDayAlertStart = twoDayAlertStart;
    }

    public boolean isOneWeekAlertStart() {
        return oneWeekAlertStart;
    }

    public void setOneWeekAlertStart(boolean oneWeekAlertStart) {
        this.oneWeekAlertStart = oneWeekAlertStart;
    }

    public boolean isTwoWeekAlertStart() {
        return twoWeekAlertStart;
    }

    public void setTwoWeekAlertStart(boolean twoWeekAlertStart) {
        this.twoWeekAlertStart = twoWeekAlertStart;
    }

    public boolean isOneMonthAlertStart() {
        return oneMonthAlertStart;
    }

    public void setOneMonthAlertStart(boolean oneMonthAlertStart) {
        this.oneMonthAlertStart = oneMonthAlertStart;
    }

    public boolean isFiveMinAlertEnd() {
        return fiveMinAlertEnd;
    }

    public void setFiveMinAlertEnd(boolean fiveMinAlertEnd) {
        this.fiveMinAlertEnd = fiveMinAlertEnd;
    }

    public boolean isFifteenMinAlertEnd() {
        return fifteenMinAlertEnd;
    }

    public void setFifteenMinAlertEnd(boolean fifteenMinAlertEnd) {
        this.fifteenMinAlertEnd = fifteenMinAlertEnd;
    }

    public boolean isThirtyMinAlertEnd() {
        return thirtyMinAlertEnd;
    }

    public void setThirtyMinAlertEnd(boolean thirtyMinAlertEnd) {
        this.thirtyMinAlertEnd = thirtyMinAlertEnd;
    }

    public boolean isOneHourAlertEnd() {
        return oneHourAlertEnd;
    }

    public void setOneHourAlertEnd(boolean oneHourAlertEnd) {
        this.oneHourAlertEnd = oneHourAlertEnd;
    }

    public boolean isSixHourAlertEnd() {
        return sixHourAlertEnd;
    }

    public void setSixHourAlertEnd(boolean sixHourAlertEnd) {
        this.sixHourAlertEnd = sixHourAlertEnd;
    }

    public boolean isTwelveHourAlertEnd() {
        return twelveHourAlertEnd;
    }

    public void setTwelveHourAlertEnd(boolean twelveHourAlertEnd) {
        this.twelveHourAlertEnd = twelveHourAlertEnd;
    }

    public boolean isOneDayAlertEnd() {
        return oneDayAlertEnd;
    }

    public void setOneDayAlertEnd(boolean oneDayAlertEnd) {
        this.oneDayAlertEnd = oneDayAlertEnd;
    }

    public boolean isTwoDayAlertEnd() {
        return twoDayAlertEnd;
    }

    public void setTwoDayAlertEnd(boolean twoDayAlertEnd) {
        this.twoDayAlertEnd = twoDayAlertEnd;
    }

    public boolean isOneWeekAlertEnd() {
        return oneWeekAlertEnd;
    }

    public void setOneWeekAlertEnd(boolean oneWeekAlertEnd) {
        this.oneWeekAlertEnd = oneWeekAlertEnd;
    }

    public boolean isTwoWeekAlertEnd() {
        return twoWeekAlertEnd;
    }

    public void setTwoWeekAlertEnd(boolean twoWeekAlertEnd) {
        this.twoWeekAlertEnd = twoWeekAlertEnd;
    }

    public boolean isOneMonthAlertEnd() {
        return oneMonthAlertEnd;
    }

    public void setOneMonthAlertEnd(boolean oneMonthAlertEnd) {
        this.oneMonthAlertEnd = oneMonthAlertEnd;
    }
}
