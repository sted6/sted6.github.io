package com.wgu.wguscheduler;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.wgu.wguscheduler.packages.custom_events.CustomEventAdapter;
import com.wgu.wguscheduler.packages.custom_events.CustomEventsViewModel;


public class SchedulerActivity extends AppCompatActivity {
    private final static int ADD_CUSTOM_EVENT_REQUEST = 1;

    @Override
    protected void onCreate(@Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scheduler);

        TextView noEventsText = findViewById(R.id.scheduler_not_custom_events_text);

        RecyclerView customEventsRecycler = findViewById(R.id.scheduler_recycler_view_custom_events);
        CustomEventAdapter customEventAdapter = new CustomEventAdapter(new CustomEventAdapter.CustomEventDiff(), this);
        RecyclerView.LayoutManager customEventLayoutManager = new LinearLayoutManager(this);
        customEventsRecycler.setLayoutManager(customEventLayoutManager);
        customEventsRecycler.setAdapter(customEventAdapter);

        CustomEventsViewModel customEventsViewModel = new CustomEventsViewModel(this.getApplication());

        customEventsViewModel.getCustomEventsLive().observe(this, customEvents -> {
            customEventAdapter.submitList(customEvents);
            if (customEvents.size() > 0) {
                noEventsText.setVisibility(View.INVISIBLE);
            } else {
                noEventsText.setVisibility(View.VISIBLE);
            }
        });

        FloatingActionButton addCustomEventBtn = findViewById(R.id.scheduler_fab);
        addCustomEventBtn.setOnClickListener(view -> {
            Intent intent = new Intent(SchedulerActivity.this, AddCustomEventActivity.class);
            startActivityForResult(intent, ADD_CUSTOM_EVENT_REQUEST);
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
