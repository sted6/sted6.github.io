package com.wgu.wguscheduler.packages.courses;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.wgu.wguscheduler.R;

import org.jetbrains.annotations.NotNull;

public class CourseNotesAdapter extends ListAdapter<String, CourseNotesAdapter.NotesViewHolder> {
    private final Activity context;

    protected CourseNotesAdapter(@NonNull @NotNull DiffUtil.ItemCallback<String> diffCallback, Activity context) {
        super(diffCallback);
        this.context = context;
    }

    @NonNull @NotNull @Override
    public CourseNotesAdapter.NotesViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return CourseNotesAdapter.NotesViewHolder.create(parent);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull CourseNotesAdapter.NotesViewHolder holder, int position) {
        String note = getItem(position);
        holder.bind(note, context);
    }

    public static class NoteDiff extends DiffUtil.ItemCallback<String> {
        @Override
        public boolean areItemsTheSame(@NonNull @NotNull String oldItem, @NonNull @NotNull String newItem) {
            return oldItem.equals(newItem);
        }

        @Override
        public boolean areContentsTheSame(@NonNull @NotNull String oldItem, @NonNull @NotNull String newItem) {
            return oldItem.equals(newItem);
        }
    }


    public static class NotesViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        CheckBox notesCheckbox;
        CoursesViewModel coursesViewModel;

        public NotesViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);

            textView = itemView.findViewById(R.id.child_text);
            notesCheckbox = itemView.findViewById(R.id.child_checkbox);
        }


        public void bind(String note, Activity context) {
            coursesViewModel = ViewModelProviders.of((FragmentActivity)context).get(CoursesViewModel.class);
            textView.setText(note);
            notesCheckbox.setChecked(false);
            coursesViewModel.resetSelectedNotesList();
            notesCheckbox.setOnClickListener(view -> {
                if (notesCheckbox.isChecked()) {
                    coursesViewModel.addNoteToSelectedList(note);
                } else {
                    coursesViewModel.removeNoteFromSelectedList(note);
                }
            });
        }

        public static CourseNotesAdapter.NotesViewHolder create(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_item, parent, false);
            return new CourseNotesAdapter.NotesViewHolder(view);
        }
    }

}
