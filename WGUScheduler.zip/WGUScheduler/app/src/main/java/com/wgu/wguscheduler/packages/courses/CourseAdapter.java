package com.wgu.wguscheduler.packages.courses;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.wgu.wguscheduler.R;

import org.jetbrains.annotations.NotNull;

public class CourseAdapter extends ListAdapter<Course, CourseAdapter.CourseViewHolder> {
    private final Activity context;
    protected CourseAdapter(@NonNull @NotNull DiffUtil.ItemCallback<Course> diffCallback, Activity context) {
        super(diffCallback);
        this.context = context;
    }

    @NonNull @NotNull @Override
    public CourseAdapter.CourseViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return CourseViewHolder.create(parent);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull CourseAdapter.CourseViewHolder holder, int position) {
        Course course = getItem(position);
        holder.bind(course, context);
    }

    public static class CourseDiff extends DiffUtil.ItemCallback<Course> {
        @Override
        public boolean areItemsTheSame(@NonNull @NotNull Course oldItem, @NonNull @NotNull Course newItem) {
            return oldItem == newItem;
        }

        @Override
        public boolean areContentsTheSame(@NonNull @NotNull Course oldItem, @NonNull @NotNull Course newItem) {
            return oldItem.getTitle().equals(newItem.getTitle());
        }
    }


    public static class CourseViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        LinearLayout linearLayout;
        CoursesViewModel coursesViewModel;

        public CourseViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.parent_term_text);
            linearLayout = itemView.findViewById(R.id.parent_term_item);
        }


        public void bind(Course course, Activity context) {
            textView.setText(course.getTitle());
            linearLayout.setOnClickListener(view -> {
                coursesViewModel = ViewModelProviders.of((FragmentActivity)context).get(CoursesViewModel.class);
                coursesViewModel.setSelectedCourse(course);
                Navigation.findNavController(view).navigate(R.id.action_coursesFragment_to_courseDetailsFragment);
            });
        }

        public static CourseViewHolder create(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_row_main, parent, false);
            return new CourseViewHolder(view);
        }
    }
}
