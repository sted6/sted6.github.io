package com.wgu.wguscheduler.packages.instructors;


import android.app.Activity;
import android.app.Dialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.wgu.wguscheduler.R;

import org.jetbrains.annotations.NotNull;

public class InstructorDetailsAdapter extends ListAdapter<Instructor, InstructorDetailsAdapter.InstructorViewHolder> {
    private Activity context;
    public InstructorDetailsAdapter(@NonNull @NotNull DiffUtil.ItemCallback<Instructor> diffCallback, Activity context) {
        super(diffCallback);
        this.context = context;
    }

    @NonNull @NotNull @Override
    public InstructorDetailsAdapter.InstructorViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return InstructorDetailsAdapter.InstructorViewHolder.create(parent);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull InstructorDetailsAdapter.InstructorViewHolder holder, int position) {
        Instructor instructor = getItem(position);
        holder.bind(instructor, context);
    }

    public static class InstructorDiff extends DiffUtil.ItemCallback<Instructor> {
        @Override
        public boolean areItemsTheSame(@NonNull @NotNull Instructor oldItem, @NonNull @NotNull Instructor newItem) {
            return oldItem == newItem;
        }

        @Override
        public boolean areContentsTheSame(@NonNull @NotNull Instructor oldItem, @NonNull @NotNull Instructor newItem) {
            return oldItem.getInstructorId() == (newItem.getInstructorId());
        }
    }


    public static class InstructorViewHolder extends RecyclerView.ViewHolder {
        TextView nameText;
        TextView emailText;
        TextView phoneText;
        ImageView editBtn;
        InstructorsViewModel instructorsViewModel;

        public InstructorViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            nameText = itemView.findViewById(R.id.instructor_details_name_text);
            emailText = itemView.findViewById(R.id.instructor_details_email_text);
            phoneText = itemView.findViewById(R.id.instructor_details_phone);
            editBtn = itemView.findViewById(R.id.instructor_details_edit_btn);
        }


        public void bind(Instructor instructor, Activity context) {
            instructorsViewModel = ViewModelProviders.of((FragmentActivity)context).get(InstructorsViewModel.class);
            nameText.setText(instructor.getFirstName() + " " + instructor.getLastName());
            emailText.setText(instructor.getEmail());
            phoneText.setText(instructor.getPhoneNumber());
            editBtn.setOnClickListener(view -> {
                Dialog dialog = new Dialog(context);
                dialog.setContentView(R.layout.create_new_instructor);
                int width = WindowManager.LayoutParams.MATCH_PARENT;
                int height = WindowManager.LayoutParams.WRAP_CONTENT;
                dialog.getWindow().setLayout(width, height);

                TextView title = dialog.findViewById(R.id.add_instructor_title_text);
                EditText editFirstName = dialog.findViewById(R.id.create_new_instructor_first_name_edit_text);
                EditText editLastName = dialog.findViewById(R.id.create_new_instructor_last_name_edit_text);
                EditText editEmail = dialog.findViewById(R.id.create_new_instructor_email_edit_text);
                EditText editPhone = dialog.findViewById(R.id.create_new_instructor_phone_edit_text);

                Button cancelBtn = dialog.findViewById(R.id.create_new_instructor_cancel_btn);
                Button saveBtn = dialog.findViewById(R.id.create_new_instructor_save_btn);

                title.setText("Edit Instructor");
                editFirstName.setText(instructor.getFirstName());
                editLastName.setText(instructor.getLastName());
                editEmail.setText(instructor.getEmail());
                editPhone.setText(instructor.getPhoneNumber());

                cancelBtn.setOnClickListener(view1 -> {
                    dialog.dismiss();
                });

                saveBtn.setOnClickListener(view1 -> {
                    instructor.setFirstName(editFirstName.getText().toString().trim());
                    instructor.setLastName(editLastName.getText().toString().trim());
                    instructor.setEmail(editEmail.getText().toString().trim());
                    instructor.setPhoneNumber(editPhone.getText().toString().trim());
                    instructorsViewModel.updateInstructor(instructor);
                    dialog.dismiss();
                });

                dialog.show();
            });

        }

        public static InstructorDetailsAdapter.InstructorViewHolder create(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.instructor_details, parent, false);
            return new InstructorDetailsAdapter.InstructorViewHolder(view);
        }
    }
}
