package com.wgu.wguscheduler.packages.assessments;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import static androidx.room.OnConflictStrategy.REPLACE;

@Dao
public interface AssessmentDao {
    @Insert(onConflict = REPLACE)
    long insert(Assessment assessment);

    @Delete
    void delete(Assessment assessment);

    @Update
    void update(Assessment assessment);

    @Query("SELECT * FROM assessments")
    LiveData<List<Assessment>> getAllAssessmentsLive();

    @Query("SELECT * FROM assessments WHERE courseOwnerId = :id")
    LiveData<List<Assessment>> getAssessmentsByCourseOwnerLive(long id);
}
