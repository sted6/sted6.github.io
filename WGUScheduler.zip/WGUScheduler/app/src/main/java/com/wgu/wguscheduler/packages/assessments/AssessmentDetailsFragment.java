package com.wgu.wguscheduler.packages.assessments;

import android.app.AlarmManager;
import android.app.Dialog;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.app.NotificationCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.wgu.wguscheduler.NotificationBroadcast;
import com.wgu.wguscheduler.R;
import com.wgu.wguscheduler.packages.courses.Course;
import com.wgu.wguscheduler.packages.courses.CoursesViewModel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import static com.wgu.wguscheduler.MainActivity.NOTIFICATION_CHANNEL_ID;


public class AssessmentDetailsFragment extends Fragment {
    private AssessmentViewModel assessmentsViewModel;
    private CoursesViewModel coursesViewModel;
    private AlarmManager alarmManager;
    
    private Assessment assessment;
    private long assessmentId;
    private String assessmentTitle;
    private String assessmentType;
    private Date assessmentStartDate;
    private Date assessmentEndDate;
    private Course assessmentParentCourse;

    private boolean fiveMinAlertStart;
    private boolean fifteenMinAlertStart;
    private boolean thirtyMinAlertStart;
    private boolean oneHourAlertStart;
    private boolean sixHourAlertStart;
    private boolean twelveHourAlertStart;
    private boolean oneDayAlertStart;
    private boolean twoDayAlertStart;
    private boolean oneWeekAlertStart;
    private boolean twoWeekAlertStart;
    private boolean oneMonthAlertStart;

    private boolean fiveMinAlertEnd;
    private boolean fifteenMinAlertEnd;
    private boolean thirtyMinAlertEnd;
    private boolean oneHourAlertEnd;
    private boolean sixHourAlertEnd;
    private boolean twelveHourAlertEnd;
    private boolean oneDayAlertEnd;
    private boolean twoDayAlertEnd;
    private boolean oneWeekAlertEnd;
    private boolean twoWeekAlertEnd;
    private boolean oneMonthAlertEnd;

    private EditText editTitle;
    private TextView parentCourseText;
    private TextView startDateText;
    private TextView endDateText;

    private RadioGroup assessmentTypeRadioGroup;


    public AssessmentDetailsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_assessment_details, container, false);
        assessmentsViewModel = ViewModelProviders.of(requireActivity()).get(AssessmentViewModel.class);
        coursesViewModel = ViewModelProviders.of(requireActivity()).get(CoursesViewModel.class);
        alarmManager = (AlarmManager) getActivity().getSystemService(Context.ALARM_SERVICE);

        assessment = assessmentsViewModel.getSelectedAssessment();
        assessmentId = assessment.getAssessmentId();
        assessmentTitle = assessment.getTitle();
        assessmentType = assessment.getType();
        assessmentStartDate = assessment.getStartDate();
        assessmentEndDate = assessment.getEndDate();
        long assessmentParentCourseId = assessment.getCourseOwnerId();
        assessmentParentCourse = coursesViewModel.getCourseById(assessmentParentCourseId);

        TextView assessmentIdText = root.findViewById(R.id.assessment_details_assessment_id_text);
        assessmentIdText.setText("Assessment ID: " + assessmentId);

        editTitle = root.findViewById(R.id.assessment_details_edit_text_assessment_title);
        editTitle.setText(assessmentTitle);

        Button setParentCourseBtn = root.findViewById(R.id.assessment_details_set_parent_course_btn);
        parentCourseText = root.findViewById(R.id.assessment_details_parent_course_text);
        if (assessmentParentCourse != null) {
            parentCourseText.setText("Parent Course: " + assessmentParentCourse.getTitle());
        }

        assessmentTypeRadioGroup = root.findViewById(R.id.assessment_details_type_radio_group);

        if (assessmentType.equals("Objective")) {
            assessmentTypeRadioGroup.check(R.id.assessment_details_objective_radio);
        } else {
            assessmentTypeRadioGroup.check(R.id.assessment_details_performance_radio);
        }

        startDateText = root.findViewById(R.id.assessment_details_start_date_text);
        endDateText = root.findViewById(R.id.assessment_details_end_date_text);

        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
        startDateText.setText("Assessment Start Date: " + sdf.format(assessmentStartDate));
        endDateText.setText("Assessment End Date: " + sdf.format(assessmentEndDate));

        Button startDateBtn = root.findViewById(R.id.assessment_details_update_start_btn);
        Button endDateBtn = root.findViewById(R.id.assessment_details_update_end_btn);
        Button setAlertsBtn = root.findViewById(R.id.assessment_details_set_alerts_btn);

        Button cancelBtn1 = root.findViewById(R.id.assessment_details_cancel_btn);
        Button addAssessmentBtn = root.findViewById(R.id.assessment_details_update_assessment_btn);
        Button deleteAssessmentBtn = root.findViewById(R.id.assessment_details_delete_assessment_btn);

        deleteAssessmentBtn.setOnClickListener(view -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setMessage("Are you sure you want to delete this Assessment?");
            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    assessmentsViewModel.deleteAssessment(assessment);
                    Navigation.findNavController(root).navigate(R.id.action_assessmentDetailsFragment_to_assessmentsFragment);
                }
            });
            builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.dismiss();
                }
            });
            AlertDialog dialog = builder.create();
            dialog.show();
        });


        setParentCourseBtn.setOnClickListener(view -> {
            SetParentCourseAdapter setParentCourseAdapter;
            RecyclerView setParentRecyclerView;
            RecyclerView.LayoutManager layoutManager;

            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.set_parent_term);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);

            Button cancelBtn = dialog.findViewById(R.id.set_parent_term_cancel_btn);
            cancelBtn.setOnClickListener(view1 -> dialog.dismiss());

            setParentCourseAdapter = new SetParentCourseAdapter(new SetParentCourseAdapter.CourseDiff(), getActivity(), dialog);
            layoutManager = new LinearLayoutManager(dialog.getContext());
            coursesViewModel = ViewModelProviders.of(getActivity()).get(CoursesViewModel.class);
            coursesViewModel.getCoursesLive().observe(getViewLifecycleOwner(), setParentCourseAdapter::submitList);

            setParentRecyclerView = dialog.findViewById(R.id.recycler_view_parent_terms);

            setParentRecyclerView.setAdapter(setParentCourseAdapter);
            setParentRecyclerView.setLayoutManager(layoutManager);
            setParentCourseAdapter.notifyDataSetChanged();
            dialog.show();
            dialog.setOnDismissListener( data -> {
                assessmentParentCourse = assessmentsViewModel.getParentCourse();
                if (assessmentParentCourse != null) {
                    parentCourseText.setText("Parent Course: " + assessmentParentCourse.getTitle());
                }
            });
        });


        startDateBtn.setOnClickListener(view1 -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.datepicker);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.show();

            DatePicker datePicker = dialog.findViewById(R.id.datePicker);

            if (assessmentStartDate != null) {
                SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String endDateString = sdf1.format(assessmentStartDate);
                String[] dateArr = endDateString.split("-");
                int startDay = Integer.parseInt(dateArr[0]);
                int startMonth = Integer.parseInt(dateArr[1])-1;
                int startYear = Integer.parseInt(dateArr[2]);
                datePicker.updateDate(startYear, startMonth, startDay);
            }
            Button addDateBtn = dialog.findViewById(R.id.btn_datepicker_add);
            Button cancelDateBtn = dialog.findViewById(R.id.btn_datepicker_cancel);

            addDateBtn.setOnClickListener(view2 -> {
                int day  = datePicker.getDayOfMonth();
                int month= datePicker.getMonth();
                int year = datePicker.getYear();
                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, day);

                SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String formattedDate = sdf2.format(calendar.getTime());
                try {
                    Date date = sdf2.parse(formattedDate);
                    assessmentStartDate = date;
                    sdf2 = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
                    formattedDate = sdf2.format(calendar.getTime());
                    startDateText.setText("Start Date: " + formattedDate);
                } catch (ParseException e) {
                    assessmentStartDate = new Date();
                    e.printStackTrace();
                }
                dialog.dismiss();
            });

            cancelDateBtn.setOnClickListener(view2 -> dialog.dismiss());
        });

        endDateBtn.setOnClickListener(view1 -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.datepicker);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.show();

            DatePicker datePicker = dialog.findViewById(R.id.datePicker);

            if (assessmentEndDate != null) {
                SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String endDateString = sdf2.format(assessmentEndDate);
                String[] dateArr = endDateString.split("-");
                int endDay = Integer.parseInt(dateArr[0]);
                int endMonth = Integer.parseInt(dateArr[1])-1;
                int endYear = Integer.parseInt(dateArr[2]);
                datePicker.updateDate(endYear, endMonth, endDay);
            }

            Button addDateBtn = dialog.findViewById(R.id.btn_datepicker_add);
            Button cancelDateBtn = dialog.findViewById(R.id.btn_datepicker_cancel);

            addDateBtn.setOnClickListener(view2 -> {
                int day  = datePicker.getDayOfMonth();
                int month= datePicker.getMonth();
                int year = datePicker.getYear();

                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, day);

                SimpleDateFormat sdf3 = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String formattedDate = sdf3.format(calendar.getTime());
                try {
                    Date date = sdf3.parse(formattedDate);
                    assessmentEndDate = date;
                    sdf3 = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
                    formattedDate = sdf3.format(calendar.getTime());
                    endDateText.setText("End Date: " + formattedDate);
                } catch (ParseException e) {
                    assessmentEndDate = new Date();
                    e.printStackTrace();
                }
                dialog.dismiss();
            });

            cancelDateBtn.setOnClickListener(view2 -> dialog.dismiss());
        });
        
        setAlertsBtn.setOnClickListener(view -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.add_alerts);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);

            fiveMinAlertStart = assessment.isFiveMinAlertStart();
            fifteenMinAlertStart = assessment.isFifteenMinAlertStart();
            thirtyMinAlertStart = assessment.isThirtyMinAlertStart();
            oneHourAlertStart = assessment.isOneHourAlertStart();
            sixHourAlertStart = assessment.isSixHourAlertStart();
            twelveHourAlertStart = assessment.isTwelveHourAlertStart();
            oneDayAlertStart = assessment.isOneDayAlertStart();
            twoDayAlertStart = assessment.isTwoDayAlertStart();
            oneWeekAlertStart = assessment.isOneWeekAlertStart();
            twoWeekAlertStart = assessment.isTwoWeekAlertStart();
            oneMonthAlertStart = assessment.isOneMonthAlertStart();

            fiveMinAlertEnd = assessment.isFiveMinAlertEnd();
            fifteenMinAlertEnd = assessment.isFifteenMinAlertEnd();
            thirtyMinAlertEnd = assessment.isThirtyMinAlertEnd();
            oneHourAlertEnd = assessment.isOneHourAlertEnd();
            sixHourAlertEnd = assessment.isSixHourAlertEnd();
            twelveHourAlertEnd = assessment.isTwelveHourAlertEnd();
            oneDayAlertEnd = assessment.isOneDayAlertEnd();
            twoDayAlertEnd = assessment.isTwoDayAlertEnd();
            oneWeekAlertEnd = assessment.isOneWeekAlertEnd();
            twoWeekAlertEnd = assessment.isTwoWeekAlertEnd();
            oneMonthAlertEnd = assessment.isOneMonthAlertEnd();

            SwitchCompat fiveMinSwitchStart = dialog.findViewById(R.id.add_alert_5min_switch);
            SwitchCompat fifteenMinSwitchStart = dialog.findViewById(R.id.add_alert_15min_switch);
            SwitchCompat thirtyMinSwitchStart = dialog.findViewById(R.id.add_alert_30min_switch);
            SwitchCompat oneHourSwitchStart = dialog.findViewById(R.id.add_alert_1hour_switch);
            SwitchCompat sixHoursSwitchStart = dialog.findViewById(R.id.add_alert_6hours_switch);
            SwitchCompat twelveHoursSwitchStart = dialog.findViewById(R.id.add_alert_12hours_switch);
            SwitchCompat oneDaySwitchStart = dialog.findViewById(R.id.add_alert_1day_switch);
            SwitchCompat twoDaysSwitchStart = dialog.findViewById(R.id.add_alert_2days_switch);
            SwitchCompat oneWeekSwitchStart = dialog.findViewById(R.id.add_alert_1week_switch);
            SwitchCompat twoWeeksSwitchStart = dialog.findViewById(R.id.add_alert_2weeks_switch);
            SwitchCompat oneMonthSwitchStart = dialog.findViewById(R.id.add_alert_1month_switch);

            SwitchCompat fiveMinSwitchEnd = dialog.findViewById(R.id.add_alert_5min_switch2);
            SwitchCompat fifteenMinSwitchEnd = dialog.findViewById(R.id.add_alert_15min_switch2);
            SwitchCompat thirtyMinSwitchEnd = dialog.findViewById(R.id.add_alert_30min_switch2);
            SwitchCompat oneHourSwitchEnd = dialog.findViewById(R.id.add_alert_1hour_switch2);
            SwitchCompat sixHoursSwitchEnd = dialog.findViewById(R.id.add_alert_6hours_switch2);
            SwitchCompat twelveHoursSwitchEnd = dialog.findViewById(R.id.add_alert_12hours_switch2);
            SwitchCompat oneDaySwitchEnd = dialog.findViewById(R.id.add_alert_1day_switch2);
            SwitchCompat twoDaysSwitchEnd = dialog.findViewById(R.id.add_alert_2days_switch2);
            SwitchCompat oneWeekSwitchEnd = dialog.findViewById(R.id.add_alert_1week_switch2);
            SwitchCompat twoWeeksSwitchEnd = dialog.findViewById(R.id.add_alert_2weeks_switch2);
            SwitchCompat oneMonthSwitchEnd = dialog.findViewById(R.id.add_alert_1month_switch2);
            
            Button cancelBtn = dialog.findViewById(R.id.add_alert_cancel_btn);
            Button saveBtn = dialog.findViewById(R.id.add_alert_save_alerts_btn);

            if (fiveMinAlertStart) {
                fiveMinSwitchStart.setChecked(true);
            }
            if (fifteenMinAlertStart) {
                fifteenMinSwitchStart.setChecked(true);
            }
            if (thirtyMinAlertStart) {
                thirtyMinSwitchStart.setChecked(true);
            }
            if (oneHourAlertStart) {
                oneHourSwitchStart.setChecked(true);
            }
            if (sixHourAlertStart) {
                sixHoursSwitchStart.setChecked(true);
            }
            if (twelveHourAlertStart) {
                twelveHoursSwitchStart.setChecked(true);
            }
            if (oneDayAlertStart) {
                oneDaySwitchStart.setChecked(true);
            }
            if (twoDayAlertStart) {
                twoDaysSwitchStart.setChecked(true);
            }
            if (oneWeekAlertStart) {
                oneWeekSwitchStart.setChecked(true);
            }
            if (twoWeekAlertStart) {
                twoWeeksSwitchStart.setChecked(true);
            }
            if (oneMonthAlertStart) {
                oneMonthSwitchStart.setChecked(true);
            }

            if (fiveMinAlertEnd) {
                fiveMinSwitchEnd.setChecked(true);
            }
            if (fifteenMinAlertEnd) {
                fifteenMinSwitchEnd.setChecked(true);
            }
            if (thirtyMinAlertEnd) {
                thirtyMinSwitchEnd.setChecked(true);
            }
            if (oneHourAlertEnd) {
                oneHourSwitchEnd.setChecked(true);
            }
            if (sixHourAlertEnd) {
                sixHoursSwitchEnd.setChecked(true);
            }
            if (twelveHourAlertEnd) {
                twelveHoursSwitchEnd.setChecked(true);
            }
            if (oneDayAlertEnd) {
                oneDaySwitchEnd.setChecked(true);
            }
            if (twoDayAlertEnd) {
                twoDaysSwitchEnd.setChecked(true);
            }
            if (oneWeekAlertEnd) {
                oneWeekSwitchEnd.setChecked(true);
            }
            if (twoWeekAlertEnd) {
                twoWeeksSwitchEnd.setChecked(true);
            }
            if (oneMonthAlertEnd) {
                oneMonthSwitchEnd.setChecked(true);
            }

            saveBtn.setOnClickListener(view1 -> {
                boolean checked = false;
                Long assessmentID = assessmentId;
                int assessmentid = assessmentID.intValue();

                if (fiveMinSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 5*60*1000;
                    long notificationTime = assessmentStartDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(assessmentTitle);
                    builder.setContentText(assessmentTitle + " begins in five minutes.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 1 );
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+5, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT ) ;
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setFiveMinAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), 5, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setFiveMinAlertStart(false);
                }

                if (fifteenMinSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 15*60*1000;
                    long notificationTime = assessmentStartDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(assessmentTitle);
                    builder.setContentText(assessmentTitle + " begins in 15 minutes.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID );
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID, 2);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION, notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+15, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setFifteenMinAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+15, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setFifteenMinAlertStart(false);
                }

                if (thirtyMinSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 30*60*1000;
                    long notificationTime = assessmentStartDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(assessmentTitle);
                    builder.setContentText(assessmentTitle + " begins in 30 minutes.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 3);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+30, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setThirtyMinAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+30, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setThirtyMinAlertStart(false);
                }

                if (oneHourSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 60*60*1000;
                    long notificationTime = assessmentStartDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(assessmentTitle);
                    builder.setContentText(assessmentTitle + " begins in one hour.");
                    builder.setSmallIcon(R.drawable. ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 4);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+60, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setOneHourAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+60, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setOneHourAlertStart(false);
                }

                if (sixHoursSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 6*60*60*1000;
                    long notificationTime = assessmentStartDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(assessmentTitle);
                    builder.setContentText(assessmentTitle + " begins in six hours.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID );
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 5);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+360, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setSixHourAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+360, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setSixHourAlertStart(false);
                }

                if (twelveHoursSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 12*60*60*1000;
                    long notificationTime = assessmentStartDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(assessmentTitle);
                    builder.setContentText(assessmentTitle + " begins in twelve hours.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 6);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+720, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setTwelveHourAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+720, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setTwelveHourAlertStart(false);
                }

                if (oneDaySwitchStart.isChecked()) {
                    checked = true;
                    long millis = 24*60*60*1000;
                    long notificationTime = assessmentStartDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default" );
                    builder.setContentTitle(assessmentTitle);
                    builder.setContentText(assessmentTitle + " begins in one day.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 7);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+1440, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setOneDayAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+1440, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setOneDayAlertStart(false);
                }

                if (twoDaysSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 48*60*60*1000;
                    long notificationTime = assessmentStartDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(assessmentTitle);
                    builder.setContentText(assessmentTitle + " begins in two days.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 8);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+2880, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setTwoDayAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+2880, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setTwoDayAlertStart(false);
                }

                if (oneWeekSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 7*24*60*60*1000;
                    long notificationTime = assessmentStartDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle( assessmentTitle );
                    builder.setContentText(assessmentTitle + " begins in one week.");
                    builder.setSmallIcon(R.drawable. ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 9);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+10080, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setOneWeekAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+10080, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setOneWeekAlertStart(false);
                }

                if (twoWeeksSwitchStart.isChecked()) {
                    checked = true;
                    long millis = 14*24*60*60*1000;
                    long notificationTime = assessmentStartDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default" );
                    builder.setContentTitle( assessmentTitle );
                    builder.setContentText(assessmentTitle + " begins in two weeks.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build() ;

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 10);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+20160, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setTwoWeekAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+20160, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setTwoWeekAlertStart(false);
                }

                if (oneMonthSwitchStart.isChecked()) {
                    checked = true;
                    long weekMillis = 7*24*60*60*1000;
                    long monthMillis = weekMillis*4;
                    long notificationTime = assessmentStartDate.getTime() - monthMillis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(assessmentTitle);
                    builder.setContentText(assessmentTitle + " begins in 1 month.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 11);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+40320, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setOneMonthAlertStart(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+40320, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setOneMonthAlertStart(false);
                }

                if (fiveMinSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 5*60*1000;
                    long notificationTime = assessmentEndDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(assessmentTitle);
                    builder.setContentText(assessmentTitle + " ends in five minutes.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 1 );
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+51, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT ) ;
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setFiveMinAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+51, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setFiveMinAlertEnd(false);
                }

                if (fifteenMinSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 15*60*1000;
                    long notificationTime = assessmentEndDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(assessmentTitle);
                    builder.setContentText(assessmentTitle + " ends in 15 minutes.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID );
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID, 2);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION, notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+151, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setFifteenMinAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+151, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setFifteenMinAlertEnd(false);
                }

                if (thirtyMinSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 30*60*1000;
                    long notificationTime = assessmentEndDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(assessmentTitle);
                    builder.setContentText(assessmentTitle + " ends in 30 minutes. The start date is " + startDateText.getText());
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 3);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+301, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setThirtyMinAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+301, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setThirtyMinAlertEnd(false);
                }

                if (oneHourSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 60*60*1000;
                    long notificationTime = assessmentEndDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(assessmentTitle);
                    builder.setContentText(assessmentTitle + " ends in one hour.");
                    builder.setSmallIcon(R.drawable. ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 4);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+601, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setOneHourAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+601, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setOneHourAlertEnd(false);
                }

                if (sixHoursSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 6*60*60*1000;
                    long notificationTime = assessmentEndDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(assessmentTitle);
                    builder.setContentText(assessmentTitle + " ends in six hours.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID );
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 5);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+3601, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setSixHourAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+3601, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setSixHourAlertEnd(false);
                }

                if (twelveHoursSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 12*60*60*1000;
                    long notificationTime = assessmentEndDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(assessmentTitle);
                    builder.setContentText(assessmentTitle + " ends in twelve hours.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 6);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+7201, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setTwelveHourAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+7201, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setTwelveHourAlertEnd(false);
                }

                if (oneDaySwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 24*60*60*1000;
                    long notificationTime = assessmentEndDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default" );
                    builder.setContentTitle(assessmentTitle);
                    builder.setContentText(assessmentTitle + " ends in one day.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 7);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+14401, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setOneDayAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+14401, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setOneDayAlertEnd(false);
                }

                if (twoDaysSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 48*60*60*1000;
                    long notificationTime = assessmentEndDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(assessmentTitle);
                    builder.setContentText(assessmentTitle + " ends in two days.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 8);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+28801, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setTwoDayAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+28801, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setTwoDayAlertEnd(false);
                }

                if (oneWeekSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 7*24*60*60*1000;
                    long notificationTime = assessmentEndDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle( assessmentTitle );
                    builder.setContentText(assessmentTitle + " ends in one week.");
                    builder.setSmallIcon(R.drawable. ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 9);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+100801, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setOneWeekAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+100801, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setOneWeekAlertEnd(false);
                }

                if (twoWeeksSwitchEnd.isChecked()) {
                    checked = true;
                    long millis = 14*24*60*60*1000;
                    long notificationTime = assessmentEndDate.getTime() - millis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default" );
                    builder.setContentTitle( assessmentTitle );
                    builder.setContentText(assessmentTitle + " ends in two weeks.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground);
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build() ;

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 10);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+201601, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setTwoWeekAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+201601, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setTwoWeekAlertEnd(false);
                }

                if (oneMonthSwitchEnd.isChecked()) {
                    checked = true;
                    long weekMillis = 7*24*60*60*1000;
                    long monthMillis = weekMillis*4;
                    long notificationTime = assessmentEndDate.getTime() - monthMillis;
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(getContext(), "default");
                    builder.setContentTitle(assessmentTitle);
                    builder.setContentText(assessmentTitle + " ends in 1 month.");
                    builder.setSmallIcon(R.drawable.ic_launcher_foreground );
                    builder.setAutoCancel(true);
                    builder.setChannelId(NOTIFICATION_CHANNEL_ID);
                    Notification notification = builder.build();

                    Intent notificationIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION_ID , 11);
                    notificationIntent.putExtra(NotificationBroadcast.NOTIFICATION , notification);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(getContext(), assessmentid+403201, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT );
                    assert alarmManager != null;
                    alarmManager.set(AlarmManager.RTC_WAKEUP, notificationTime, pendingIntent);
                    assessment.setOneMonthAlertEnd(true);
                } else {
                    Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
                    PendingIntent pendingIntent = PendingIntent.getBroadcast(
                            getContext(), assessmentid+403201, cancelIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT);
                    alarmManager.cancel(pendingIntent);
                    assessment.setOneMonthAlertEnd(false);
                }

                if (checked) {
                    CharSequence text = "Notification(s) set.";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(root.getContext(), text, duration);
                    toast.show();
                } else {
                    CharSequence text = "All notifications disabled.";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(root.getContext(), text, duration);
                    toast.show();
                }
                dialog.dismiss();
            });

            cancelBtn.setOnClickListener(view1 -> dialog.dismiss());

            dialog.show();
        });

        addAssessmentBtn.setOnClickListener(view1 -> {
            assessmentTitle = editTitle.getText().toString().trim();
            if (assessmentTitle.equals("null") || assessmentTitle.isEmpty() || String.valueOf(assessmentStartDate).equals("null") || String.valueOf(assessmentEndDate).equals("null")) {
                Context context = view1.getContext().getApplicationContext();
                CharSequence text = "Please input a title and select both start and end dates.";
                Toast toast = Toast.makeText(context, text, Toast.LENGTH_LONG);
                toast.show();
                return;
            }
            int assessmentTypeId = assessmentTypeRadioGroup.getCheckedRadioButtonId();
            if (assessmentTypeId == -1) {
                Context context = root.getContext().getApplicationContext();
                CharSequence text = "Assessment Type is required.";
                Toast toast = Toast.makeText(context, text, Toast.LENGTH_LONG);
                toast.show();
                return;
            }
            RadioButton selectedBtn = root.findViewById(assessmentTypeId);
            assessmentType = selectedBtn.getText().toString();

            if (assessmentStartDate.after(assessmentEndDate)) {
                Context context = root.getContext().getApplicationContext();
                CharSequence text = "Term Start must be before Term End.";
                Toast toast = Toast.makeText(context, text, Toast.LENGTH_LONG);
                toast.show();
                return;
            }
            assessment.setTitle(assessmentTitle);
            assessment.setType(assessmentType);
            if (!assessment.getStartDate().equals(assessmentStartDate)) {
                Context context = root.getContext().getApplicationContext();
                CharSequence text = "Assessment Start Date changed. Notifications reset.";
                resetStartNotifications();
                Toast toast = Toast.makeText(context, text, Toast.LENGTH_LONG);
                toast.show();
            }
            assessment.setStartDate(assessmentStartDate);
            if (!assessment.getEndDate().equals(assessmentEndDate)) {
                Context context = root.getContext().getApplicationContext();
                CharSequence text = "Assessment End Date changed. Notifications reset.";
                resetEndNotifications();
                Toast toast = Toast.makeText(context, text, Toast.LENGTH_LONG);
                toast.show();
            }
            assessment.setEndDate(assessmentEndDate);
            if (assessmentParentCourse != null) {
                long parentCourseId = assessmentParentCourse.getCourseId();
                assessment.setCourseOwnerId(parentCourseId);
            }
            assessmentsViewModel.updateAssessment(assessment);

            Navigation.findNavController(view1).navigate(R.id.action_assessmentDetailsFragment_to_assessmentsFragment);
        });

        cancelBtn1.setOnClickListener(view1 -> Navigation.findNavController(view1).navigate(R.id.action_assessmentDetailsFragment_to_assessmentsFragment));

        return root;
    }
    private void resetStartNotifications() {
        Long assessmentID = assessmentId;
        int assessmentid = assessmentID.intValue();
        Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+5, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setFiveMinAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+15, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setFifteenMinAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+30, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setThirtyMinAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+60, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setOneHourAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+360, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setSixHourAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+720, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setTwelveHourAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+1440, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setOneDayAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+2880, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setTwoDayAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+10080, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setOneWeekAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+20160, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setTwoWeekAlertStart(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+40320, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setOneMonthAlertStart(false);
    }

    private void resetEndNotifications() {
        Long assessmentID = assessmentId;
        int assessmentid = assessmentID.intValue();
        Intent cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+51, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setFiveMinAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+151, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setFifteenMinAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+301, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setThirtyMinAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+601, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setOneHourAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+3601, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setSixHourAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+7201, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setTwelveHourAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+14401, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setOneDayAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+28801, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setTwoDayAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+100801, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setOneWeekAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+201601, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setTwoWeekAlertEnd(false);

        cancelIntent = new Intent(getActivity(), NotificationBroadcast.class);
        pendingIntent = PendingIntent.getBroadcast(
                getContext(), assessmentid+403201, cancelIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.cancel(pendingIntent);
        assessment.setOneMonthAlertEnd(false);
    }
}