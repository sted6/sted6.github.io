package com.wgu.wguscheduler.packages.instructors;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import static androidx.room.OnConflictStrategy.REPLACE;

@Dao
public interface InstructorDao {

    @Insert(onConflict = REPLACE)
    void insert(Instructor instructor);

    @Delete
    void delete(Instructor instructor);

    @Delete
    void deleteList(List<Instructor> instructors);

    @Update
    void update(Instructor instructor);

    @Query("SELECT * FROM instructors")
    LiveData<List<Instructor>> getAllInstructorsLive();
}
