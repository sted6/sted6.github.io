package com.wgu.wguscheduler.packages.assessments;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.wgu.wguscheduler.R;
import com.wgu.wguscheduler.packages.courses.Course;
import com.wgu.wguscheduler.packages.courses.CoursesViewModel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AddAssessmentFragment extends Fragment {
    AssessmentViewModel assessmentsViewModel;
    CoursesViewModel coursesViewModel;

    private String assessmentTitle;
    private String assessmentType;
    private Date assessmentStartDate;
    private Date assessmentEndDate;
    private Course assessmentParentCourse;

    EditText editTitle;
    TextView parentCourseText;
    TextView startDateText;
    TextView endDateText;

    Button setParentCourseBtn;
    RadioGroup assessmentTypeRadioGroup;
    RadioButton objectiveRadio;
    RadioButton performanceRadio;
    Button startDateBtn;
    Button endDateBtn;

    Button cancelBtn;
    Button addAssessmentBtn;

    
    public AddAssessmentFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_add_assessment, container, false);
        assessmentsViewModel = ViewModelProviders.of(requireActivity()).get(AssessmentViewModel.class);
        coursesViewModel = ViewModelProviders.of(requireActivity()).get(CoursesViewModel.class);

        editTitle = root.findViewById(R.id.add_assessment_edit_text_assessment_title);

        setParentCourseBtn = root.findViewById(R.id.add_assessment_set_parent_course_btn);
        parentCourseText = root.findViewById(R.id.add_assessment_parent_course_text);

        assessmentTypeRadioGroup = root.findViewById(R.id.add_assessment_type_radio_group);
        objectiveRadio = root.findViewById(R.id.add_assessment_objective_radio);
        performanceRadio = root.findViewById(R.id.add_assessment_performance_radio);

        startDateText = root.findViewById(R.id.add_assessment_start_date_text);
        endDateText = root.findViewById(R.id.add_assessment_end_date_text);

        startDateBtn = root.findViewById(R.id.add_assessment_add_start_btn);
        endDateBtn = root.findViewById(R.id.add_assessment_add_end_btn);

        cancelBtn = root.findViewById(R.id.add_assessment_cancel_btn);
        addAssessmentBtn = root.findViewById(R.id.add_assessment_add_assessment_btn);


        setParentCourseBtn.setOnClickListener(view -> {
            SetParentCourseAdapter setParentCourseAdapter;
            RecyclerView setParentRecyclerView;
            RecyclerView.LayoutManager layoutManager;

            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.set_parent_term);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);

            Button cancelBtn = dialog.findViewById(R.id.set_parent_term_cancel_btn);
            cancelBtn.setOnClickListener(view1 -> {
                dialog.dismiss();
            });

            setParentCourseAdapter = new SetParentCourseAdapter(new SetParentCourseAdapter.CourseDiff(), getActivity(), dialog);
            layoutManager = new LinearLayoutManager(dialog.getContext());
            coursesViewModel = ViewModelProviders.of(getActivity()).get(CoursesViewModel.class);
            coursesViewModel.getCoursesLive().observe(getViewLifecycleOwner(), setParentCourseAdapter::submitList);

            setParentRecyclerView = dialog.findViewById(R.id.recycler_view_parent_terms);

            setParentRecyclerView.setAdapter(setParentCourseAdapter);
            setParentRecyclerView.setLayoutManager(layoutManager);
            setParentCourseAdapter.notifyDataSetChanged();
            dialog.show();
            dialog.setOnDismissListener( data -> {
                assessmentParentCourse = assessmentsViewModel.getParentCourse();
                if (assessmentParentCourse != null) {
                    parentCourseText.setText("Parent Course: " + assessmentParentCourse.getTitle());
                }
            });
        });


        startDateBtn.setOnClickListener(view1 -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.datepicker);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.show();

            DatePicker datePicker = dialog.findViewById(R.id.datePicker);

            if (assessmentStartDate != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String endDateString = sdf.format(assessmentStartDate);
                String[] dateArr = endDateString.split("-");
                int startDay = Integer.parseInt(dateArr[0]);
                int startMonth = Integer.parseInt(dateArr[1])-1;
                int startYear = Integer.parseInt(dateArr[2]);
                datePicker.updateDate(startYear, startMonth, startDay);
            }
            Button addDateBtn = dialog.findViewById(R.id.btn_datepicker_add);
            Button cancelDateBtn = dialog.findViewById(R.id.btn_datepicker_cancel);

            addDateBtn.setOnClickListener(view2 -> {
                int day  = datePicker.getDayOfMonth();
                int month= datePicker.getMonth();
                int year = datePicker.getYear();
                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, day);

                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String formattedDate = sdf.format(calendar.getTime());
                try {
                    Date date = sdf.parse(formattedDate);
                    assessmentStartDate = date;
                    sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
                    formattedDate = sdf.format(calendar.getTime());
                    startDateText.setText("Start Date: " + formattedDate);
                } catch (ParseException e) {
                    assessmentStartDate = new Date();
                    e.printStackTrace();
                }
                dialog.dismiss();
            });

            cancelDateBtn.setOnClickListener(view2 -> dialog.dismiss());
        });

        endDateBtn.setOnClickListener(view1 -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.datepicker);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.show();

            DatePicker datePicker = dialog.findViewById(R.id.datePicker);

            if (assessmentEndDate != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String endDateString = sdf.format(assessmentEndDate);
                String[] dateArr = endDateString.split("-");
                int endDay = Integer.parseInt(dateArr[0]);
                int endMonth = Integer.parseInt(dateArr[1])-1;
                int endYear = Integer.parseInt(dateArr[2]);
                datePicker.updateDate(endYear, endMonth, endDay);
            }

            Button addDateBtn = dialog.findViewById(R.id.btn_datepicker_add);
            Button cancelDateBtn = dialog.findViewById(R.id.btn_datepicker_cancel);

            addDateBtn.setOnClickListener(view2 -> {
                int day  = datePicker.getDayOfMonth();
                int month= datePicker.getMonth();
                int year = datePicker.getYear();

                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, day);

                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String formattedDate = sdf.format(calendar.getTime());
                try {
                    Date date = sdf.parse(formattedDate);
                    assessmentEndDate = date;
                    sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
                    formattedDate = sdf.format(calendar.getTime());
                    endDateText.setText("End Date: " + formattedDate);
                } catch (ParseException e) {
                    assessmentEndDate = new Date();
                    e.printStackTrace();
                }
                dialog.dismiss();
            });

            cancelDateBtn.setOnClickListener(view2 -> dialog.dismiss());
        });



        addAssessmentBtn.setOnClickListener(view1 -> {
            assessmentTitle = editTitle.getText().toString().trim();
            if (assessmentTitle.equals("null") || String.valueOf(assessmentStartDate).equals("null") || String.valueOf(assessmentEndDate).equals("null")) {
                Context context = view1.getContext().getApplicationContext();
                CharSequence text = "Please input a title and select both start and end dates.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            int assessmentTypeId = assessmentTypeRadioGroup.getCheckedRadioButtonId();
            if (assessmentTypeId == -1) {
                Context context = root.getContext().getApplicationContext();
                CharSequence text = "Assessment Type is required.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            RadioButton selectedBtn = root.findViewById(assessmentTypeId);
            assessmentType = selectedBtn.getText().toString();

            if (assessmentStartDate.after(assessmentEndDate)) {
                Context context = root.getContext().getApplicationContext();
                CharSequence text = "Term Start must be before Term End.";
                Toast toast = Toast.makeText(context, text, Toast.LENGTH_LONG);
                toast.show();
                return;
            }
            Assessment newAssessment = new Assessment(assessmentTitle, assessmentType, assessmentStartDate, assessmentEndDate);
            if (assessmentParentCourse != null) {
                long parentCourseId = assessmentParentCourse.getCourseId();
                newAssessment.setCourseOwnerId(parentCourseId);
            };
            assessmentsViewModel.addAssessment(newAssessment);

            Navigation.findNavController(view1).navigate(R.id.action_addAssessmentFragment_to_assessmentsFragment);
        });

        cancelBtn.setOnClickListener(view1 -> Navigation.findNavController(view1).navigate(R.id.action_addAssessmentFragment_to_assessmentsFragment));

        return root;
    }
}