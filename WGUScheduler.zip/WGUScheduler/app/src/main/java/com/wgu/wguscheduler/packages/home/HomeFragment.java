package com.wgu.wguscheduler.packages.home;

import android.content.Intent;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.wgu.wguscheduler.R;
import com.wgu.wguscheduler.SchedulerActivity;
import com.wgu.wguscheduler.databinding.FragmentHomeBinding;

public class HomeFragment extends Fragment {
    private static final int CUSTOM_EVENT_SCHEDULER_REQUEST = 1;
    private FragmentHomeBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        LinearLayout rootLinearLayout = root.findViewById(R.id.home_linear_layout);

        // PROGRAMMATICALLY CREATING UI
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(5, 5, 5, 5);

        TextView textView = new TextView(getActivity());
        textView.setText("Welcome, Night Owl");
        textView.setLayoutParams(params);
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 60);
        textView.setGravity(Gravity.CENTER);

        Button customSchedulerBtn = new Button(getActivity());
        customSchedulerBtn.setText("Open Custom Event Scheduler");
        customSchedulerBtn.setLayoutParams(params);
        customSchedulerBtn.setGravity(Gravity.CENTER);

        GradientDrawable buttonBackground = new GradientDrawable();
        buttonBackground.setColor(getResources().getColor(R.color.wgu_blue, getActivity().getTheme()));
        buttonBackground.setCornerRadius(20);
        customSchedulerBtn.setBackground(buttonBackground);
        customSchedulerBtn.setTextColor(getResources().getColor(R.color.white, getActivity().getTheme()));
        customSchedulerBtn.setPadding(20, 5, 20, 5);

        rootLinearLayout.addView(textView, params);
        rootLinearLayout.addView(customSchedulerBtn);

        customSchedulerBtn.setOnClickListener(view -> {
            Intent intent = new Intent(getActivity(), SchedulerActivity.class);
            startActivityForResult(intent, CUSTOM_EVENT_SCHEDULER_REQUEST);
        });
        //
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}