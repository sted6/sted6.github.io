package com.wgu.wguscheduler.packages.terms;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.wgu.wguscheduler.R;
import com.wgu.wguscheduler.packages.courses.Course;
import com.wgu.wguscheduler.packages.courses.CoursesViewModel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


public class AddTermFragment extends Fragment {
    private TermsViewModel termsViewModel;

    private TextView startDateText;
    private TextView endDateText;
    private TextView coursesLabelCount;

    private EditText editTitle;

    private String termTitle;
    private Date termStart;
    private Date termEnd;
    CoursesViewModel coursesViewModel;

    public AddTermFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_term, container, false);
        termsViewModel = new ViewModelProvider(this, ViewModelProvider.AndroidViewModelFactory.getInstance(getActivity().getApplication())).get(TermsViewModel.class);
        coursesViewModel = ViewModelProviders.of(requireActivity()).get(CoursesViewModel.class);
        coursesViewModel.resetSelectedCourses();

        startDateText = view.findViewById(R.id.add_course_start_date_text);
        endDateText = view.findViewById(R.id.add_course_end_date_text);
        coursesLabelCount = view.findViewById(R.id.add_term_course_count_label);

        editTitle = view.findViewById(R.id.edit_text_term_title);
        Button startDateBtn = view.findViewById(R.id.btn_add_term_start);
        Button endDateBtn = view.findViewById(R.id.btn_add_term_end);
        Button addCoursesBtn = view.findViewById(R.id.btn_add_term_courses);
        Button addTermBtn = view.findViewById(R.id.btn_add_term);
        Button cancelBtn = view.findViewById(R.id.btn_cancel_add_term);

        startDateBtn.setOnClickListener(view1 -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.datepicker);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.show();

            DatePicker datePicker = dialog.findViewById(R.id.datePicker);

            if (termStart != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String endDateString = sdf.format(termStart);
                String[] dateArr = endDateString.split("-");
                int startDay = Integer.parseInt(dateArr[0]);
                int startMonth = Integer.parseInt(dateArr[1])-1;
                int startYear = Integer.parseInt(dateArr[2]);
                datePicker.updateDate(startYear, startMonth, startDay);
            }
            Button addDateBtn = dialog.findViewById(R.id.btn_datepicker_add);
            Button cancelDateBtn = dialog.findViewById(R.id.btn_datepicker_cancel);

            addDateBtn.setOnClickListener(view2 -> {
                int day  = datePicker.getDayOfMonth();
                int month= datePicker.getMonth();
                int year = datePicker.getYear();
                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, day);

                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String formattedDate = sdf.format(calendar.getTime());
                try {
                    Date date = sdf.parse(formattedDate);
                    termStart = date;
                    sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
                    formattedDate = sdf.format(calendar.getTime());
                    startDateText.setText("Start Date: " + formattedDate);
                } catch (ParseException e) {
                    termStart = new Date();
                    e.printStackTrace();
                }
                dialog.dismiss();
            });

            cancelDateBtn.setOnClickListener(view2 -> dialog.dismiss());
        });

        endDateBtn.setOnClickListener(view1 -> {
            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.datepicker);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);
            dialog.show();

            DatePicker datePicker = dialog.findViewById(R.id.datePicker);

            if (termEnd != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String endDateString = sdf.format(termEnd);
                String[] dateArr = endDateString.split("-");
                int endDay = Integer.parseInt(dateArr[0]);
                int endMonth = Integer.parseInt(dateArr[1])-1;
                int endYear = Integer.parseInt(dateArr[2]);
                datePicker.updateDate(endYear, endMonth, endDay);
            }

            Button addDateBtn = dialog.findViewById(R.id.btn_datepicker_add);
            Button cancelDateBtn = dialog.findViewById(R.id.btn_datepicker_cancel);

            addDateBtn.setOnClickListener(view2 -> {
                int day  = datePicker.getDayOfMonth();
                int month= datePicker.getMonth();
                int year = datePicker.getYear();

                Calendar calendar = Calendar.getInstance();
                calendar.set(year, month, day);

                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                String formattedDate = sdf.format(calendar.getTime());
                try {
                    Date date = sdf.parse(formattedDate);
                    termEnd = date;
                    sdf = new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault());
                    formattedDate = sdf.format(calendar.getTime());
                    endDateText.setText("End Date: " + formattedDate);
                } catch (ParseException e) {
                    termEnd = new Date();
                    e.printStackTrace();
                }
                dialog.dismiss();
            });

            cancelDateBtn.setOnClickListener(view2 -> dialog.dismiss());
        });

        addCoursesBtn.setOnClickListener(view1 -> {
            AddCoursesToTermAdapter addCoursesToTermAdapter;
            RecyclerView addCoursesToTermRecyclerView;
            RecyclerView.LayoutManager addCourseRecyclerViewLayoutManager;

            Dialog dialog = new Dialog(getContext());
            dialog.setContentView(R.layout.add_courses_to_term);
            int width = WindowManager.LayoutParams.MATCH_PARENT;
            int height = WindowManager.LayoutParams.WRAP_CONTENT;
            dialog.getWindow().setLayout(width, height);

            Button addSelectedCoursesBtn = dialog.findViewById(R.id.add_selected_courses_btn);
            Button cancel = dialog.findViewById(R.id.cancel_selected_courses_btn);
            addCoursesToTermRecyclerView = dialog.findViewById(R.id.recycler_view_add_courses_to_term);

            addCoursesToTermAdapter = new AddCoursesToTermAdapter(new AddCoursesToTermAdapter.CourseDiff(), getActivity());
            addCourseRecyclerViewLayoutManager = new LinearLayoutManager(getContext());

            addCoursesToTermRecyclerView.setLayoutManager(addCourseRecyclerViewLayoutManager);
            addCoursesToTermRecyclerView.setAdapter(addCoursesToTermAdapter);

            addCoursesToTermAdapter.submitList(coursesViewModel.getCourses());

            dialog.show();

            cancel.setOnClickListener(view2 -> {
                dialog.dismiss();
                coursesViewModel.resetSelectedCourses();
            });

            addSelectedCoursesBtn.setOnClickListener(view2 -> {
                ArrayList<Course> courses = coursesViewModel.getSelectedCourses();
                if (courses.size() <= 0) {
                    Context context = view.getContext().getApplicationContext();
                    CharSequence text = "No Courses selected.";
                    int duration = Toast.LENGTH_LONG;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                    return;
                }
                int courseCount = courses.size();
                for (int x = 0; x < courseCount; x++) {
                    if (courses.get(x).getTermOwnerId() != 0) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                        builder.setMessage("One or more of the selected Courses are assigned to another Term. Are you sure you want to reassign them?");
                        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog1, int id) {
                                coursesViewModel.addCoursesToToBeAddedToTermList(courses);
                                coursesViewModel.resetSelectedCourses();
                                dialog1.dismiss();
                                dialog.dismiss();
                                coursesLabelCount.setText("Courses(" + courseCount+ ")");
                            }
                        });
                        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.dismiss();
                            }
                        });
                        AlertDialog dialog1 = builder.create();
                        dialog1.show();
                        return;
                    }
                }
                coursesViewModel.addCoursesToToBeAddedToTermList(courses);
                coursesViewModel.resetSelectedCourses();
                dialog.dismiss();
                coursesLabelCount.setText("Courses("+courseCount+")");
            });

        });

        addTermBtn.setOnClickListener(view1 -> {
            termTitle = editTitle.getText().toString().trim();
            if (termTitle.equals("null") || String.valueOf(termStart).equals("null") || String.valueOf(termEnd).equals("null")) {
                Context context = view1.getContext().getApplicationContext();
                CharSequence text = "Please input a title and select both start and end dates.";
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                return;
            }
            if (termStart.after(termEnd)) {
                Context context = view.getContext().getApplicationContext();
                CharSequence text = "Term Start must be before Term End.";
                Toast toast = Toast.makeText(context, text, Toast.LENGTH_LONG);
                toast.show();
                return;
            }
            long newTermId = termsViewModel.addTerm(new Term(termTitle, termStart, termEnd));
            Log.d("New Term Id", String.valueOf(newTermId));
            ArrayList<Course> coursesToAdd = coursesViewModel.getCoursesToBeAddedToTerm();
            coursesToAdd.forEach(course -> {
                course.setTermOwnerId(newTermId);
                coursesViewModel.updateCourse(course);
            });
            coursesViewModel.resetCoursesToBeAddedToTermList();
            Navigation.findNavController(view1).navigate(R.id.action_addTermFragment_to_termsFragment);
        });

        cancelBtn = view.findViewById(R.id.btn_cancel_add_term);
        cancelBtn.setOnClickListener(view1 -> Navigation.findNavController(view1).navigate(R.id.action_addTermFragment_to_termsFragment));

        return view;
    }
}